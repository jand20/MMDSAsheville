<?php session_start();
//if session is not set redirect the user
if(empty($_SESSION['user']))
header("Location:index.php");

include "config.php";
$user = $_SESSION['user'];
$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tbluser where fldUserName='$user'"));
$fac=$sql_values_fetch['fldFacility'];
$uid=$sql_values_fetch['fldID'];

//  require_once "Mail.php"; // PEAR Mail package
//  require_once ('Mail/mime.php'); // PEAR Mail_Mime packge

$host = "mail.mdipacs.net";
$username = "dpotter";
$password = "brasil06";

if($id !="")
{
$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tblorderdetails where fldID='$id'"));
$sql = "select * from tblorderdetails where fldID like '$id'";
$result = mysql_query($sql) or die (mysql_error());
$num=0;
$num = mysql_num_rows($result);
}

?>
<script type="text/javascript">
function search_prompt() {
var retVal=""
var valReturned;
retVal=showModalDialog('searchpop.htm');
valReturned=retVal;
location.replace(valReturned);
}
function newpt() {
location.replace('?pg=42');
}
</script>
<script type="text/javascript"></script>
<script type="text/javascript">
function cdenable(){
if (document.getElementById('cdrequested').value != 0){
document.getElementById('cdaddrlab').style.display = '';
document.getElementById('cddatelab').style.display = '';
document.getElementById('cdaddr').style.display = '';
document.getElementById('cddate').style.display = '';
} else {
document.getElementById('cddatelab').style.display = 'none';
document.getElementById('cdaddrlab').style.display = 'none';
document.getElementById('cdaddr').style.display = 'none';
document.getElementById('cddate').style.display = 'none';
};
}
function phyenable(){
if (document.forms[0].orderingphysicians.value == "new"){
document.forms[0].phynew.style.display = "";
} else {
document.forms[0].phynew.style.display = "none";
};
}
</script>
<script type="text/javascript" src="facility.js"></script>
<style type="text/css">
@import "timer/jquery.timeentry.css";
</style>
<script type="text/javascript" src="timer/jquery-1.3.2.js"></script>
<script type="text/javascript" src="timer/jquery.min.js"></script>
<script type="text/javascript" src="timer/jquery.timeentry.js"></script>
<script type="text/javascript">
$(function () {
	$('#schdate2').timeEntry({spinnerImage: ''});
    $('#schdate22').timeEntry({spinnerImage: ''});

});
</script>
 <script type="text/javascript" src="jquery-latest.js"></script>
 <script type="text/javascript" src="jquery.validate.js"></script>
 <script type="text/javascript">
  $.validator.addMethod(
      "aDate",
      function(value, element) {
          return value.match(/^\d\d?\-\d\d?\-\d\d\d\d$/);

      },
      "Please enter a date in the format mm-dd-yyyy"
  );
  $.validator.addMethod(
      "aDate1",
      function(value, element) {
          var temp = new Array();
		  temp = value.split('-');
		  month=temp[0];
		  days=temp[1];
		  year=temp[2];
		  flag=1;
		  if(value.length<10)
		  flag=0;
		  if(year.length<4)
		  flag=0;
		  if(year<1600 || year>2400)
		  flag=0;
		  if(month.length<2)
		  flag=0;
		  if(month<1 || month>12)
		  flag=0;
		  if(days.length<2)
		  flag=0;
          if ((parseInt(year)%4) == 0){
              if (parseInt(year)%100 == 0){
                  if (parseInt(year)%400 != 0){
		    		mdays=28;
                  }
                 if (parseInt(year)%400 == 0){
		    		mdays=29;
                  }
              }
              if (parseInt(year)%100 != 0){
		    	mdays=29;
              }
          }
          if ((parseInt(year)%4) != 0){
		  mdays=28;
          }
          if(month==01||month==03||month==05||month==07||month==08||month==10||month==12)
          mdays=31;
          if(month==04||month==06||month==09||month==11)
          mdays=30;
		  if(days<1 || days>mdays)
		  flag=0;

          if(flag==1)
          return true;
          else
          return false;

      },
      "Please enter a date in the format mm-dd-yyyy"
  );

    $(document).ready(function() {
      $("#myform").validate({
        rules: {
        lastname: {
          required: false
        },
        firstname: {
          required: false
        },
        symptoms1: {
          required: false
        },
        dob: {
          required: false,
          aDate: false,
          aDate1: false
        },
        schdate12: {
          required: false,
          aDate: false,
          aDate1: false
        },
        patientssn: {
          required: false
        },
        sex: {
          required: false
        },
		History: {
          required: false
        },
        requester: {
          required: false
        },
        facility: {
          required: false
        },
        orderingphysicians: {
          required: false
        },
		medicare: {
          required: false
        }
        }
      });
    });
  </script>
<link href="style.css" rel="stylesheet" type="text/css" />
<form id="myform" action="" method="post">
<table width="1050" border="0" cellpadding="0" cellspacing="0" background="main.png">
  <tr>
    <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td>&nbsp;</td>
      </tr>
      <?if ($num == 0 && $id !="") {?>
      <tr>
        <td><div align="center"><span class="war"><strong>Patient doesn't exist</strong></span></div></td>
      </tr>
      <? } ?>
      <tr>
        <td><table width="75%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="15%"><span class="lab3">Last name:</span></td>
            <td width="20%"><input name="lastname" type="text" class="myinput1" value="<?=$sql_values_fetch['fldLastName']?>" /></td>
            <td width="15%"><span class="lab3">Bldg/Floor/Unit/Room:</span></td>
            <td width="20%"><input name="patientroom" type="text" class="myinput1" value="<?=$sql_values_fetch['fldPatientroom']?>" /></td>
		  </tr>
          <tr>			
			<td width="13%"><span class="lab3">First name:</span></td>
            <td><input name="firstname" type="text" class="myinput1" value="<?=$sql_values_fetch['fldFirstName']?>"  /></td>
            <td><span class="lab3">Soc. Sec. No.:</span></td>
            <td><input name="patientssn" type="text" class="myinput1" value="<?=$sql_values_fetch['fldPatientSSN']?>" /></td>
          <tr>
            <td><span class="lab">Middle name:</span></td>
            <td><input name="middlename" type="text" class="myinput1" value="<?=$sql_values_fetch['fldMiddleName']?>" /></td>
            <td><span class="lab">Employee Screening:</span></td>
            <td width="9%"><input name="stat" type="checkbox" class="chk" value="1" <? if($sql_values_fetch['fldStat'] == 1) {?>checked="checked"<? } ?> /></td>
		  </tr>
         <tr>
            <td><span class="lab">Suffix (Jr. Sr. III):</span></td>
            <td><input name="surname" type="text" class="myinput2" value="<?=$sql_values_fetch['fldSurName']?>" size="10" /></td>
          </tr>
          <tr>
            <?
	 		function formatDateddmmyy($dDate){
	 		if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
			    return '';
}
			$dNewDate = strtotime($dDate);
			return date('m-d-Y',$dNewDate);
			}
			$ddob="MM-DD-YYYY";
			$fdob = $sql_values_fetch['fldDOB'];
			if($fdob!='')
			{
			$ddob = formatDateddmmyy($fdob);
			}
			?>
            <td><span class="lab3">DOB: (MM-DD-YYYY)</span></td>
            <td><input name="dob" type="text" class="myinput1" value="<?=$ddob?>" maxlength="10"  /></td>
			</tr>
			<tr>
            <td><span class="lab3">Gender:</span></td>
            <td><select name="sex"  >
              <option value="" <? if($sql_values_fetch['fldGender'] == '') {?> selected="selected" <? } ?>>Select</option>
              <option value="female" <? if($sql_values_fetch['fldGender'] == 'female') {?> selected="selected" <? } ?>>FEMALE</option>
              <option value="male" <? if($sql_values_fetch['fldGender'] == 'male') {?> selected="selected" <? } ?>>MALE</option>
			  <option value="Unknown" <? if($sql_values_fetch['fldGender'] == 'Unknown') {?> selected="selected" <? } ?>>Unknown</option>
            </select></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
	  
	  <tr>
        <td>&nbsp;</td>
      </tr>
	  <tr>
	  <td><span class="lab">Study Info:</span></td>
	  </tr>
	  <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="11%"><span class="lab3">Referring Physician: </span></td>
            <td colspan="2"><select name="orderingphysicians" class="myselect1" onChange="phyenable();"  >
              <option selected="selected" value="">Select</option>
              <?
			  if($_SESSION['role'] =='facilityuser')
    		  {
			  //$sql="Select * from tbluser where fldRole='orderingphysician' and fldID in (Select fldUserID from tbluserfacdetails where                           fldFacility in (Select fldFacility from tbluserfacdetails where fldUserID in(Select fldid from tbluser where fldUserName='$user'))) Order by FldRealName";
			  $sql="SELECT * FROM tbluser where fldRole='orderingphysician' order by fldRealName";
			  } else {
			  $sql="SELECT * FROM tbluser where fldRole='orderingphysician' order by fldRealName";
			  }
			  $result = mysql_query($sql);
			  while($row = mysql_fetch_array($result))
	     	  {?>
              <option value="<?=$row['fldRealName']?>">
              <?=strtoupper($row['fldRealName'])?>
              </option>
              <? } ?>
              <option value="new">Not In List</option>
            </select>        
			<input name="phynew" id="phynew" style="display: none;"/></td>
			</tr>
			
			
			<tr>
			<td><span class="lab3">Ordered By:</span></td>
            <td width="20%"><input name="requester" type="text" class="myinput3"  value="<?=$sql_values_fetch['fldRequestedBy']?>" /></td>
			</tr>
			<tr>
			<td width="16%"><span class="lab3">Bldg/Floor/Unit/Room:</span></td>
            <td width="18%"><input name="patientroom" type="text" class="myinput3" value="<?=$sql_values_fetch['fldPatientroom']?>" /></td>
			</tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="9%"><span class="lab3">Procedure #1</span></td>
            <td width="33%"><span class="lab">
              <select name="procedure1" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr1" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr1" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr1" value="BILATERAL" />
B</label>
            </span></td>
            <td width="8%"><span class="lab3">Reason: </span></td>
            <td width="48%"><span class="lab">
              <input name="symptoms1" type="text" size="40" />
            </span></td>
            <td width="2%">&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #2</span></td>
            <td><span class="lab">
              <select name="procedure2" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr2" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr2" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr2" value="BILATERAL"/>
B</label>
            </span></td>
            <td><span class="lab">Reason: </span></td>
            <td><span class="lab">
              <input name="symptoms2" type="text" size="40" />
            </span></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #3</span></td>
            <td><span class="lab">
              <select name="procedure3" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr3" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr3" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr3" value="BILATERAL" />
B</label>
            </span></td>
            <td><span class="lab">Reason: </span></td>
            <td><span class="lab">
              <input name="symptoms3" type="text" size="40" />
            </span></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #4</span></td>
            <td><span class="lab">
              <select name="procedure4" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr4" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr4" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr4" value="BILATERAL" />
B</label>
            </span></td>
            <td><span class="lab">Reason: </span></td>
            <td><span class="lab">
              <input name="symptoms4" type="text" size="40" />
            </span></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #5</span></td>
            <td><span class="lab">
              <select name="procedure5" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr5" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr5" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr5" value="BILATERAL" />
B</label>
            </span></td>
            <td><span class="lab">Reason: </span></td>
            <td><span class="lab">
              <input name="symptoms5" type="text" size="40" />
            </span></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #6</span></td>
            <td><span class="lab">
              <select name="procedure6" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr6" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr6" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr6" value="BILATERAL" />
B</label>
            </span></td>
            <td><span class="lab">Reason: </span></td>
            <td><span class="lab">
              <input name="symptoms6" type="text" size="40" />
            </span></td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
	  
	  
	  <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Stat</span></td>
            <td width="9%"><input name="stat" type="checkbox" class="chk" value="1" <? if($sql_values_fetch['fldStat'] == 1) {?>checked="checked"<? } ?> /></td>
           </tr>
		   <tr>
        <td>&nbsp;</td>
      </tr>
		  <tr>
            <td width="9%"><span class="lab">Facility Name </span></td>
            <td colspan="3"><select name="facility" class="myselect5" onchange="showUser(this.value)"  >
              <?
			$sql="SELECT * FROM tblfacility where 1 order by fldFacilityName";
			//if($_SESSION['role'] == 'facilityuser') {$sql="select fldFacility as 'fldFacilityName' from tbluserfacdetails where fldUserID = '$uid'";}
			if($_SESSION['role'] =='facilityuser') { $sql="select * from tbluserfacdetails where fldUserID = '$uid'";
			echo $sql;}
			else { ?>
            <option selected="selected" value="">Select</option>
			<? }
			$result = mysql_query($sql);
			while($row = mysql_fetch_array($result))
			{?>
              <option value="<?=$row['fldFacilityName']?>" <? if($sql_values_fetch['fldFacilityName'] == $row['fldFacilityName']) {?> selected="selected" <? } ?>>
              <?=strtoupper($row['fldFacilityName'])?>
              </option>
              <? } ?>
            </select></td>
			</tr>
			<tr>
            <td width="17%" class="lab3"> Phone Results To:</td>
            <td width="19%"><div id="txtHint"><input name='faccontact' type='text' class='myinput1'  value='<?=$sql_values_fetch['fldFacPhone']?>' /></div></td>
          </tr>
		  <tr>
            <td width="17%" class="lab"> Fax To:</td>
            <td width="19%"><div id="txtHint"><input name='faccontact' type='text' class='myinput1'  value='<?=$sql_values_fetch['fldFacPhone']?>' /></div></td>
          </tr>
         
        </table></td>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
        <td>&nbsp;</td>
      </tr>
		  <tr>
            
            <td width="5%"><span class="lab3">Scheduled ServiceDate: (mm/dd/yyyy) </span></td>
            <td width="25%"><input name="schdate12" type="text" id="schdate12" size="20" value="<?php echo date('m/d/Y') ?>"/></td>
           </tr>
        
      <tr>
        <td>&nbsp;</td>
      </tr>
	  </table></td>
	  
	  <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="5%"><span class="lab">Notes:</span></td>
              <td height="20"><textarea name="symptoms" cols="60" rows="3">
              </textarea></td>
            </tr>
       </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
     
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><div align="center">
              <input type="submit" name="submit" value="Save" />
            </div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>

    </table></td>
  </tr>
</table>
</form>

<?php
if($_REQUEST['submit']!='')
{

if($_REQUEST['patientid']=='')
{
$i=0;
$sql="SELECT * from tblorderdetails where 1";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result))
{
$ptid=$row['fldPatientID'];
if(is_numeric($ptid))
{
$arr[$i++]=$ptid;
}
}
$pid=max($arr);
if($pid < 25001)
{
$pid=25000;
}
$pid = $pid + 1;
}
else
{
$pid=$_REQUEST['patientid'];
}


function formatdate($sDate1)
{
$sDate = split('-', $sDate1);
$sDate1 = $sDate[2].'-'.$sDate[0].'-'.$sDate[1];
return $sDate1;
}

$newdob = formatdate($_REQUEST['dob']);

function phone_number($sPhone){
    $sPhone = ereg_replace("[^0-9]",'',$sPhone);
    if(strlen($sPhone) != 10) return(False);
    $sArea = substr($sPhone,0,3);
    $sPrefix = substr($sPhone,3,3);
    $sNumber = substr($sPhone,6,4);
    $sPhone = "(".$sArea.")".$sPrefix."-".$sNumber;
    return($sPhone);
}

$cretime=date("Y-m-d",time());

$orddate = date('Y-m-d H:i',strtotime(formatdate($_REQUEST['schdate1']) . ' ' . $_REQUEST['schdate2']));
$schdate = date('Y-m-d H:i',strtotime(formatdate($_REQUEST['schdate12']) . ' ' . $_REQUEST['schdate22']));
$cddate = formatdate($_REQUEST['cddate']);

$ordphy=$_REQUEST['orderingphysicians'];
if($ordphy == "new")
{
$ordphy=$_REQUEST['phynew'];
}

$dispatched=0;
$technologist='';
$facy=$_REQUEST['facility'];
$sql_values_fetch_fac =	mysql_fetch_array(mysql_query("select * from tblfacility where fldFacilityName='$facy'"));
$adisp=$sql_values_fetch_fac['fldAutoDispatch'];
if($adisp==1)
{
$dispatched=1;
$technologist=$sql_values_fetch_fac['fldTechnologist'];
}

$sql_insert = mysql_query("insert into tblorderdetails set
fldPatientID='".strtoupper(strip_tags(addslashes($pid)))."',
fldSchDate='".strtoupper(strip_tags(addslashes($schdate)))."',
fldPatientSSN='".strtoupper(strip_tags(addslashes($_REQUEST['patientssn'])))."',
fldFirstName='".strtoupper(strip_tags(addslashes($_REQUEST['firstname'])))."',
fldLastName='".strtoupper(strip_tags(addslashes($_REQUEST['lastname'])))."',
fldMiddleName='".strtoupper(strip_tags(addslashes($_REQUEST['middlename'])))."',
fldSurName='".strtoupper(strip_tags(addslashes($_REQUEST['surname'])))."',
fldDOB='".strtoupper(strip_tags(addslashes($newdob)))."',
fldGender='".(strip_tags(addslashes($_REQUEST['sex'])))."',
fldInsurance='".(strip_tags(addslashes($_REQUEST['insurance'])))."',
fldMedicareNumber='".strtoupper(strip_tags(addslashes($_REQUEST['medicare'])))."',
fldMedicaidNumber='".strtoupper(strip_tags(addslashes($_REQUEST['medicaid'])))."',
fldState='".(strip_tags(addslashes($_REQUEST['state'])))."',
fldInsuranceCompanyName='".strtoupper(strip_tags(addslashes($_REQUEST['insurancecompanyname'])))."',
fldHmoContract='".strtoupper(strip_tags(addslashes($_REQUEST['hmo_contract'])))."',
fldPolicy='".strtoupper(strip_tags(addslashes($_REQUEST['policy'])))."',
fldGroup='".strtoupper(strip_tags(addslashes($_REQUEST['group'])))."',
fldResponsiblePerson='".strtoupper(strip_tags(addslashes($_REQUEST['responsibleperson'])))."',
fldRelationship='".(strip_tags(addslashes($_REQUEST['relationship'])))."',
fldFacilityName='".(strip_tags(addslashes($_REQUEST['facility'])))."',
fldFacPhone='".(phone_number($_REQUEST['faccontact']))."',
fldPrivateAddressLine1='".strtoupper(strip_tags(addslashes($_REQUEST['privatestreetaddress1'])))."',
fldPrivateAddressLine2='".strtoupper(strip_tags(addslashes($_REQUEST['privatestreetaddress2'])))."',
fldPrivateAddressCity='".strtoupper(strip_tags(addslashes($_REQUEST['privatecity'])))."',
fldPrivateAddressState='".(strip_tags(addslashes($_REQUEST['privatestate'])))."',
fldPrivateAddressZip='".strtoupper(strip_tags(addslashes($_REQUEST['privatezipcode'])))."',
fldPrivatePhoneNumber='".strtoupper(phone_number($_REQUEST['privatephone']))."',
fldHomeAddressLine1='".strtoupper(strip_tags(addslashes($_REQUEST['homestreetaddress1'])))."',
fldHomeAddressLine2='".strtoupper(strip_tags(addslashes($_REQUEST['homestreetaddress2'])))."',
fldHomeAddressCity='".strtoupper(strip_tags(addslashes($_REQUEST['homecity'])))."',
fldHomeAddressState='".(strip_tags(addslashes($_REQUEST['homestate'])))."',
fldHomeAddressZip='".strtoupper(strip_tags(addslashes($_REQUEST['homezipcode'])))."',
fldHomePhoneNumber='".strtoupper(strip_tags(addslashes($_REQUEST['homephone'])))."',
fldStat='".strtoupper(strip_tags(addslashes($_REQUEST['stat'])))."',
fldOrderingPhysicians='".(strip_tags(addslashes($ordphy)))."',
fldRequestedBy='".strtoupper(strip_tags(addslashes($_REQUEST['requester'])))."',
fldProcedure1='".(strip_tags(addslashes($_REQUEST['procedure1'])))."',
fldProcedure2='".(strip_tags(addslashes($_REQUEST['procedure2'])))."',
fldProcedure3='".(strip_tags(addslashes($_REQUEST['procedure3'])))."',
fldProcedure4='".(strip_tags(addslashes($_REQUEST['procedure4'])))."',
fldProcedure5='".(strip_tags(addslashes($_REQUEST['procedure5'])))."',
fldProcedure6='".(strip_tags(addslashes($_REQUEST['procedure6'])))."',
fldplr1='".(strip_tags(addslashes($_REQUEST['plr1'])))."',
fldplr2='".(strip_tags(addslashes($_REQUEST['plr2'])))."',
fldplr3='".(strip_tags(addslashes($_REQUEST['plr3'])))."',
fldplr4='".(strip_tags(addslashes($_REQUEST['plr4'])))."',
fldplr5='".(strip_tags(addslashes($_REQUEST['plr5'])))."',
fldplr6='".(strip_tags(addslashes($_REQUEST['plr6'])))."',
fldSymptom1='".(strip_tags(addslashes($_REQUEST['symptoms1'])))."',
fldSymptom2='".(strip_tags(addslashes($_REQUEST['symptoms2'])))."',
fldSymptom3='".(strip_tags(addslashes($_REQUEST['symptoms3'])))."',
fldSymptom4='".(strip_tags(addslashes($_REQUEST['symptoms4'])))."',
fldSymptom5='".(strip_tags(addslashes($_REQUEST['symptoms5'])))."',
fldSymptom6='".(strip_tags(addslashes($_REQUEST['symptoms6'])))."',
fldPatientroom='".strtoupper(strip_tags(addslashes($_REQUEST['patientroom'])))."',
fldAfterhours='".strtoupper(strip_tags(addslashes($_REQUEST['afterhours'])))."',
fldHistory='".strtoupper(strip_tags(addslashes($_REQUEST['history'])))."',
fldCDRequested='".(strip_tags(addslashes($_REQUEST['cdrequested'])))."',
fldSymptoms='".strtoupper(strip_tags(addslashes($_REQUEST['symptoms'])))."',
fldCDAddr='".strtoupper(strip_tags(addslashes($_REQUEST['cdaddr'])))."',
fldCDDate='".strtoupper(strip_tags(addslashes($cddate)))."',
fldUserName='".strtoupper(strip_tags(addslashes($_SESSION['user'])))."',
fldDate='".strtoupper(strip_tags(addslashes($orddate)))."',
fldCreDate='".strtoupper(strip_tags(addslashes($cretime)))."',
fldDispatched='".strtoupper(strip_tags(addslashes($dispatched)))."',
fldTechnologist='".strtoupper(strip_tags(addslashes($technologist)))."',
created_by = '".$_SESSION['user']."',
created_date = '".date('Y-m-d H:i:s')."'
") or die (mysql_error());
$id =	mysql_insert_id();
$txtid = $id;
$id =   $txtid;

if($sql_insert)
{
$sql_insert_icd	= mysql_query("insert into tblicdcodes set
fldOrderid='".(strip_tags(addslashes($id)))."'
") or die (mysql_error());

if($sql_insert_icd)
{
include "pdf_neworder.php";
}

//////////////////////////
// Read POST request params into global vars
//$to1=$sql_values_fetch['fldEmailSendOrders1'];
//$to2=$sql_values_fetch['fldEmailSendOrders2'];

//$from = "Douglas <dpotter@mdipacs.net>";
//$to=$to1 . ";" . $to2;
//$subject = "MDI Imaging & Reffering Physician - Order";
//$headers = array ('From' => $from,'To' => $to, 'Subject' => $subject);
//$text = "Hi,\r\n\r\nPlease find the attached receipt for Order Placed at MDF Imaging & Referring Physician\r\n\r\nRegards\r\nMDF Imaging & Referring Physician";
//$file = $filename; // attachment
//$crlf = "\n";
//  $mime = new Mail_mime($crlf);
//  $mime->setTXTBody($text);
//  $mime->addAttachment($file, 'text/plain');
//  $body = $mime->get();
//  $headers = $mime->headers($headers);
//  $smtp = Mail::factory('smtp', array ('host' => $host, 'auth' => false, 'username' => $username,'password' => $password));
//  $mail = $smtp->send($to, $headers, $body);

//email to facility
//$fac = $_REQUEST['facility'];
//$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tblfacility where fldFacilityName = '$fac'"));
//if($sql_values_fetch['fldEmailOrder'] == 1)
//{
//$to = $sql_values_fetch['fldEmail'];
//$mail = $smtp->send($to, $headers, $body);
//}


$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tblsettings"));
$txtdest=$sql_values_fetch['flddmwl'];

$stringData0 = "[RecordNum1] \r";
$stringData0 .= "Patient Name = " . $_REQUEST['lastname'] . "\t^" . $_REQUEST['firstname'] . "\r";
$stringData0 .= "Patient ID = " . $pid . "\r";

$stringData0 .= "Date of Birth = " . $newdob . "\r";
$stringData0 .= "Additional Patient History = " . $_REQUEST['history'] . "\r";
$stemp = $_REQUEST['sex'];
if ($stemp == 'male')
{
$txtsex = 'M';
}
if ($stemp == 'female')
{
$txtsex = 'F';
}
$stringData0 .= "Sex = " . $txtsex. "\r";
function formatDatez($dDate){
$dNewDate = strtotime($dDate);
return date('Ymd-His',$dNewDate);
}

$stringData1 = "Referring Physician = " . $ordphy . "\r";
$stringData1 .= "Scheduled AE Station = crvan \r";

$schdate = date('Y-m-d',strtotime(formatdate($_REQUEST['schdate12']) . ' ' . $_REQUEST['schdate22']));
$schtime = date('H:i',strtotime(formatdate($_REQUEST['schdate12']) . ' ' . $_REQUEST['schdate22']));
$stringData2 = "Scheduled Start Date = " . $schdate . "\r";
$stringData2 .= "Scheduled Start Time = " . $schtime . "\r";

$dob = $_REQUEST['dob'];
$sDate = split('-', $dob);
$sDate1 = $sDate[2].$sDate[0].$sDate[1];
$hi7_dob=$sDate1;


$hi7dest="hi7/";
$hi7_time=date("mdY",time());

$hi7_1="MSH|^~\&|Ig bu|MDImaging|Test|MD Imaging|";
$hi7_2 .="||ORM^O01|00000";
$hi7_2 .=$hi7_time;
$hi7_2 .="|P|2.3|||NE|NE" . "\r";
$hi7_2 .="PID|";
$hi7_2 .=$pid;
$hi7_2 .="|";
$hi7_2 .=$pid;
$hi7_2 .="|";
$hi7_2 .=$pid;
$hi7_21 =$_REQUEST['lastname'] . "^" . $_REQUEST['firstname'] . "^" . $_REQUEST['middlename'] . "^" . $_REQUEST['surname'];
$hi7_21 .="||";
$hi7_21 .=$hi7_dob;
$hi7_21 .="|";
$hi7_21 .=$txtsex;
$hi7_21 .="||U|||||U|||000-00-0000" . "\r";
$hi7_21 .="PV1|";
$hi7_21 .=$pid;
$hi7_21 .="|O|BUF^^buffalo^MDImaging||||Referring|";
$hi7_21 .=$ordphy . "\r";
$hi7_21 .="ORC|SC|";
$hi7_3 .="|S||^^^";
$hi7_3 .=$hi7_time;
$hi7_3 .="^^N||||||||||||||MD Imaging" . "\r";
$hi7_3 .="OBR|1|";

$pr1 = $_REQUEST['procedure1'];
if($pr1)
{
$myFile = $txtdest . $txtid . "p1.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr1'"));
$atime=date("Y-m-d H:i:s",time() + 1);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno1='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " . $_REQUEST['symptoms1'] . "\r" . $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r";
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr1'] . " " . $_REQUEST['procedure1'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr1'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr1'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms1'];

fwrite($fh, $hi7_txt);
fclose($fh);
}

$pr2 = $_REQUEST['procedure2'];
if($pr2)
{
$myFile = $txtdest . $txtid . "p2.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr2'"));
$atime=date("Y-m-d H:i:s",time() + 2);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno2='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " .$_REQUEST['symptoms2'] . "\r" . $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r" ;
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr2'] . " " . $_REQUEST['procedure2'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "-2||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr2'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr2'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms2'];

fwrite($fh, $hi7_txt);
fclose($fh);
}

$pr3 = $_REQUEST['procedure3'];
if($pr3)
{
$myFile = $txtdest . $txtid . "p3.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr3'"));
$atime=date("Y-m-d H:i:s",time() + 3);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno3='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " .$_REQUEST['symptoms3'] . "\r" .  $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r" ;
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr3'] . " " . $_REQUEST['procedure3'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "-3||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr3'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr3'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms3'];

fwrite($fh, $hi7_txt);
fclose($fh);
}

$pr4 = $_REQUEST['procedure4'];
if($pr4)
{
$myFile = $txtdest . $txtid . "p4.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr4'"));
$atime=date("Y-m-d H:i:s",time() + 4);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno4='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " .$_REQUEST['symptoms4'] . "\r" .  $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r" ;
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr4'] . " " . $_REQUEST['procedure4'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "-4||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr4'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr4'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms4'];

fwrite($fh, $hi7_txt);
fclose($fh);
}

$pr5 = $_REQUEST['procedure5'];
if($pr5)
{
$myFile = $txtdest . $txtid . "p5.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr5'"));
$atime=date("Y-m-d H:i:s",time() + 5);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno5='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " .$_REQUEST['symptoms5'] . "\r" .  $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r" ;
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr5'] . " " . $_REQUEST['procedure5'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "-5||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr5'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr5'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms5'];

fwrite($fh, $hi7_txt);
fclose($fh);
}

$pr6 = $_REQUEST['procedure6'];
if($pr6)
{
$myFile = $txtdest . $txtid . "p6.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr6'"));
$atime=date("Y-m-d H:i:s",time() + 6);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno6='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " .$_REQUEST['symptoms6'] . "\r" .  $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r" ;
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr6'] . " " . $_REQUEST['procedure6'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");

$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "-6||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr6'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr6'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms6'];

fwrite($fh, $hi6_txt);
fclose($fh);
}

$redirecturl = "index.php?pg=20";
header("location:".$redirecturl);

}
}
?>

