ALTER TABLE `tblorderdetails` ADD `fldpps` VARCHAR( 5 ) NOT NULL ,
ADD `fldSign` BOOL NOT NULL 