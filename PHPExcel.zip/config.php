<?php # PMD 2012-01-17

$servername='localhost'; // MySql Server Name or IP address
$dbusername='root';      // Login user id
$dbpassword='!mdi634';   // Login password
$dbname='order1';    // database name

# OVERRIDE
$dbname='order1';    // database name


function connecttodb($servername,$dbname,$dbuser,$dbpassword)
{
	global $link;
	$link = mysql_connect ("$servername","$dbuser","$dbpassword");
	if( !$link ) die ("Could not connect to MySQL");
	mysql_select_db("$dbname",$link) or die ("could not open db".mysql_error());
}

connecttodb($servername,$dbname,$dbusername,$dbpassword);

// Order DB Name & Table Name
$host1="root";
$table1="order1";

// Archive DB Name & Table Name
$host2="root";
$table2="pacsone1";

//row perpage of site
define('FRONT_END_ROW_PER_PAGE', 50);

//number of link display in page
define('WEBSITE_DEFAULT_NUMBER_LINK', 20);

define('OVER_DST' , false);

function getCurrentDate($role, $userState)
{
	if(OVER_DST == false) return date('Y-m-d H:i:s');

	if($role == 'admin') $userState = 'AZ';

	if($userState == 'AZ') return date('Y-m-d H:i:s');

	//CO
	return date('Y-m-d H:i:s', strtotime('+1 hour'));
}