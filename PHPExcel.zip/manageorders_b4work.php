<? # PMD 2012-01-23
// if session is not set redirect the user
if(empty($_SESSION['user']))
header("Location:index.php");
include 'config.php';
header('Refresh: 120');
$user=$_SESSION['user'];
include('ps_pagination.php');
if($_SESSION['role'] =='biller') {
$redirecturl = "?pg=55";
header("Location:".$redirecturl);
}
?>
<script type="text/javascript">
function search_prompt() {
    var retVal=""
    var valReturned;
    retVal=showModalDialog('searchpop1.html');
    valReturned=retVal;
    location.replace(valReturned);
}
</script>
<?
if(isset($_GET['d']))
{
$div=$_GET['d'];
}
else {
$div="%";
}

$user = $_SESSION['user'];
$facility=$_SESSION['facility'];
$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tbluser where fldUserName='$user'"));
$orphy=$sql_values_fetch['fldRealName'];
$facid=$sql_values_fetch['fldID'];

function formatDate($dDate){
$dNewDate = strtotime($dDate);
return date('Y-m-d H:i',$dNewDate);
}
$curtime=date("Y-m-d",time());
$curdate=formatdate($curtime);

if( $_REQUEST['action'] =="ESignAllSelected"){
    $selected_orders = $_REQUEST['selected_orders'];

    foreach( $selected_orders as $orderid ){
        $sql = "UPDATE tblorderdetails SET fldAuthorized='1',fldAuthDate=now() WHERE fldID = '$orderid'";
        $c = mysql_query($sql);
    }
}

$userState = $_SESSION['userState'];

$selectField = "select tblorderdetails.fldID,
                    tblorderdetails.fldFacilityName,
                    fldSchDate,
                    fldOrderingPhysicians,
                    fldAuthorized,
                    tblorderdetails.fldTechnologist,
                    fldDate,
                    fldAfterhours,
					fldTechComplete,
                    fldStat,
                    fldDispatched,
                    fldPatientID,
                    fldLastName,
                    fldFirstName,
                    fldProcedure1,
                    fldProcedure2,
                    fldProcedure3,
                    fldProcedure4,
                    fldProcedure5,
                    fldProcedure6,
                    fldplr1,
                    fldplr2,
                    fldplr3,
                    fldplr4,
                    fldplr5,
                    fldplr6,
                    fldRequestedBy,
                    fldVerbal,
                    fldCoded,
                    fldException1,
                    fldException2,
                    fldException3,
					fldStation,
                    fldDOB ";

$sql ='';
//SonIT add
//if orderingphysician
if($_SESSION['role'] =='orderingphysician')
{
    //we just build slq for orderingphysician, LOL, i just copy from current code
    //we don't need copy code from this to that, LOL. Just check not set all var -> default
    if(!isset($_GET['all']) || $_GET['all']=='all') {
        $sql = "$selectField
                from tblorderdetails
                        INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                where fldOrderingPhysicians = '$orphy' AND fldAuthorized = '0' order by ";

    }
    else if($_GET['all']=='week') {

        $stdate=date('c',strtotime(date('Y')."W".date('W')."0"));
        $etdate=date('c',strtotime(date('Y')."W".date('W')."7"));
        $sdate = strftime("%Y-%m-%d", strtotime($stdate));
        $edate = strftime("%Y-%m-%d", strtotime($etdate));

        $sdate .=" 00:00:00";
        $edate .=" 23:59:59";
        $sql = "$selectField
                from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                where fldOrderingPhysicians = '$orphy' and fldSchDate >= '$sdate' and fldSchDate <= '$edate' AND fldAuthorized = '0' order by ";
    }
    else if($_GET['all']=='month') {

        $curtime=date("Y-m-d",time());
        $sDate = split('-', $curtime);
        $num = cal_days_in_month(CAL_GREGORIAN, $sDate[1], $sDate[0]) ;
        $stdate=$sDate[0].'-'.$sDate[1].'-01 00:00:00';
        $enddate=$sDate[0].'-'.$sDate[1].'-'.$num. ' 23:59:59';

        $sql = "$selectField
                from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                where fldOrderingPhysicians = '$orphy' and fldSchDate >= '$stdate' and fldSchDate <= '$enddate' AND fldAuthorized = '0' order by ";
    }
    else if($_GET['all']=='nondis') {

        $sql = "$selectField
                from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                where fldOrderingPhysicians = '$orphy' AND fldAuthorized = '0'  AND fldDispatched=0 order by ";
    }
    else{
        $sql = "select tblorderdetails.fldID, tblorderdetails.fldFacilityName, fldSchDate, fldOrderingPhysicians, fldAuthorized, fldTechnologist, fldDate, fldAfterhours, fldStat, fldDispatched, fldPatientID, fldLastName, fldFirstName, fldProcedure1, fldProcedure2, fldProcedure3, fldProcedure4, fldProcedure5, fldProcedure6, fldplr1, fldplr2, fldplr3, fldplr4, fldplr5, fldplr6,  fldRequestedBy, fldVerbal,fldCoded, fldException1, fldException2, fldException3,fldDOB
                from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                where fldOrderingPhysicians = '$orphy' AND fldAuthorized = '0' order by ";
    }

}
else
{

    //keep current process
    //we don't need remove line check
    //if($_SESSION['role'] =='orderingphysician')
    //$sql = "...";
    // in case we use it in future, leave it now.

    if($_GET['all']=='all') {
        if($_SESSION['role'] =='admin')
        $sql = "$selectField
                from tblorderdetails
                where tblorderdetails.fldFacilityName in (select fldFacilityName from tblfacility where fldDivisionName LIKE '$div') order by ";

        if($_SESSION['role'] =='dispatcher' || $_SESSION['role'] =='coder')
        $sql = "$selectField
                from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                where tblorderdetails.fldFacilityName in (select fldFacilityName from tblfacility where fldDivisionName LIKE '$div') order by ";

        if($_SESSION['role'] =='facilityuser')
        {
            $sql = "$selectField
                            from tblorderdetails
                            INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                            INNER JOIN tbluserfacdetails
                                ON tblorderdetails.fldFacilityName = tbluserfacdetails.fldFacility AND tbluserfacdetails.flduserid = '$facid'
                            order by ";

        }

        if($_SESSION['role'] =='orderingphysician')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where fldOrderingPhysicians = '$orphy' AND fldAuthorized = '0' order by ";

        if($_SESSION['role'] =='technologist')
            $sql = "$selectField
                    from tblorderdetails
                        INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where tblorderdetails.fldTechnologist = '$user' order by ";
    }
    else if($_GET['all']=='week') {

        $stdate=date('c',strtotime(date('Y')."W".date('W')."0"));
        $etdate=date('c',strtotime(date('Y')."W".date('W')."7"));
        $sdate = strftime("%Y-%m-%d", strtotime($stdate));
        $edate = strftime("%Y-%m-%d", strtotime($etdate));

        $sdate .=" 00:00:00";
        $edate .=" 23:59:59";

        if($_SESSION['role'] =='admin')
            $sql = "$selectField
                    from tblorderdetails
                    where fldSchDate >= '$sdate' and fldSchDate <= '$edate' and tblorderdetails.fldFacilityName in (select fldFacilityName from tblfacility where fldDivisionName LIKE '$div') order by ";

        if($_SESSION['role'] =='dispatcher'  || $_SESSION['role'] =='coder')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where fldSchDate >= '$sdate' and fldSchDate <= '$edate' and tblorderdetails.fldFacilityName in (select fldFacilityName from tblfacility where fldDivisionName LIKE '$div') order by ";

        if($_SESSION['role'] =='facilityuser')
            $sql = "$selectField
                                from tblorderdetails
                                INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                                    AND tblfacility.fldAddressState = '$userState'
                                INNER JOIN tbluserfacdetails ON tblorderdetails.fldFacilityName = tbluserfacdetails.fldFacility AND tbluserfacdetails.flduserid = '$facid'
                                WHERE fldSchDate >= '$sdate' and fldSchDate <= '$edate' order by ";

        if($_SESSION['role'] =='orderingphysician')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where fldOrderingPhysicians = '$orphy' and fldSchDate >= '$sdate' and fldSchDate <= '$edate' AND fldAuthorized = '0' order by ";

        if($_SESSION['role'] =='technologist')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where tblorderdetails.fldTechnologist = '$user' and fldSchDate >= '$sdate' and fldSchDate <= '$edate' order by ";
    }
    else if($_GET['all']=='month') {

        $curtime=date("Y-m-d",time());
        $sDate = split('-', $curtime);
        $num = cal_days_in_month(CAL_GREGORIAN, $sDate[1], $sDate[0]) ;
        $stdate=$sDate[0].'-'.$sDate[1].'-01 00:00:00';
        $enddate=$sDate[0].'-'.$sDate[1].'-'.$num. ' 23:59:59';

        if($_SESSION['role'] =='admin')
            $sql = "$selectField
                    from tblorderdetails
                    where fldSchDate >= '$stdate' and fldSchDate <= '$enddate' and tblorderdetails.fldFacilityName in (select fldFacilityName from tblfacility where fldDivisionName LIKE '$div') order by ";

        if($_SESSION['role'] =='dispatcher'  || $_SESSION['role'] =='coder')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where fldSchDate >= '$stdate' and fldSchDate <= '$enddate' and tblorderdetails.fldFacilityName in (select fldFacilityName from tblfacility where fldDivisionName LIKE '$div') order by ";


        if($_SESSION['role'] =='facilityuser')
            $sql = "$selectField
                                from tblorderdetails
                                INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                                    AND tblfacility.fldAddressState = '$userState'
                                INNER JOIN tbluserfacdetails
                                    ON tblorderdetails.fldFacilityName = tbluserfacdetails.fldFacility AND tbluserfacdetails.flduserid = '$facid'
                                WHERE fldSchDate >= '$stdate' and fldSchDate <= '$enddate' order by ";

        if($_SESSION['role'] =='orderingphysician')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where fldOrderingPhysicians = '$orphy' and fldSchDate >= '$stdate' and fldSchDate <= '$enddate' AND fldAuthorized = '0' order by ";

        if($_SESSION['role'] =='technologist')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where tblorderdetails.fldTechnologist = '$user' and fldSchDate >= '$stdate' and fldSchDate <= '$enddate' order by ";
    }
    else if($_GET['all']=='nondis') {

        $curtime=date("Y-m-d",time());
        $sDate = split('-', $curtime);
        $num = cal_days_in_month(CAL_GREGORIAN, $sDate[1], $sDate[0]) ;
        $stdate=$sDate[0].'-'.$sDate[1].'-01 00:00:00';
        $enddate=$sDate[0].'-'.$sDate[1].'-'.$num. ' 23:59:59';

        if($_SESSION['role'] =='admin')
            $sql = "$selectField
                    from tblorderdetails
                    where fldDispatched=0 and fldFacilityName in (select fldFacilityName from tblfacility where fldDivisionName LIKE '$div') order by ";

        if($_SESSION['role'] =='dispatcher'  || $_SESSION['role'] =='coder')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where fldDispatched=0 and tblorderdetails.fldFacilityName in (select fldFacilityName from tblfacility where fldDivisionName LIKE '$div') order by ";

        if($_SESSION['role'] =='facilityuser')
            $sql = "$selectField
                                from tblorderdetails
                                INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                                AND tblfacility.fldAddressState = '$userState'
                                INNER JOIN tbluserfacdetails
                                    ON tblorderdetails.fldFacilityName = tbluserfacdetails.fldFacility AND tbluserfacdetails.flduserid = '$facid'
                                WHERE fldDispatched=0 order by ";

        if($_SESSION['role'] =='orderingphysician')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where fldOrderingPhysicians = '$orphy' AND fldAuthorized = '0'  AND fldDispatched=0 order by ";

        if($_SESSION['role'] =='technologist')
            $sql = "$$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where tblorderdetails.fldTechnologist = '$user' AND fldDispatched=0 order by ";
    }
    else {
        $stdate=$curtime.' 00:00:00';
        $enddate=$curtime.' 23:59:59';
        if($_SESSION['role'] =='admin')
            $sql = "$selectField
                    from tblorderdetails
                    where fldSchDate >= '$stdate' and fldSchDate <= '$enddate' and tblorderdetails.fldFacilityName in (select fldFacilityName from tblfacility where fldDivisionName LIKE '$div') order by ";

        if($_SESSION['role'] =='dispatcher'  || $_SESSION['role'] =='coder')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                                AND tblfacility.fldAddressState = '$userState'
                    where fldSchDate >= '$stdate' and fldSchDate <= '$enddate' and tblorderdetails.fldFacilityName in (select fldFacilityName from tblfacility where fldDivisionName LIKE '$div') order by ";

        if($_SESSION['role'] =='facilityuser')
            $sql = "$selectField
                                from tblorderdetails
                                INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                                AND tblfacility.fldAddressState = '$userState'
                                INNER JOIN tbluserfacdetails
                                    ON tblorderdetails.fldFacilityName = tbluserfacdetails.fldFacility AND tbluserfacdetails.flduserid = '$facid'
                                WHERE fldSchDate >= '$stdate' and fldSchDate <= '$enddate' order by ";

        if($_SESSION['role'] =='orderingphysician')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where fldOrderingPhysicians = '$orphy' and fldSchDate >= '$stdate' and fldSchDate <= '$enddate' AND fldAuthorized = '0' order by ";

        if($_SESSION['role'] =='technologist')
            $sql = "$selectField
                    from tblorderdetails
                    INNER JOIN tblfacility ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
                            AND tblfacility.fldAddressState = '$userState'
                    where tblorderdetails.fldTechnologist = '$user' and fldSchDate >= '$stdate' and fldSchDate <= '$enddate' order by ";
    }

}//end if
?>
<link href='tablesort.css'  rel="stylesheet" type="text/css" />
<link href="paginate.css"   rel="stylesheet" type="text/css" />

<style>
.fdtablePaginatorWrapTop { display:none; }
</style>
<script type="text/javascript">
function show_confirm()
{
var r=confirm("Are you sure you want  to delete this Order");
if (r==true)
  {
  return true;
  }
else
  {
  return false;
  }
}
function unselectCheckall(){
    document.getElementById("checkAllCheckbox").checked=false;
}
function selectAll(){
    var x=document.getElementsByName('selected_orders[]');
    var status = document.getElementById("checkAllCheckbox").checked;
    for(i=0;i<x.length;i++){
        x[i].checked = status;
    }
}
function selectAllButton(){
    document.getElementById("checkAllCheckbox").checked = true;
    selectAll();
}
function eSignAll(){
    if(confirm("Are you sure you want  to E-Sign all selected orders?") ){
        var args;
        var x=document.getElementsByName('selected_orders[]');
        for(i=0;i<x.length;i++){
            if(x[i].checked == true ){
                args +="&selected_orders[]="+x[i].value;
            }
        }
        window.location.href="index.php?pg=20&action=ESignAllSelected&"+args;
    }
}
</script>

<form action="" method="post">

<?
    if($_REQUEST['val']=="0")
    {
    $sql .= "fldDate";
    }
    else if($_REQUEST['val']=="1")
    {
    $sql .= "fldSchDate";
    }
    else if($_REQUEST['val']=="2")
    {
    $sql .= "fldPatientID";
    }
    else if($_REQUEST['val']=="3")
    {
    $sql .= "fldLastName,fldFirstName";
    }
    else if($_REQUEST['val']=="4")
    {
    $sql .= "fldProcedure1, fldProcedure2, fldProcedure3, fldProcedure1";
    }
    else if($_REQUEST['val']=="5")
    {
    $sql .= "fldOrderingPhysicians";
    }
    else if($_REQUEST['val']=="6")
    {
    $sql .= "fldRequestedBy";
    }
    else if($_REQUEST['val']=="7")
    {
    $sql .= "fldFacilityName, fldStation";
    }
    else if($_REQUEST['val']=="8")
    {
    $sql .= "fldDOB";
    }
    else
    {
        //$sql .= "fldSchDate";
        $sql .= "fldDispatched, fldExamDate, fldSchDate ";
    }

    if($_REQUEST['ord']=="2")
    {
    $sql .= " desc";
    }

    $ord=$_REQUEST['ord'];
    if($ord=="")
    {
    $ord="1";
    }
    else if($ord=="1")
    {
    $ord="2";
    }
    else if($ord=="2")
    {
    $ord="1";
    }
    $all=$_REQUEST['all'];

    //var_dump($_SESSION);
    //echo $sql;


    $conn = mysql_connect('localhost', $host1, '!mdi634');
    mysql_select_db($dbname,$conn);
//  mysql_select_db($table1,$conn);



    $res = mysql_query($sql) or die (mysql_error());
    $num = mysql_num_rows($res);

    $pgr = "pg=20&all=" . $all . "&val=0&ord=2";

    $pager = new PS_Pagination($conn, $sql, 25, 5, $pgr);

    if(empty($_GET['all']) || $_GET['page']=='all') {
    $pager = new PS_Pagination($conn, $sql, $num, 5, $pgr);
    }
    $rs = $pager->paginate();
?>
<table id="orders" width="1050px" aligh="left" cellpadding="0" cellspacing="0" border="0">
<thead>
  <tr>
    <th width="7%" class="sortable-text"><a href="index.php?pg=20&all=<?=$all?>&page=1&val=0&ord=<?=$ord?>">Date</a></th>
    <th width="7%" class="sortable-text"><a href="index.php?pg=20&all=<?=$all?>&page=1&val=1&ord=<?=$ord?>">Exam Date</a></th>
    <th width="6%" class="sortable-text"><a href="index.php?pg=20&all=<?=$all?>&page=1&val=2&ord=<?=$ord?>">Patient ID</a></th>
    <th width="8%" class="sortable-text"><a href="index.php?pg=20&all=<?=$all?>&page=1&val=3&ord=<?=$ord?>">Patient Name</a></th>
    <th width="9%" class="sortable-text"> <a href="index.php?pg=20&all=<?=$all?>&page=1&val=4&ord=<?=$ord?>">Procedure</a></th>
    <th width="10%" class="sortable-text"><a href="index.php?pg=20&all=<?=$all?>&page=1&val=5&ord=<?=$ord?>">Ordering Physician</a></th>
    <th width="10%" class="sortable-text"><a href="index.php?pg=20&all=<?=$all?>&page=1&val=6&ord=<?=$ord?>">Ordered By</a></th>
    <th width="8%" class="sortable-text"><a href="index.php?pg=20&all=<?=$all?>&page=1&val=7&ord=<?=$ord?>">Facility</a></th>
    <? if($_SESSION['role'] =='orderingphysician') { ?>
    <th width="6%" class="sortable-text"><a href="index.php?pg=20&all=<?=$all?>&page=1&val=8&ord=<?=$ord?>">DOB</a></th>
    <th width="6%"><input type='checkbox' id='checkAllCheckbox' name='checkall' onClick='selectAll();'></th>
    <? } ?>
    <? if($_SESSION['role'] =='admin'  || $_SESSION['role'] =='dispatcher') { ?>
    <th width="6%">&nbsp;</th>
    <? } ?>
    <? //if($_SESSION['role'] =='admin'  || $_SESSION['role'] =='dispatcher' || $_SESSION['role'] =='technologist') { ?>
    <th width="12%" colspan="2"><input name="retrive" type="button" onclick="search_prompt()" value="Search" /></th>
    <? //} ?>
    <th colspan="3" align="center" valign="middle"><div align="right">
      <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="https://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="105" height="23">
        <param name="movie" value="button1.swf" />
        <param name="quality" value="high" />
        <param name="bgcolor" value="#CAE8EA" />
        <embed src="button1.swf" quality="high" pluginspage="https://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="105" height="23" bgcolor="#CAE8EA"></embed>
      </object>
    </div></th>
    </tr>
    <?  if($_SESSION['role'] =='admin' || $_SESSION['role'] =='dispatcher' || $_SESSION['role'] =='coder')
    { ?>
    <tr>
    <th colspan="2">&nbsp;</th>
    <th colspan="2">Select Division Name</th>
    <th colspan="4">
       <select name="divisionname" id="divisionname" class="myselect3">
       <option selected="selected" value="">Select</option>
       <?
       $sql="SELECT distinct fldDivisionName FROM tblfacility order by fldDivisionName";
     $result = mysql_query($sql);
     while($row = mysql_fetch_array($result))
     {?>
       <option value="<?=$row['fldDivisionName']?>"><?=$row['fldDivisionName']?></option>
       <? } ?>
     </select>
    </th>
    <th colspan="6"><input name="div" id="div" type="submit" value="Load" /></th>
    </tr>
     <? } ?>
 </thead>
<?
if(!$num)
{
?>
<tbody>
  <tr><td colspan="14" class="total" height="50">No Records Found</td></tr>
</tbody></table>
<?
}
else
{
?>
 <tbody>
  <? while($row = mysql_fetch_assoc($rs)) { ?>
          <?
          if($row['fldTechComplete'] == 1)
          {
          $tdclass = "blackbold";
          }
		  else if($row['fldAfterhours'] == 0 && $row['fldStat'] == 0 && $row['fldDispatched'] == 0 && $row['fldAuthorized'] == 1)
          {
          $tdclass = "blue";
          }
          else if($row['fldAfterhours'] == 0 && $row['fldStat'] == 0 && $row['fldDispatched'] == 0 && $row['fldAuthorized'] == 0)
          {
          $tdclass = "bluebold";
          }
          else if($row['fldAfterhours'] == 0 && $row['fldStat'] == 0 && $row['fldDispatched'] == 1 && $row['fldAuthorized'] == 0)
          {
          $tdclass = "green";
          }
          else if($row['fldAfterhours'] == 0 && $row['fldStat'] == 0 && $row['fldDispatched'] == 1 && $row['fldAuthorized'] == 1)
          {
          $tdclass = "greenbold";
          }
          else if($row['fldStat'] == 1 && $row['fldDispatched'] == 0 && $row['fldAuthorized'] == 0)
          {
          $tdclass = "redbold";
          }
          else if($row['fldStat'] == 1 && $row['fldDispatched'] == 0 && $row['fldAuthorized'] == 1)
          {
          $tdclass = "red";
          }
          else if($row['fldDispatched'] == 1 && $row['fldStat'] == 1 && $row['fldAuthorized'] == 0)
          {
          $tdclass = "orangebold";
          }
          else if($row['fldDispatched'] == 1 && $row['fldStat'] == 1 && $row['fldAuthorized'] == 1)
          {
          $tdclass = "orange";
          }

          for($i=1;$i<7;$i++){
            if( $row['fldProcedure'.$i]){
                $sql = "SELECT * FROM tblproceduremanagment WHERE fldDescription='".$row['fldProcedure'.$i]."'";
                $result = mysql_query($sql);
                $dt = mysql_fetch_assoc($result);
                $row['fldCBTCode'.$i] = $dt['fldCBTCode'];
                $dt = '';
            }
          }
        preg_match("/(\d\d\d\d)\-(\d\d)\-(\d\d)/", $row['fldDOB'], $matches);
        $row['fldDOB'] = $matches[2]."-".$matches[3]."-".$matches[1];
          ?>
     <tr>
        <td class="<? echo $tdclass;?>"><?echo strftime("%m-%d-%Y %H:%M", strtotime($row['fldDate']));?></td>
        <td class="<? echo $tdclass;?>"><?echo strftime("%m-%d-%Y %H:%M", strtotime($row['fldSchDate']));?></td>
        <td class="<? echo $tdclass;?>"><?=$row['fldPatientID']?></td>
        <td class="<? echo $tdclass;?>"><?=$row['fldLastName']?>, <?=$row['fldFirstName']?></td>
        <td class="<? echo $tdclass;?>"><?=$row['fldProcedure1']?> , <?=$row['fldplr1'];?>
        <? if($row['fldProcedure2']!='') { ?> <br /><?=$row['fldProcedure2']?> , <?=$row['fldplr2']; } ?>
        <? if($row['fldProcedure3']!='') { ?> <br /><?=$row['fldProcedure3']?> , <?=$row['fldplr3']; } ?>
        <? if($row['fldProcedure4']!='') { ?> <br /><?=$row['fldProcedure4']?> , <?=$row['fldplr4']; } ?>
        <? if($row['fldProcedure5']!='') { ?> <br /><?=$row['fldProcedure5']?> , <?=$row['fldplr5']; } ?>
        <? if($row['fldProcedure6']!='') { ?> <br /><?=$row['fldProcedure6']?> , <?=$row['fldplr6']; } ?>
        </td>
        <td class="<? echo $tdclass;?>"><?=strtoupper($row['fldOrderingPhysicians'])?></td>
        <td class="<? echo $tdclass;?>"><?=$row['fldRequestedBy']?></td>
        <td class="<? echo $tdclass;?>"><?=$row['fldFacilityName']."-".$row['fldStation']; ?></td>
        <? if($_SESSION['role'] =='orderingphysician') { ?>
            <td width="6%" class="<? echo $tdclass;?>"><?=$row['fldDOB']?></td>
            <td width="6%" class="<? echo $tdclass;?>"><input type='checkbox' name='selected_orders[]' value='<?=$row['fldID']?>' onClick='unselectCheckall();'></td>
        <? } ?>
        <td class="<? echo $tdclass;?>">
            <?php
                if($_SESSION['role'] =='admin' || $_SESSION['role'] =='coder')
                {
                    if($row['fldAuthorized'] == '0')
                    {
                        echo '<a href="index.php?pg=21&id='.$row['fldID'].'">Edit</a>'; // is this field name correct ?
                    }
                    elseif($row['fldAuthorized'] == '1')
                    {
                        echo 'E-Signed / <a href="index.php?pg=30&id='.$row['fldID'].'">Edit</a>';
                    }
                }
            ?>
            <?php
                if($_SESSION['role'] =='dispatcher'|| $_SESSION['role'] =='technologist' || $_SESSION['role'] =='facilityuser')
                {
                    if($row['fldAuthorized'] == '0')
                    {
                        echo '<a href="index.php?pg=21&id='.$row['fldID'].'">Edit</a>'; // is this field name correct ?
                    }
                    elseif($row['fldAuthorized'] == '1')
                    {
                        echo 'E-Signed';
                    }
                }
            ?>

        </td>

<? if($_SESSION['role'] =='admin' || $_SESSION['role'] =='dispatcher' || $_SESSION['role'] =='technologist') { ?>
    <td width="6%" class="<? echo $tdclass;?>">
    <?
        if($row['fldVerbal'] == '1')
        {
        ?>Called In / <a class="<? echo $tdclass;?>" href="index.php?pg=31&id=<?=$row['fldID']?>">Verbal</a>
        <? }
        else if($row['fldVerbal'] == '2')
        {
        ?>Received / <a class="<? echo $tdclass;?>" href="index.php?pg=31&id=<?=$row['fldID']?>">Verbal</a>
        <?
        }
            else
            { ?>
            <a class="<? echo $tdclass;?>" href="index.php?pg=27&id=<?=$row['fldID']?>">Verbal</a>
            <? } ?>
    </td>
<? } ?>

<? if($_SESSION['role'] =='coder') { ?>
    <td width="6%" class="<? echo $tdclass;?>">
    <? if($row['fldCoded'] == '1')
    { ?>Coded
    <? } else { ?>
    <a class="<? echo $tdclass;?>" href="index.php?pg=28&id=<?=$row['fldID']?>">Not Coded</a>
    <? } ?>
    </td>
<? } ?>

<? if($_SESSION['role'] =='orderingphysician') { ?>
    <td width="6%" class="<? echo $tdclass;?>">
    <a class="<? echo $tdclass;?>" href="index.php?pg=22&id=<?=$row['fldID']?>">E-Sign</a>
    </td>
<? } ?>

<? if($_SESSION['role'] =='admin' || $_SESSION['role'] =='dispatcher') { ?>
    <td width="6%" class="<? echo $tdclass;?>">
    <? if($row['fldDispatched'] == '1')
    { ?>
    <?=$row['fldTechnologist']?> / <a class="<? echo $tdclass;?>" href="index.php?pg=26&id=<?=$row['fldID']?>">Undispatch</a>
    <? } else { ?>
    <a class="<? echo $tdclass;?>" href="index.php?pg=25&id=<?=$row['fldID']?>">Dispatch</a>
    <? } ?>
    </td>
<? } ?>
<? if($_SESSION['role'] =='facilityuser') { ?>
    <td width="6%" class="<? echo $tdclass;?>">
    <?
    if($row['fldDispatched'] == 1)
    { ?>
    <?=$row['fldTechnologist']?>
    <? } else { ?>
    To be Dispatched
    <? } ?>
    </td>
<? } ?>


<td class="<? echo $tdclass;?>"><a class="<? echo $tdclass;?>" href="index.php?pg=<?if($_SESSION['role'] =='admin' || $_SESSION['role'] =='coder'){?>29<?} else {?>22<?}?>&id=<?=$row['fldID']?>">Details</a></td>


<? if($_SESSION['role'] =='admin' || $_SESSION['role'] =='dispatcher' || $_SESSION['role'] =='technologist' || $_SESSION['role'] =='facilityuser') {
$exp='';
if($row['fldException1']!='' && $row['fldException2']=='')
$exp='';
else if($row['fldException1']!='' && $row['fldException2']!='' && $row['fldException3']=='')
$exp='';
else if($row['fldException3']!='')
$exp='';
?>
    <td class="<? echo $tdclass;?>"><?=$exp?></td>
<?
}
if($_SESSION['role'] =='admin' || $_SESSION['role'] =='dispatcher' || $_SESSION['role'] =='technologist') {
?>
    <td class="<? echo $tdclass;?>">
    <a class="<? echo $tdclass;?>" href="index.php?pg=24&id=<?=$row['fldID']?>" onclick="return show_confirm()" value="Delete Confirmation">Delete</a>
    </td>
<? } ?>

    </tr>
    <? } ?>
<? if($_SESSION['role'] =='orderingphysician') { ?>
<tr>
    <td colspan="13" align="right"><input type="button" value='Select All' onClick="selectAllButton();"><input type="button" name='action' value='E-Sign All Selected' onClick="eSignAll();"></td>
<tr>
<? } ?>
  </tbody>
</table>
<? echo $pager->renderFullNav() . $pager->renderAll(); } ?>
</form>
<table height="10" border="0"><tr><td class="nb">&nbsp;</td></tr></table>
<?
if($_REQUEST['submit']!='')
{
$redirecturl = "index.php?pg=21";
header("location:".$redirecturl);
}
if($_REQUEST['div']!='')
{
$div=$_REQUEST['divisionname'];
$redirecturl = $_SERVER['HTTP_REFERER'];
$redirecturl .='&d=' . $div;
header("Location:".$redirecturl);
}
?>

