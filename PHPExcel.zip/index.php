<?php # pmd 2011-02-01
$debugflag = $_REQUEST['debug'];
#$debugflag = false;
if ( $debugflag )
{
	error_reporting(E_ALL);
	ini_set('display_errors', '1');
}
session_start();
ob_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<title>MD Imaging</title>
<link href="menu/menu_style.css" rel="stylesheet" type="text/css">
<link href="style.css" rel="stylesheet" type="text/css">
<link href="redmond/jquery-ui-1.8.6.custom.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.6/jquery-ui.min.js" type="text/javascript"></script>
<script type="text/javascript" src="map_images/jquery.blockUI.js"></script>
<script type="text/javascript" src="common.js"></script>
<style>
#wrapper {
	width:1050px;
	margin:1px auto;
	border:0px solid #bbb;
	padding:0px;
}
#top1 {
  background: url(top.png);
  position: absolute;
  top: 0px;
  left: 0px;
  width: 76px;
  height: 22px;
  padding-left:5px;
}
#top2 {
  background: url(top.png);
  position: absolute;
  top: 0px;
  left: 76px;
  width: 910px;
  height: 22px;
  vertical-align:middle;
}
#top2a {
  position: absolute;
  top: 5px;
  left: 0px;
  width: 910px;
  height: 17px;
  vertical-align:middle;
}
#top3 {
  background: url(top.png);
  position: absolute;
  left: 986px;
  top: 0px;
  width: 64px;
  height: 22px;
}

#header1 {
  background: url(bg.png);
  position: absolute;
  top: 22px;
  vertical-align: top;
  left: 0px;
  width: 500px;
  height: 79px;
}

#header2 {
  background: url(bg.png);
  position: absolute;
  top: 22px;
  left: 500px;
  width: 550px;
  height: 79px;
}

#menuad {
  background: url(main.png);
  position: absolute;
  top: 101px;
  left: 0px;
  text-align: left;
  width: 1050px;
  <? if($_SESSION['role'] =='admin') { ?>
  height: 40px;
  <? } else { ?>
  height: 25px;
  <? } ?>
}

#content {
  position: absolute;
  <? if($_SESSION['role'] =='admin') { ?>
  top: 141px;
  <? } else { ?>
  top: 126px;
  <? } ?>
  left: 0px;
  width: 1050px;
  height: auto;
}
#footer {
  background: url(top.png);
  position: absolute;
  top: auto;
  left: 0px;
  width: 1050px;
  height: 22px;
}
HR {
page-break-after: always;
}
</style>
</head>
<body>
<div id="wrapper">
<div id="top1">
	<img src="home.png" border="0" usemap="#Map" />
	<map name="Map">
		<area shape="rect" coords="3,3,46,19" href="index.php?pg=20">
	</map>
</div>
<div id="top2">
	<?php
		require_once 'top_nav.php';
	?>
</div>

<div id="top3"><a href="logout.php"><img src="logout.png" border="0" /></a></div>
<div id="header1"><img src="logo.png" align="left"/> <!-- 6:45 PM 8/27/2009--> </div>

<div class="header2" id="header2">
  <div align="center" class="banner">
    <blockquote>
      <p align="right"></p>
      </blockquote>
  </div>
</div>

<? if( $_SESSION['role'] == 'admin' )
{
?>
<div id="menuad">
<script src="menujs.js" type="text/javascript"></script>
<noscript><OBJECT id="menuobj" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="https://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" WIDTH=1050 HEIGHT=45>
 <PARAM NAME=movie VALUE="menu.swf">
 <PARAM NAME=menu VALUE=false>
 <PARAM NAME=quality VALUE=high>
 <PARAM NAME=bgcolor VALUE=#DDE6EA>
 <EMBED src="menu.swf" menu=false quality=high bgcolor=#DDE6EA  WIDTH=1050 HEIGHT=45 TYPE="application/x-shockwave-flash" PLUGINSPAGE="https://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash">
 </EMBED>
 </OBJECT>
 </noscript>
</div>
<?
}
else
{
?>
<div id="menuad">
<div class="menu"><ul><li>
<?
if( $_REQUEST['pg'] == "20" && !isset($_GET['all']) ) { ?>
<a href="index.php?pg=20&all=all" style="color:#fff;text-decoration:none; padding-left:10px;align: left;" align="left"> Show All</a>
<? } ?>
<? if( $_REQUEST['pg'] == "20" && isset($_GET['all']) ) { ?>
<a href="index.php?pg=20" style="color:#fff;text-decoration:none; padding-left:10px;align: left;" align="left"> Today</a>
<? } ?>
</li></ul></div></div>
<? } ?>
<div id="content">
<?
if($_REQUEST['pg']=="")
{
	if(empty($_SESSION['user'])) include_once "login.php";
	else include_once "manageorders.php";
}
if($_REQUEST['pg']=="1") include_once "createusers.php";
if($_REQUEST['pg']=="2") include_once "listusers.php";
if($_REQUEST['pg']=="3")
{
	$id = $_REQUEST['id'];
	include_once "editusers.php";
}
if($_REQUEST['pg']=="4")
{
	$id=$_REQUEST['id'];
	include_once "deleteusers.php";
}
if($_REQUEST['pg']=="5") include_once "emailmanagment.php";
if($_REQUEST['pg']=="6") include_once "pdfmanagment.php";
if($_REQUEST['pg']=="7") include_once "dbmanagment.php";
if($_REQUEST['pg']=="8") include_once "createprocedure.php";
if($_REQUEST['pg']=="9") include_once "listprocedure.php";
if($_REQUEST['pg']=="10")
{
	$id=$_REQUEST['id'];
	include_once "editprocedure.php";
}
if($_REQUEST['pg']=="11")
{
	$id=$_REQUEST['id'];
	include_once "deleteprocedure.php";
}
if($_REQUEST['pg']=="12") include_once "createfacility.php";
if($_REQUEST['pg']=="13") include_once "listfacility.php";
if($_REQUEST['pg']=="14")
{
	$id=$_REQUEST['id'];
	include_once "editfacility.php";
}
if($_REQUEST['pg']=="15")
{
	$id=$_REQUEST['id'];
	include_once "deletefacility.php";
}
if($_REQUEST['pg']=="16") include_once "addlist.php";
if($_REQUEST['pg']=="17") include_once "viewlists.php";
if($_REQUEST['pg']=="18")
{
	$id=$_REQUEST['id'];
	include_once "editlist.php";
}
if($_REQUEST['pg']=="19")
{
	$id=$_REQUEST['id'];
	include_once "deletelist.php";
}
if($_REQUEST['pg']=="20")
{
 header("Location: manageorders_new.php");
 die;
}
if($_REQUEST['pg']=="21")
{
	$id=$_REQUEST['id'];
	include_once "createorders.php";
}
if($_REQUEST['pg']=="22")
{
	$id=$_REQUEST['id'];
	include_once "authorizeorder.php";
}
if($_REQUEST['pg']=="23")
{
	$id=$_REQUEST['id'];
	include_once "editorders.php";
}
if($_REQUEST['pg']=="24")
{
	$id=$_REQUEST['id'];
	include_once "deleteorders.php";
}
if($_REQUEST['pg']=="25")
{
	$id=$_REQUEST['id'];
	include_once "dispatch.php";
}
if($_REQUEST['pg']=="26")
{
	$id=$_REQUEST['id'];
	include_once "undispatch.php";
}
if($_REQUEST['pg']=="27")
{
	$id=$_REQUEST['id'];
	include_once "verbal.php";
}
if($_REQUEST['pg']=="28")
{
	$id=$_REQUEST['id'];
	include_once "code.php";
}
if($_REQUEST['pg']=="29")
{
	$id=$_REQUEST['id'];
	include_once "orderdetails.php";
}
if($_REQUEST['pg']=="30")
{
	$id=$_REQUEST['id'];
	include_once "editorders1.php";
}
if($_REQUEST['pg']=="31")
{
	$id=$_REQUEST['id'];
	include_once "verbal.php";
}
if($_REQUEST['pg']=="32")
{
	$keyw=$_REQUEST['srch'];
	$key=strtoupper($keyw);
	$keyword=$_REQUEST['keyword'];
	include_once "searchres.php";
}
if($_REQUEST['pg']=="33")
{
	$keyw=$_REQUEST['srch'];
	$key=strtoupper($keyw);
	$keyword=$_REQUEST['keyword'];
	include_once "searchres1.php";
}
if($_REQUEST['pg']=="34") include_once "legend.php";
if($_REQUEST['pg']=="35")
{
	$d=$_REQUEST['d'];
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "appmnts.php";
}
if($_REQUEST['pg']=="36") include_once "reports.php";
if($_REQUEST['pg']=="37") include_once "appmnts_main.php";
if($_REQUEST['pg']=="38") include_once "mdet_main.php";
if($_REQUEST['pg']=="39") include_once "msum_main.php";
if($_REQUEST['pg']=="40")
{
	$d=$_REQUEST['d'];
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "mdet.php";
}
if($_REQUEST['pg']=="41") include_once "msum.php";
if($_REQUEST['pg']=="42") include_once "createneworders.php";
if($_REQUEST['pg']=="43") include_once "changepwd.php";
if($_REQUEST['pg']=="44") include_once "techrep_main.php";
if($_REQUEST['pg']=="45") include_once "facrep_main.php";
if($_REQUEST['pg']=="46")
{
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "fac_report.php";
}
if($_REQUEST['pg']=="47")
{
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "tech_report.php";
}
if($_REQUEST['pg']=="48") include_once "exception.php";
if($_REQUEST['pg']=="49") include_once "cdreq_main.php";
if($_REQUEST['pg']=="50")
{
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "cdreq_report.php";
}
if($_REQUEST['pg']=="51") include_once "parta_main.php";
if($_REQUEST['pg']=="52")
{
	$d=$_REQUEST['d'];
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "partarpt.php";
}
if($_REQUEST['pg']=="53") include_once "callrpt_main.php";
if($_REQUEST['pg']=="54")
{
	$d=$_REQUEST['d'];
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "callrpt.php";
}
if($_REQUEST['pg']=="55") include_once "billing.php";
if($_REQUEST['pg']=="56")
{
	$d=$_REQUEST['d'];
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "billingdet.php";
}
if($_REQUEST['pg']=="57") include_once "billpay.php";
if($_REQUEST['pg']=="58") include_once "facinvoice_main.php";
if($_REQUEST['pg']=="59")
{
	$d=$_REQUEST['d'];
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "facinvoice.php";
}
if($_REQUEST['pg']=="60")
{
	$d=$_REQUEST['d'];
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "facinvoice.php";
}
if($_REQUEST['pg']=="61") include_once "admin_fac_main.php";
if($_REQUEST['pg']=="62")
{
	$d=$_REQUEST['d'];
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "admin_fac.php";
}
if($_REQUEST['pg']=="63") include_once "facexp_main.php";
if($_REQUEST['pg']=="64")
{
	$d=$_REQUEST['d'];
	$dt1=$_REQUEST['dt1'];
	$dt2=$_REQUEST['dt2'];
	include_once "facexp.php";
}
if($_REQUEST['pg']=="65") include_once "admin_exp_main.php";
if($_REQUEST['pg']=="66") include_once "FTR_main.php";
if($_REQUEST['pg']=="67") include_once "Forgotpassword.php";
if($_REQUEST['pg']=="71")
{
	$id=$_REQUEST['id'];
	include_once "createorders2.php";
}
if($_REQUEST['pg']=="72") include_once "dispatch_board.php";
if($_REQUEST['pg']=="73") include_once "facdisplay.php";
if($_REQUEST['pg']=="74") include_once "physicianmgt.php";
?>
</div>
</div>
</body>
</html>

