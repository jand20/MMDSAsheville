<?php session_start();
// if session is not set redirect the user
if(empty($_SESSION['user']))
header("Location:index.php");
include "config.php";
$sql_values_fetch =	mysql_fetch_array(mysql_query("select * from tblorderdetails where fldID='$id'"));
?>
<script type="text/javascript">
function open_win()
{
<?
$sql_values_fetch_pdf =	mysql_fetch_array(mysql_query("select * from tblsettings"));
	if($sql_values_fetch['fldAuthorized'] == 1)
	{
	$dest=$sql_values_fetch_pdf['fldPDFSignedOrders'];
	$pdate=$sql_values_fetch['fldAuthDate'];
	$sign="s";
	}
	else
	{
	$dest=$sql_values_fetch_pdf['fldPDFUnsignedOrders'];
	$pdate=$sql_values_fetch['fldCreDate'];
	$sign="u";
	}

$filename = $dest . $sign . $pdate . $sql_values_fetch['fldLastName'] . $sql_values_fetch['fldFirstName'] . "_" . $id . ".pdf";
?>
window.open("<?echo $filename; ?>")
}
</script>
<link href="style.css" rel="stylesheet" type="text/css" />
<form action="" method="post">
<table width="1050" border="0" cellpadding="0" cellspacing="0" background="main.png">
  <tr>
    <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <?
		  $time=date("Y-m-d H:i",time());
		  function formatDate11($dDate){
		  if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
		      return '';
			}
		  $dNewDate = strtotime($dDate);
		  return date('m-d-Y',$dNewDate);
		  }
		  function formatDate12($dDate){
		  if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
		      return '';
			}
		  $dNewDate = strtotime($dDate);
		  return date('H:i',$dNewDate);
		  }
		  $orddate = $time;
		  $time11=formatdate11($orddate);
		  $time12=formatdate12($orddate);
          ?>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td class="lab">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td width="9%"><span class="lab">Today Date</span></td>
            <td width="16%"><span class="dis">
              <?echo date('m-d-Y' ,strtotime($sql_values_fetch['fldDate']));?>
              </span></td>
            <td width="13%" class="lab">Today Time </td>
            <td width="31%"><span class="dis">
              <?echo date('g:i A' ,strtotime($sql_values_fetch['fldDate']));?>
            </span></td>
            <td width="6%">&nbsp;</td>
            <td width="25%">&nbsp;</td>
          </tr>

        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

          <tr>
            <td width="9%"><span class="lab">Last name</span></td>
            <td width="16%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldLastName'])?>
            </span></td>
            <td width="13%"><span class="lab">First name</span></td>
            <td width="17%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldFirstName'])?>
            </span></td>
            <td width="9%"><span class="lab">Middle name</span></td>
            <td width="17%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldMiddleName'])?>
            </span></td>
            <td width="6%"><span class="lab">Jr, Sr, II</span></td>
            <td width="13%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldSurName'])?>
            </span></td>
          </tr>
          <tr>
            <td class="lab">Patient MR# </td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPatientID'])?>
            </span></td>
            <?
	 		function formatDateddmmyy($dDate){
	 		if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
			    return '';
			}
			$dNewDate = strtotime($dDate);
			return date('m-d-Y',$dNewDate);
			}
			$ddob="MM-DD-YYYY";
			$fdob = $sql_values_fetch['fldDOB'];
			if($fdob!='')
			{
			$ddob = formatDateddmmyy($fdob);
			}
			?>
            <td><span class="lab">DOB (MM-DD-YYYY)</span></td>
            <td><span class="dis">
              <?=$ddob?>
            </span></td>
            <td><span class="lab">Patient SSN</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPatientSSN'])?>
            </span></td>
            <td><span class="lab">Sex</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldGender'])?>
            </span></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Contact</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldRequestedBy'])?>
            </span></td>
            <td width="9%"><span class="lab">Facility Name </span></td>
            <td colspan="5"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldFacilityName'])?>
            </span></td>
            <td class="lab"> Phone </td>
            <td colspan="2" class="lab"><div id="txtHint"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldFacPhone'])
			?>
            </span></div></td>
            </tr>
          <tr>
            <td width="7%"><span class="lab">Room #</span></td>
            <td width="15%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPatientroom'])?>
            </span></td>
            <td><span class="lab">Urgent/Normal</span></td>
            <td width="8%"><span class="dis">
              <? if($sql_values_fetch['fldStat'] == 1) {?>
              URGENT
              <? } else { ?>
              NORMAL
              <? } ?>
            </span></td>
            <td width="9%"><span class="lab">After Hours</span></td>
            <td width="9%"><span class="dis">
              <? if($sql_values_fetch['fldAfterhours'] == 1) {?>
YES
<? } else { ?>
NO
<? } ?>
            </span></td>
            <td width="12%"><span class="lab">Date Exam needed: </span></td>
            <td width="9%"><span class="dis">
              <?echo date('m-d-Y' ,strtotime($sql_values_fetch['fldSchDate']));?>
            </span></td>
			<td width="12%"><span class="lab">Time exam needed</span></td>
            <td width="10%"><span class="dis">
              <?echo date('g:i A' ,strtotime($sql_values_fetch['fldSchDate']));?>
            </span></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="10%"><span class="lab">Procedure #1</span></td>
            <td width="24%"><span class="lab"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldProcedure1'])?>
            </span>
              <label></label>
            </span></td>
            <td width="8%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldplr1'])?>
            </span></td>
            <td width="7%"><span class="lab">Symptom </span></td>
            <td width="26%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldSymptom1'])?>
            </span></td>
            <td width="5%" class="lab">Ac No :</td>
            <td width="20%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldacsno1'])?>
            </span></td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #2</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldProcedure2'])?>
            </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldplr2'])?>
            </span></td>
            <td><span class="lab">Symptom </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldSymptom2'])?>
            </span></td>
            <td><span class="lab">Ac No :</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldacsno2'])?>
            </span></td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #3</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldProcedure3'])?>
            </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldplr3'])?>
            </span></td>
            <td><span class="lab">Symptom </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldSymptom3'])?>
            </span></td>
            <td><span class="lab">Ac No :</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldacsno3'])?>
            </span></td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #4</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldProcedure4'])?>
            </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldplr4'])?>
            </span></td>
            <td><span class="lab">Symptom </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldSymptom4'])?>
            </span></td>
            <td><span class="lab">Ac No :</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldacsno4'])?>
            </span></td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #5</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldProcedure5'])?>
            </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldplr5'])?>
            </span></td>
            <td><span class="lab">Symptom </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldSymptom5'])?>
            </span></td>
            <td><span class="lab">Ac No :</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldacsno5'])?>
            </span></td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #6</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldProcedure6'])?>
            </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldplr6'])?>
            </span></td>
            <td><span class="lab">Symptom </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldSymptom6'])?>
            </span></td>
            <td><span class="lab">Ac No :</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldacsno6'])?>
            </span></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Additional Patient Info</span></td>
          </tr>
          <tr>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldSymptoms'])?>
            </span></td>
          </tr>
          <tr>
            <td><span class="lab">History:</span></td>
          </tr>
          <tr>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldHistory'])?>
            </span></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="9%"><span class="lab">Referring Dr. </span></td>
            <td colspan="6" width="62%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldOrderingPhysicians'])?>
            </span></td>
            <?
		  $time=date("Y-m-d H:i",time());
		  function formatDate21($dDate){
		  $dNewDate = strtotime($dDate);
		  return date('m-d-Y',$dNewDate);
		  }
		  function formatDate22($dDate){
		  $dNewDate = strtotime($dDate);
		  return date('H:i',$dNewDate);
		  }
		  $schdte=$sql_values_fetch['fldSchDate'];
		  $time11=formatdate21($schdte);
		  $time12=formatdate22($schdte);
		  $cddte=$sql_values_fetch['fldCDDate'];
		  $cddate=formatdate21($cddte);
		  $refph=$sql_values_fetch['fldOrderingPhysicians'];
		  $sql_user=mysql_fetch_array(mysql_query("SELECT * FROM tbluser where fldRealName='$refph'"));
		  $phyph=$sql_user['fldPhone'];
		  ?>
            <td><span class="lab">Phone : </span></td>
            <td><span class="dis">
              <?=strtoupper($phyph)?>
            </span></td>
          </tr>
          <tr>
            <td class="lab">CD Needed ? </td>
            <td width="12%"><span class="dis">
              <? if($sql_values_fetch['fldCDRequested'] == 1) {?>
              YES
              <? } else { ?>
              NO
              <? } ?>
            </span></td>
            <? if($sql_values_fetch['fldCDRequested'] == 1) {?>
            <td width="7%"><span class="lab">Location</span></td>
            <td colspan="4"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldCDAddr'])?>
            </span></td>
            <td width="10%" class="lab">Date CD needed </td>
            <td width="14%"><span class="dis">
              <?=strtoupper($cddate)?>
            </span></td>
            <? }
            else
            { ?>
            <td colspan="7">&nbsp;</td>
            <? } ?>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Insurance Type</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldInsurance'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td width="13%"><span class="lab">Medicare #</span></td>
            <td width="28%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldMedicareNumber'])?>
            </span></td>
            <td width="8%"><span class="lab">Medicaid #</span></td>
            <td width="24%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldMedicaidNumber'])?>
            </span></td>
            <td width="6%"><span class="lab">State #</span></td>
            <td width="21%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldState'])?>
            </span></td>
          </tr>
          <tr>
            <td><span class="lab">Insurance Company </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldInsuranceCompanyName'])?>
            </span></td>
            <td><span class="lab">Policy #</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPolicy'])?>
            </span></td>
            <td><span class="lab">Group #</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldGroup'])?>
            </span></td>
          </tr>
          <tr>
            <td><span class="lab">HMO Name/Contract </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldHmoContract'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>

        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="13%"><span class="lab">Responsible Party:</span></td>
            <td width="28%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldResponsiblePerson'])?>
            </span></td>
            <td width="8%"><span class="lab">Relationship</span></td>
            <td width="51%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldRelationship'])?>
            </span></td>
          </tr>
          <tr>
            <td><span class="lab">Address #1</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivateAddressLine1'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Address #2 </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivateAddressLine2'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">City</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivateAddressCity'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">State </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivateAddressState'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Zip</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivateAddressZip'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Phone #</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivatePhoneNumber'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
	  <tr>

        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="13%"><span class="lab">Verbal Date</span></td>
            <td width="18%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldReportDate'])?>
            </span></td>
            <td width="12%"><span class="lab">Report Called To</span></td>
            <td width="22%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldReportCalledTo'])?>
            </span></td>
            <td width="9%"><span class="lab">Report Details</span></td>
            <td width="26%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldReportDetails'])?>
            </span></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="5%"><span class="lab">Email</span></td>
            <td width="62%"><input type="text" name="temail" />
              <input name="email" type="submit" id="email" value="Email" /></td>
            <td width="33%">&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan="3"><input type="checkbox" name="confirmbox" />
This Patient would find it physically and/or psychologically taxing because of advanced age and/or physical limitations to receive an X-ray or EKG outside this location. This test is medically necessary for the diagnosis and treatment of this patient.</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>
		<table align="center">
		<tr>
    	<td align="center">
		<? if($_SESSION['role'] =='orderingphysician') { ?>
		<input type="submit" name="submit" value="E-Sign">
		<? } else { ?>
		<input type="submit" name="back" value="Back" />
		<? } ?>	</td>
    <td align="center"><input type="button" name="print" value="Print" onclick="window.print()" ></td>
	<td align="center"><input type="button" name="pdf" value="PDF" onclick="open_win()" /></td>
        </tr></table>		</td>
      </tr>
      <tr>
        <td>	  </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
<?php
if($_REQUEST['back']!='')
{
$redirecturl = "index.php?pg=20";
header("location:".$redirecturl);
}
if($_REQUEST['email']!='')
{
$sql_values_fetch_pdf =	mysql_fetch_array(mysql_query("select * from tblsettings"));
	if($sql_values_fetch['fldAuthorized'] == 1)
	{
	$dest=$sql_values_fetch_pdf['fldPDFSignedOrders'];
	$pdate=$sql_values_fetch['fldAuthDate'];
	$sign="s";
	}
	else
	{
	$dest=$sql_values_fetch_pdf['fldPDFUnsignedOrders'];
	$pdate=$sql_values_fetch['fldCreDate'];
	$sign="u";
	}

$filename = $dest . $sign . $pdate . $sql_values_fetch['fldLastName'] . $sql_values_fetch['fldFirstName'] . "_" . $id . ".pdf";

// Read POST request params into global vars
$to=$_REQUEST['temail'];

function mail_attachment($filename, $path, $mailto, $from_mail, $from_name, $replyto, $subject, $message) {
    $file = $path.$filename;
    $file_size = filesize($file);
    $handle = fopen($file, "r");
    $content = fread($handle, $file_size);
    fclose($handle);
    $content = chunk_split(base64_encode($content));
    $uid = md5(uniqid(time()));
    $name = basename($file);
    $header = "From: ".$from_name." <".$from_mail.">\r\n";
    $header .= "Reply-To: ".$replyto."\r\n";
    $header .= "MIME-Version: 1.0\r\n";
    $header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";
    $header .= "This is a multi-part message in MIME format.\r\n";
    $header .= "--".$uid."\r\n";
    $header .= "Content-type:text/plain; charset=iso-8859-1\r\n";
    $header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $header .= $message."\r\n\r\n";
    $header .= "--".$uid."\r\n";
    $header .= "Content-Type: application/octet-stream; name=\"".$filename."\"\r\n"; // use diff. tyoes here
    $header .= "Content-Transfer-Encoding: base64\r\n";
    $header .= "Content-Disposition: attachment; filename=\"".$filename."\"\r\n\r\n";
    $header .= $content."\r\n\r\n";
    $header .= "--".$uid."--";
    if (mail($mailto, $subject, "", $header)) {
        //echo "mail send ... OK"; // or use booleans here
    } else {
        //echo "mail send ... ERROR!";
    }
}
// how to use
$my_file = $filename; //"test.pdf"
$my_mail = "manigce@gmail.com";
$my_replyto = "manigce@gmail.com";

$my_name = "MDI Imaging - Reffering Physician";
$my_subject = "MDI Imaging & Reffering Physician - Order";
$my_message = "Hi,\r\n\r\nPlease find the Copy of your Order. \r\n\r\nRegards\r\nMDF Imaging & Referring Physician";
mail_attachment($my_file, $dest, $to, $my_mail, $my_name, $my_replyto, $my_subject, $my_message);
}
if($_REQUEST['submit']!='')
{
$cretime=date("Y-m-d",time());
$sql_insert	= mysql_query("update tblorderdetails set fldAuthorized=1,fldCreDate='".strip_tags(addslashes($cretime))."' where fldID='".$id."'");
if($sql_insert)
{

require('fpdf/html_table.php');

$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tblorderdetails where fldID='$id'"));
$orddate=$sql_values_fetch['fldDate'];
$time=date("Y-m-d H:i",time());
function formatDate21x($dDate){
if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
    return '';
}
$dNewDate = strtotime($dDate);
return date('d-m-Y',$dNewDate);
}
function formatDate22x($dDate){
if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
    return '';
}
$dNewDate = strtotime($dDate);
return date('H:i',$dNewDate);
}
$time11=formatdate21x($orddate);
$time12=formatdate22x($orddate);
$rperson=$sql_values_fetch['fldRequestedBy'];
$facility = $sql_values_fetch['fldFacilityName'];
$phone=$sql_values_fetch['fldPhone'];
$fname = $sql_values_fetch['fldFirstName'];
$lname = $sql_values_fetch['fldLastName'];
$mname=$sql_values_fetch['fldMiddleName'];
$sname=$sql_values_fetch['fldSurName'];
$patientid=$sql_values_fetch['fldPatientID'];
$sDate1 = $sql_values_fetch['fldDOB'];
$sDate2 = split('-', $sDate1);
$dob = $sDate2[1].'-'.$sDate2[2].'-'.$sDate2[0];

$ssn=$sql_values_fetch['fldPatientSSN'];
$gender=$sql_values_fetch['fldGender'];
$room=$sql_values_fetch['fldPatientroom'];
$urgent="No";
if($sql_values_fetch['fldStat']==1)
{
$urgent="Yes";
}
$afterhours="No";
if($sql_values_fetch['fldAfterhours']==1)
{
$afterhours="Yes";
}
$symptom1=$sql_values_fetch['fldSymptom1'];
$symptom2=$sql_values_fetch['fldSymptom2'];
$symptom3=$sql_values_fetch['fldSymptom3'];
$symptom4=$sql_values_fetch['fldSymptom4'];
$symptom5=$sql_values_fetch['fldSymptom5'];
$symptom6=$sql_values_fetch['fldSymptom6'];
$plr1=$sql_values_fetch['fldplr1'];
$plr2=$sql_values_fetch['fldplr2'];
$plr3=$sql_values_fetch['fldplr3'];
$plr4=$sql_values_fetch['fldplr4'];
$plr5=$sql_values_fetch['fldplr5'];
$plr6=$sql_values_fetch['fldplr6'];
$additionalinfo=$sql_values_fetch['fldSymptoms'];
$history=$sql_values_fetch['fldHistory'];
$physician=$sql_values_fetch['fldOrderingPhysicians'];
function formatDate1a($dDate){
if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
    return '';
}
$dNewDate = strtotime($dDate);
return date('m-d-Y',$dNewDate);
}
function formatDate1b($dDate){
if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
    return '';
}
$dNewDate = strtotime($dDate);
return date('H:i',$dNewDate);
}
$schdte=$sql_values_fetch['fldSchDate'];
$shdate=formatdate1a($schdte);
//$sDate1 = $shdate;
//$sDate2 = split('-', $sDate1);
//$shdate = $sDate2[1].'-'.$sDate2[2].'-'.$sDate2[0];

$shtime=formatdate1b($schdte);
$cdneeded="No";
if($sql_values_fetch['fldCDRequested']==1)
{
$cdneeded="Yes";
}
$cdaddr=$sql_values_fetch['fldCDAddr'];
$medicare=$sql_values_fetch['fldMedicareNumber'];
$medicaid=$sql_values_fetch['fldMedicaidNumber'];
$state=$sql_values_fetch['fldState'];
$inscompany=$sql_values_fetch['fldInsuranceCompanyName'];
$relation=$sql_values_fetch['fldRelationship'];
$addr1=$sql_values_fetch['fldPrivateAddressLine1'];
$addr2=$sql_values_fetch['fldPrivateAddressLine2'];
$addrcity=$sql_values_fetch['fldPrivateAddressCity'];
$addrstate=$sql_values_fetch['fldPrivateAddressState'];
$addrzip=$sql_values_fetch['fldPrivateAddressZip'];
$addrph=$sql_values_fetch['fldPrivatePhoneNumber'];
//$addrphone=substr($addrph, 0, 3)."-".substr($addrph, 3, 3)."-".substr($addrph, 6, 4);
$addrphone=$addrph;
$hmo_contract=$sql_values_fetch['fldHmoContract'];
$policy=$sql_values_fetch['fldPolicy'];
$group=$sql_values_fetch['fldGroup'];
$verbalrep=$sql_values_fetch['fldReportDetails'];
$repdate=$sql_values_fetch['fldReportDate'];
function formatDate1d($dDate){
if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
    return '';
}
$dNewDate = strtotime($dDate);
return date('m-d-Y H:i',$dNewDate);
}
$rpdate=formatdate1d($repdate);
$repcalledto=$sql_values_fetch['fldReportCalledTo'];
$radiologist=$sql_values_fetch['fldRadiologist'];
$noofpatients=$sql_values_fetch['fldVerbalnoofpat'];
$noofviews=$sql_values_fetch['fldnoofviews'];
$examtime=$sql_values_fetch['fldExamDate'];
$cddt=$sql_values_fetch['fldCDDate'];
$cddate=formatdate1a($cddt);



$proc=$sql_values_fetch['fldProcedure1'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt1=$sql_values_fetch_proc['fldCBTCode'];
$pdesc1=$sql_values_fetch_proc['fldDescription'];
$proc=$sql_values_fetch['fldProcedure2'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt2=$sql_values_fetch_proc['fldCBTCode'];
$pdesc2=$sql_values_fetch_proc['fldDescription'];
$proc=$sql_values_fetch['fldProcedure3'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt3=$sql_values_fetch_proc['fldCBTCode'];
$pdesc3=$sql_values_fetch_proc['fldDescription'];
$proc=$sql_values_fetch['fldProcedure4'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt4=$sql_values_fetch_proc['fldCBTCode'];
$pdesc4=$sql_values_fetch_proc['fldDescription'];
$proc=$sql_values_fetch['fldProcedure5'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt5=$sql_values_fetch_proc['fldCBTCode'];
$pdesc5=$sql_values_fetch_proc['fldDescription'];
$proc=$sql_values_fetch['fldProcedure6'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt6=$sql_values_fetch_proc['fldCBTCode'];
$pdesc6=$sql_values_fetch_proc['fldDescription'];

$sql_fac=mysql_fetch_array(mysql_query("SELECT * FROM tblfacility where fldFacilityName='$facility'"));
$facph=$sql_fac['fldPhoneNumber'];
$facphone=$facph;

$sql_user=mysql_fetch_array(mysql_query("SELECT * FROM tbluser where fldRealName='$physician'"));
$phyph=$sql_user['fldPhone'];

$plr1=strtoupper($plr1);
$plr2=strtoupper($plr2);
$plr3=strtoupper($plr3);
$plr4=strtoupper($plr4);
$plr5=strtoupper($plr5);
$plr6=strtoupper($plr6);

$resperson=$sql_values_fetch['fldResponsiblePerson'];
if(!$resperson) $resperson='&nbsp;';

if(!$noofviews) $noofviews='&nbsp;';
if(!$examtime) $examtime='&nbsp;';

if(!$phyph) $phyph='&nbsp;';
if(!$facphone) $facphone='&nbsp;';
if(!$time11) $time11='&nbsp;';
if(!$time12) $time12='&nbsp;';
if(!$rperson) $rperson='&nbsp;';
if(!$facility ) $facility ='&nbsp;';
if(!$phone) $phone='&nbsp;';
if(!$patientid) $patientid='&nbsp;';
if(!$dob) $dob='&nbsp;';
if(!$ssn) $ssn='&nbsp;';
if(!$gender) $gender='&nbsp;';
if(!$room) $room='&nbsp;';
if(!$urgent) $urgent='&nbsp;';
if(!$afterhours) $afterhours='&nbsp;';
if(!$plr1) $plr1='&nbsp;';
if(!$plr2) $plr2='&nbsp;';
if(!$plr3) $plr3='&nbsp;';
if(!$plr4) $plr4='&nbsp;';
if(!$plr5) $plr5='&nbsp;';
if(!$plr6) $plr6='&nbsp;';
if(!$physician) $physician='&nbsp;';
if(!$shdate) $shdate='&nbsp;';
if(!$shtime) $shtime='&nbsp;';
if(!$cdneeded) $cdneeded='&nbsp;';
if(!$cdaddr) $cdaddr='&nbsp;';
if(!$medicare) $medicare='&nbsp;';
if(!$medicaid) $medicaid='&nbsp;';
if(!$state) $state='&nbsp;';
if(!$inscompany) $inscompany='&nbsp;';
if(!$relation) $relation='&nbsp;';
if(!$addr1) $addr1='&nbsp;';
if(!$addr2) $addr2='&nbsp;';
if(!$addrcity) $addrcity='&nbsp;';
if(!$addrstate) $addrstate='&nbsp;';
if(!$addrphone) $addrphone='&nbsp;';
if(!$hmo_contract) $hmo_contract='&nbsp;';
if(!$policy) $policy='&nbsp;';
if(!$group) $group='&nbsp;';
if(!$repdate) $repdate='&nbsp;';
if(!$rpdate) $rpdate='&nbsp;';
if(!$repcalledto) $repcalledto='&nbsp;';
if(!$radiologist) $radiologist='&nbsp;';
if(!$noofpatients) $noofpatients='&nbsp;';
if(!$cbt1) $cbt1='&nbsp;';
if(!$pdesc1) $pdesc1='&nbsp;';
if(!$cbt2) $cbt2='&nbsp;';
if(!$pdesc2) $pdesc2='&nbsp;';
if(!$cbt3) $cbt3='&nbsp;';
if(!$pdesc3) $pdesc3='&nbsp;';
if(!$cbt4) $cbt4='&nbsp;';
if(!$pdesc4) $pdesc4='&nbsp;';
if(!$cbt5) $cbt5='&nbsp;';
if(!$pdesc5) $pdesc5='&nbsp;';
if(!$cbt6) $cbt6='&nbsp;';
if(!$pdesc6) $pdesc6='&nbsp;';
if(!$noofviews) $noofviews='&nbsp;';
if(!$examtime) $examtime='&nbsp;';


$sDate1 = $time11;
$sDate2 = split('-', $sDate1);
$dt1 = $sDate2[1].'-'.$sDate2[0].'-'.$sDate2[2];

$pdf=new PDF();
$pdf->AddPage();

$html='<table border="0">
<tr>
<td width="50" height="30">Date :</td>
<strong><td width="100" height="30">';
$html.=$dt1;
$html.='</td></strong>
<td width="50" height="30">Time :</td>
<strong><td width="100" height="30">';
$html.=$time12;
$html.='</td></strong>
</tr>
<tr>
<td height="10"></td>
</tr>
<tr>
<td width="55" height="30">Facility : </td>
<strong><td width="350" height="30">';
$html.=$facility;
$html.='</td></strong>
<td width="60" height="30">Contact : </td>
<strong><td width="150" height="30">';
$html.=$rperson;
$html.='</td></strong>
<td width="50" height="30">Phone : </td>
<strong><td width="90" height="30">';
$html.=$facphone;
$html.='</td></strong>
</tr>
<tr>
<td width="90" height="30">Patient Name : </td>
<strong><td width="110" height="30">';
$html.=$fname . ' ' . $mname . ' ' . $lname;
$html.='</td></strong>
</tr>
<tr>
<td width="90" height="30">Patient MR#</td>
<strong><td width="90" height="30">';
$html.=$patientid;
$html.='</td></strong>
<td width="40" height="30">DOB : </td>
<strong><td width="150" height="30">';
$html.=$dob;
$html.='</td></strong>
<td width="40" height="30">SSN# </td>
<strong><td width="180" height="30">';
$html.=$ssn;
$html.='</td>
</strong><td width="40" height="30">Sex : </td>
<strong><td width="50" height="30">';
$html.=strtoupper($gender);
$html.='</td></strong>
</tr>
<tr>
<td width="60" height="30">Room# </td>
<strong><td width="80" height="30">';
$html.=$room;
$html.='</td></strong>
<td width="60" height="30">Urgent? </td>
<strong><td width="50" height="30">';
$html.=$urgent;
$html.='</td></strong>
<td width="80" height="30">After hours? </td>
<strong><td width="40" height="30">';
$html.=$afterhours;
$html.='</td></strong>
<td width="120" height="30">Date Exam needed: </td>
<strong><td width="100" height="30">';
$html.=$shdate;
$html.='</td></strong>
<td width="120" height="30">Time exam needed: </td>
<strong><td width="50" height="30">';
$html.=$shtime;
$html.='</td></strong>
</tr>
<tr>
</tr>
<tr>
<td width="90" height="30">Procedure1# </td>
<strong><td width="160" height="30">';
$html.=$pdesc1;
$html.='<td width="90" height="30">';
$html.=$plr1;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom1);
$html.='</td></strong>
</tr>
<td width="90" height="30">Procedure2# </td>
<strong><td width="160" height="30">';
$html.=$pdesc2;
$html.='<td width="90" height="30">';
$html.=$plr2;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom2);
$html.='</td></strong>
</tr>
<td width="90" height="30">Procedure3# </td>
<strong><td width="160" height="30">';
$html.=$pdesc3;
$html.='<td width="90" height="30">';
$html.=$plr3;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom3);
$html.='</td></strong>
</tr>
<td width="90" height="30">Procedure4# </td>
<strong><td width="160" height="30">';
$html.=$pdesc4;
$html.='<td width="90" height="30">';
$html.=$plr4;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom4);
$html.='</td></strong>
</tr>
<td width="90" height="30">Procedure5# </td>
<strong><td width="160" height="30">';
$html.=$pdesc5;
$html.='<td width="90" height="30">';
$html.=$plr5;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom5);
$html.='</td></strong>
</tr>
<td width="90" height="30">Procedure6# </td>
<strong><td width="160" height="30">';
$html.=$pdesc6;
$html.='<td width="90" height="30">';
$html.=$plr6;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom6);
$html.='</td></strong>
</tr>
<tr>
</tr>
</table>';

$html1='<table border="0">
<tr>
<td width="90" height="30">Ordering Dr. </td>
<strong><td width="330" height="30">';
$html1.=$physician;
$html1.='</td></strong>
<td width="50" height="30">Phone# </td>
<strong><td width="250" height="30">';
$html1.=$phyph;
$html1.='</td></strong>
</tr>
<tr>
<td width="90" height="30">CD Needed ? </td>
<strong><td width="75" height="30">';
$html1.=$cdneeded;
if($cdneeded!='No')
{
$html1.='</td></strong>
<td width="60" height="30">Location : </td>
<strong><td width="325" height="30">';
$html1.=$cdaddr;
$html1.='</td></strong>
<td width="100" height="30">Date Needed By : </td>
<strong><td width="80" height="30">';
$html1.=$cddate;
}
$html1.='</td></strong>
</tr>
<tr>
<td width="90" height="30">Medicare# </td>
<strong><td width="330" height="30">';
$html1.=$medicare;
$html1.='</td></strong>
<u><strong><td width="140" height="30">Responsible Party </td></strong></u>
</tr>
<tr>
<td width="90" height="30">Medicaid# </td>
<strong><td width="180" height="30">';
$html1.=$medicaid;
$html1.='</td></strong>
<td width="30" height="30">ST </td>
<strong><td width="120" height="30">';
$html1.=$state;
$html1.='</td></strong>
<td width="140" height="30">Name :</td>
<strong><td width="120" height="30">';
$html1.=$resperson;
$html1.='</td></strong>
</tr>
<tr>
<td width="420" height="30">&nbsp;</td>
<td width="140" height="30">Relationship :</td>
<strong><td width="120" height="30">';
$html1.=$relation;
$html1.='</td></strong>
</tr>
<tr>
<td width="110" height="30">Supplementary Ins :</td>
<strong><td width="310" height="30">';
$html1.=$inscompany;
$html1.='</td></strong>
<td width="140" height="30">Address :</td>
<strong><td width="120" height="30">';
$html1.=$addr1;
$html1.='</td></strong>
</tr>
<tr>
<td width="110" height="30">Policy# </td>
<strong><td width="310" height="30">';
$html1.=$policy;
$html1.='</td></strong>
<td width="140" height="30">&nbsp;</td>
<strong><td width="120" height="30">';
$html1.=$addr2;
$html1.='</td></strong>
</tr>
<tr>
<td width="110" height="30">Group# </td>
<strong><td width="310" height="30">';
$html1.=$group;
$html1.='</td></strong>
<td width="140" height="30">&nbsp;</td>
<strong><td width="120" height="30">';
$html1.=$addrcity;
$html1.='</td></strong>
</tr>
<tr>
<td width="110" height="30">HMO :</td>
<strong><td width="310" height="30">';
$html1.=$hmo_contract;
$html1.='</td></strong>
<td width="140" height="30">&nbsp;</td>
<strong><td width="120" height="30">';
$html1.=$addrstate . "," . $addrzip;
$html1.='</td></strong>
</tr>
<tr>
<td width="420" height="30">&nbsp;</td>
<td width="140" height="30">Phone </td>
<strong><td width="120" height="30">';
$html1.=$addrphone;
$html1.='</td></strong>
</tr>
<tr>
</tr>
<tr>
<td width="560" height="30">I request that payment of authorized Medicare and/or Medigap benefits be made either to me or on my behalf to MD Imaging </td>
</tr>
<tr>
<td width="560" height="30">Services and/or the interpreting physician for any services furnished me by that physician or supplier. I authorize any holder of</td>
</tr>
<tr>
<td width="560" height="30">medical information about me to release to the Center for Medicare and Medicaid Services and its agents any information</td>
</tr>
<tr>
<td width="560" height="30">needed to determine these benefits payable for related services.</td>
</tr>
<tr>
</tr>
<tr>
<u><td width="300" height="30">X                                         </td></u>
<u><td width="220" height="30">X                                         </td></u>
</tr>
<tr>
<td width="300" height="30">Patient Signature</td>
<td width="220" height="30">Nurse�s Signature (if patient unable to sign)</td>
</tr>
<tr>
</tr>
</table>';
$html2='<table border="0">
<tr>
<td width="90" height="30">Time Called in :</td>
<strong><td width="130" height="30">';
$html2.=$rpdate;
$html2.='</td></strong>
<td width="110" height="30">Report Called to :</td>
<strong><td width="110" height="30">';
$html2.=$repcalledto;
$html2.='</td></strong>
<td width="120" height="30">Reading Radiologist :</td>
<strong><td width="110" height="30">';
$html2.=$radiologist;
$html2.='</td></strong>
</tr>
<tr>
<td width="130" height="30"># of Patients this Trip :</td>
<strong><td width="90" height="30">';
$html2.=$noofpatients;
$html2.='</td></strong>
<td width="100" height="30"># of Views Done :</td>
<strong><td width="120" height="30">';
$html2.=$noofviews;
$html2.='</td></strong>
<td width="100" height="30">Time Exam Done :</td>
<strong><td width="50" height="30">';
$examtm=formatdate1b($examtime);
$html2.=$examtm;
$html2.='</td></strong>
</tr>
<tr>
</tr>
</table>';
$pdf->Ln(10);
$pdf->SetFont('Arial','B',20);
$pdf->Cell(110,10,'MD Imaging, Inc.   ',0,0,'C');
$pdf->Ln();
$pdf->SetFont('Arial','B',11);
$pdf->Cell(90,10,'Phone 847-626-0800  Fax 847-626-0817',0,0,'C');
$pdf->Ln(15);
$pdf->SetFont('Arial','',9);
$pdf->WriteHTML($html);
$pdf->Cell(90,10,'Additonal patient Info');
$pdf->Ln(5);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(90,10,$additionalinfo);
$pdf->Ln(10);
$pdf->SetFont('Arial','',9);
$pdf->Cell(90,10,'History');
$pdf->Ln(5);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(90,10,$history);
$pdf->Ln(15);
$pdf->SetFont('Arial','',9);
$pdf->WriteHTML($html1);
$pdf->Cell(90,10,'Verbal Report');
$pdf->Ln(5);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(90,10,$verbalrep);
$pdf->Ln();
$pdf->SetFont('Arial','',9);
$pdf->WriteHTML($html2);

if($sql_values_fetch['fldAuthorized'] == 1)
{
//    $pdf->Cell(105);
//    $pdf->SetFont('Arial','U',10);
//    $pdf->Cell(30,10,'"Electronically Signed"',0,0,'C');
//    $pdf->Ln(5);
//    $pdf->Cell(105);
//    $pdf->SetFont('Arial','I',10);
//    $pdf->Cell(30,10,$physician,0,0,'C');
}

$sql_values_fetch =	mysql_fetch_array(mysql_query("select * from tblsettings"));
$dest=$sql_values_fetch['fldPDFSignedOrders'];
$filename = $dest . "s" . $cretime . $lname . $fname . "_" . $id . ".pdf";
$pdf->Output($filename,'F');

// Read POST request params into global vars
$to1=$sql_values_fetch['fldEmailSignedOrders1'];
$to2=$sql_values_fetch['fldEmailSignedOrders2'];

function mail_attachment($filename, $path, $mailto, $from_mail, $from_name, $replyto, $subject, $message) {
    $file = $path.$filename;
    $file_size = filesize($file);
    $handle = fopen($file, "r");
    $content = fread($handle, $file_size);
    fclose($handle);
    $content = chunk_split(base64_encode($content));
    $uid = md5(uniqid(time()));
    $name = basename($file);
    $header = "From: ".$from_name." <".$from_mail.">\r\n";
    $header .= "Reply-To: ".$replyto."\r\n";
    $header .= "MIME-Version: 1.0\r\n";
    $header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";
    $header .= "This is a multi-part message in MIME format.\r\n";
    $header .= "--".$uid."\r\n";
    $header .= "Content-type:text/plain; charset=iso-8859-1\r\n";
    $header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $header .= $message."\r\n\r\n";
    $header .= "--".$uid."\r\n";
    $header .= "Content-Type: application/octet-stream; name=\"".$filename."\"\r\n"; // use diff. tyoes here
    $header .= "Content-Transfer-Encoding: base64\r\n";
    $header .= "Content-Disposition: attachment; filename=\"".$filename."\"\r\n\r\n";
    $header .= $content."\r\n\r\n";
    $header .= "--".$uid."--";
    if (mail($mailto, $subject, "", $header)) {
        //echo "mail send ... OK"; // or use booleans here
    } else {
        //echo "mail send ... ERROR!";
    }
}
// how to use
$my_file = $filename;
$my_mail = "manigce@gmail.com";
$my_replyto = "manigce@gmail.com";

$my_name = "MDI Imaging - Reffering Physician";
$my_subject = "MDI Imaging & Reffering Physician - Order";
$my_message = "Hi,\r\n\r\nPlease find the Copy of Authorised Order Placed at MDI Imaging and Referring Physician\r\n\r\nRegards\r\nMDF Imaging & Referring Physician";
mail_attachment($my_file, $dest, $to1, $my_mail, $my_name, $my_replyto, $my_subject, $my_message);
mail_attachment($my_file, $dest, $to2, $my_mail, $my_name, $my_replyto, $my_subject, $my_message);
if ($ok) {
$redirecturl = "index.php?pg=20";
header("location:".$redirecturl);
}
else {
$redirecturl = "index.php?";
header("location:".$redirecturl);
}

}
}
?>
