<?php # PMD 2012-01-23
session_start(); // if session is not set redirect the user
if( empty($_SESSION['user']) ) header("Location:index.php");
include "config.php";
include "mod_facfuncs.php";
$row = mysql_fetch_row( mysql_query("SELECT varValue FROM tblsysvar WHERE varName='autodispatch'") );
$autodispatch = $row[0];
$sql_values_fetch = mysql_fetch_array( mysql_query("select * from tblfacility where fldID='$id'") );
?>
<link href="style.css" rel="stylesheet" type="text/css" />
<form action="" method="post" onsubmit="tech();">
<table width="100%" border="0" background="main.png">
  <tr>
    <td width="15%">&nbsp;</td>
    <td width="16%">&nbsp;</td>
    <td width="2%">&nbsp;</td>
    <td width="67%">&nbsp;</td>
  </tr>
    <? if(isset($_GET['msg'])) { $err=$_GET['msg'];?>
    <tr>
        <td colspan="4" height"10"><div align="center" class="war"><?=$err?></div></td>
    </tr>
    <tr>
        <td height="5" colspan="4"></td>
    </tr>
    <? } ?>
 <tr>
    <td>&nbsp;</td>
    <td class="lab">Facility Name</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="facilityname" value="<?=$sql_values_fetch['fldFacilityName']?>"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="lab">Disabled</td>
    <td><strong>:</strong></td>
    <td><input type="checkbox" name="disabled" value="1" <? if($sql_values_fetch['fldFacilityDisabled'] == 1) {?> checked="checked" <? } ?>></td>
  </tr>
  <tr>
    <td height="5" colspan="4"></td>
  </tr>
  <!-- <tr>
    <td>&nbsp;</td>
    <td class="lab">Facility Organizational Type</td>
    <td><strong>:</strong></td>
    <td>
        <select name='facorgtype' id='facorgtype' class='myselect3'>
        <option value=''></option>
        <option value='Skilled'<? if( $sql_values_fetch['fldFacilityOrgType'] == 'Skilled') echo " selected"; ?>>Skilled Nursing</option>
        <option value='Assisted Living'<? if( $sql_values_fetch['fldFacilityOrgType'] == 'SAssisted Living') echo " selected"; ?>>Assisted Living</option>
        <option value='Correctional'<? if( $sql_values_fetch['fldFacilityOrgType'] == 'Correctional') echo " selected"; ?>>Correctional</option>
        <option value='Physician PracticeClinic'<? if( $sql_values_fetch['fldFacilityOrgType'] == 'Physician PracticeClinic') echo " selected"; ?>>Physician Practice Clinic</option>
        <option value='Home Health'<? if( $sql_values_fetch['fldFacilityOrgType'] == 'Home Health') echo " selected"; ?>>Home Health</option>
        </select>
  </tr> -->  
   <tr>
    <td>&nbsp;</td>
    <td class="lab">Facility Type</td>
    <td><strong>:</strong></td>
    <td><? doSelect('facilitytype',$ftypearray,$sql_values_fetch['fldFacilityType'],'myselect2'); ?></td>
  </tr>
  <tr>
    <td height="10" colspan="4"></td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
    <td class="lab">Administrators Name</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="administratorsname" value="<?=$sql_values_fetch['fldAdminName']?>"></td>
  </tr>
  <tr>
    <td height="5" colspan="4"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="lab">Division Name</td>
    <td><strong>:</strong></td>
    <td>
       <select name="divisionname" class="myselect3">
         <option selected="selected" value="">Select</option>
         <?
      $sql="SELECT * FROM tbllists where fldListName = 'division' order by fldValue";
      $result = mysql_query($sql);
      while($row = mysql_fetch_array($result))
       {?>
         <option value="<?=$row['fldValue']?>"<? if($sql_values_fetch['fldDivisionName'] == $row['fldValue']) {?> selected="selected" <? } ?>>
          <?=$row['fldValue']?>
          </option>
         <? } ?>
    </select>
    </td>
  </tr>
  <tr>
    <td height="5" colspan="4"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="lab">Street Address 1</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="streetaddress1" value="<?=$sql_values_fetch['fldAddressLine1']?>"></td>
  </tr>
  <tr>
    <td height="5" colspan="4"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="lab">Street Address 2</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="streetaddress2" value="<?=$sql_values_fetch['fldAddressLine2']?>"></td>
  </tr>
  <tr>
    <td height="5" colspan="4"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="lab">City</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="city" value="<?=$sql_values_fetch['fldAddressCity']?>"></td>
  </tr>
  <tr>
    <td height="5" colspan="4"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="lab">State</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="state" value="<?=$sql_values_fetch['fldAddressState']?>"></td>
  </tr>
  <tr>
    <td height="5" colspan="4"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="lab">Zip Code</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="zipcode" value="<?=$sql_values_fetch['fldAddressZip']?>"></td>
  </tr>
  <tr>
    <td height="5" colspan="4"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="lab">Phone Number</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="phonenumber" value="<?=$sql_values_fetch['fldPhoneNumber']?>"></td>
  </tr>
  <tr>
    <td height="5" colspan="4"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="lab">Fax Number</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="faxnumber" value="<?=$sql_values_fetch['fldFaxNumber']?>"></td>
  </tr>
  <tr>
    <td height="10" colspan="4"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="lab">Email</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="email" value="<?=$sql_values_fetch['fldEmail']?>"></td>
  </tr>
  <tr>
    <td height="10" colspan="4"></td>
  </tr>

  <tr>
    <td>&nbsp;</td>
    <td class="lab">Email Order</td>
    <td><strong>:</strong></td>
    <td><input type="checkbox" name="emailorder" value="1" <? if($sql_values_fetch['fldEmailOrder'] == 1) {?> checked="checked" <? } ?>></td>
  </tr>
  <tr>
    <td height="10" colspan="4"></td>
  </tr>
  
    <tr>
    <td>&nbsp;</td>
    <td class="lab">Main State</td>
    <td><strong>:</strong></td>
    <td>
        <select name='mainstate' id='mainstate' class='myselect6'>
        <option value=''></option><? //remove hard code states; put in loop and check for current settings
       //FIXME
       $sql = "SELECT * FROM tblStates";
       $results = mysql_query($sql);
       
       while($row = mysql_fetch_assoc($results))
       {
           print_r($row);
           ?>
        <option value="<?=$row['fldSt']?>"<?;
        //print_r($sql_values_fetch['fldMainState']);
        if( $sql_values_fetch['fldMainState'] == $row['fldSt']) 
        {
            echo "selected = \"selected\"";
        }
        ?>>
        <?=$row['fldState']?></option>
        <?
        }
        ?></select>
  </tr>
  <tr>
    <td height="10" colspan="4"></td>
  </tr>

  <?php 
if ( $autodispatch == 1 )
{ ?> 
  <tr>
    <td>&nbsp;</td>
    <td class="lab">Auto Dispatch</td>
    <td><strong>:</strong></td>
    <td><input type="checkbox" name="autodis" value="1" <? if($sql_values_fetch['fldAutoDispatch'] == 1) {?> checked="checked" <? } ?>></td>
  </tr>
  <tr>
      <td height="10" colspan="4"></td>
  </tr>
  <tr>
     <td>&nbsp;</td>
     <td class="lab">Select Technologist</td>
     <td><strong>:</strong></td>
     <td><select name="technologist" STYLE="width: 200px">
      <option selected="selected" value="">Select</option>
      <?
      $sql="SELECT * FROM tbluser where fldRole='technologist' AND fldStatus='Enabled' order by fldRealName";
      $result = mysql_query($sql);
      while($row = mysql_fetch_array($result))
      {?>
      <option value="<?=$row['fldUserName']?>"  <? if($sql_values_fetch['fldTechnologist'] == $row['fldUserName']) {?> selected="selected" <? } ?>>
      <?=$row['fldRealName']?>
      </option>
      <? } ?>
     </select></td>
  </tr>
  <tr>
    <td height="10" colspan="4"></td>
  </tr>
  <? 
} ?>


<script language='JavaScript'> 
function openWindow()
{
    window.showModalDialog('facstationpop.php?facID=<? echo $sql_values_fetch['fldID']; ?>');
}
</script>


  <tr>
    <td>&nbsp;</td>
    <td class="lab">Stations</td>
    <td><strong>:</strong></td>
    <td><input type=button value='Stations ...' onclick='openWindow();'>
    </td>
  </tr>
  <tr>
    <td height="10" colspan="4"></td>
  </tr>


    <tr>
    
     <td colspan=3>
      </td>
    
    <tr>
        <td>&nbsp;</td>
        <td class="lab">Billing Contact Name</td>
        <td><strong>:</strong></td>
        <td><input type="text" name="facBillingContact" value="<?=$sql_values_fetch['fldBillingContact']?>"></td>
    </tr>
     <tr>
    <td>&nbsp;</td>
    <td class="lab">Billing Phone #</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="facBillingPhone" value="<?=$sql_values_fetch['fldBillingPhone']?>"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="lab">Billing fax #</td>
    <td><strong>:</strong></td>
    <td><input type="text" name="facBillingFax" value="<?=$sql_values_fetch['fldBillingFax']?>"></td>
  </tr>
  <tr>
        <td>&nbsp;</td>
        <td class="lab">Billing Rep</td>
        <td><strong>:</strong></td>
        <td><input type="text" name="facBillingRep" value="<?=$sql_values_fetch['fldBillingRep']?>"></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td class="lab">Billing Account #</td>
        <td><strong>:</strong></td>
        <td><input type="text" name="facBillingAccNum" value="<?=$sql_values_fetch['fldBillingAccNum']?>"></td>
    </tr>
  
  
  <tr>
    <td>&nbsp;</td>
    <td><br></td>
    <td>&nbsp;</td>
    <td><input type="submit" name="submit" value="Update"></td>
  </tr>
  <tr>
    <td height="10" colspan="4"></td>
  </tr>

</table>
</form>

<?php
// Getting Values from the registration to create Master Account
if( $_REQUEST['submit'] !=  ''  )
{
    $autodis = 0 ;
    if ( isset($_REQUEST['autodis']) ) $autodis = 1;
    if( $autodis == 1 && $_REQUEST['technologist']=='')
    {
        header("Location: index.php?pg=14&id=$id&msg=Please Select Technologist");
        exit();
    }

    function phone_number($sPhone)
    {
        $sPhone = preg_replace("#[^0-9]#",'',$sPhone);
        if(strlen($sPhone) != 10) return(False);
        $sArea = substr($sPhone,0,3);
        $sPrefix = substr($sPhone,3,3);
        $sNumber = substr($sPhone,6,4);
        $sPhone = "(".$sArea.")".$sPrefix."-".$sNumber;
        return($sPhone);
    }

    $tech='';
    if ( $autodispatch == 1 )
    {
        if( $autodis == 1 )
        $tech = $_REQUEST['technologist'];
    }

    $strSQL = "UPDATE tblfacility SET
        fldFacilityName='".strip_tags(addslashes($_REQUEST['facilityname']))."',
        fldFacilityType='".strip_tags(addslashes($_REQUEST['facilitytype']))./* "',    unused ATM
        fldFacilityOrgType='".strip_tags(addslashes($_REQUEST['facorgtype']))." */"',
        fldAdminName='".strip_tags(addslashes($_REQUEST['administratorsname']))."',
        fldDivisionName='".strip_tags(addslashes($_REQUEST['divisionname']))."',
        fldAddressLine1='".strip_tags(addslashes($_REQUEST['streetaddress1']))."',
        fldAddressLine2='".strip_tags(addslashes($_REQUEST['streetaddress2']))."',
        fldAddressCity='".strip_tags(addslashes($_REQUEST['city']))."',
        fldAddressState='".strip_tags(addslashes($_REQUEST['state']))."',
        fldAddressZip='".strip_tags(addslashes($_REQUEST['zipcode']))."',
        fldPhoneNumber='".phone_number($_REQUEST['phonenumber'])."',
        fldFaxNumber='".strip_tags(addslashes($_REQUEST['faxnumber']))."',
        fldEmail='".strip_tags(addslashes($_REQUEST['email']))."',
        fldAutoDispatch='$autodis',
        fldEmailOrder='".strip_tags(addslashes($_REQUEST['emailorder']))."',
        fldFacilityDisabled='".strip_tags(addslashes($_REQUEST['disabled']))."',
        fldTechnologist='".strip_tags(addslashes($tech))."',
        fldBillingContact='".strip_tags(addslashes($_REQUEST['facBillingContact']))."',
        fldBillingPhone='".strip_tags(addslashes($_REQUEST['facBillingPhone']))."',
        fldBillingFax='".strip_tags(addslashes($_REQUEST['facBillingFax']))."',
        fldBillingRep='".strip_tags(addslashes($_REQUEST['facBillingRep']))."',
        fldBillingAccNum='".strip_tags(addslashes($_REQUEST['facBillingAccNum']))."',
        fldMainState='".$_REQUEST['mainstate']."'
        where fldID='".$id."'";
    
    $sql_insert = mysql_query($strSQL);

    if($sql_insert)
    {
        $redirecturl = "index.php?pg=13";
        header("location:".$redirecturl);
    }
}
?>