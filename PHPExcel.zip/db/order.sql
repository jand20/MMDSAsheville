-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 31, 2009 at 01:50 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `order`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblfacility`
--

CREATE TABLE IF NOT EXISTS `tblfacility` (
  `fldID` int(20) NOT NULL AUTO_INCREMENT,
  `fldFacilityName` varchar(100) NOT NULL,
  `fldAdminName` varchar(100) NOT NULL,
  `fldDivisionName` varchar(100) NOT NULL,
  `fldAddressLine1` varchar(100) NOT NULL,
  `fldAddressLine2` varchar(100) NOT NULL,
  `fldAddressCity` varchar(100) NOT NULL,
  `fldAddressState` varchar(100) NOT NULL,
  `fldAddressZip` varchar(100) NOT NULL,
  `fldPhoneNumber` varchar(100) NOT NULL,
  `fldFaxNumber` varchar(100) NOT NULL,
  `fldEmail` varchar(100) NOT NULL,
  `fldEmailOrder` tinyint(1) NOT NULL,
  PRIMARY KEY (`fldID`),
  UNIQUE KEY `fldFacilityName` (`fldFacilityName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tblfacility`
--


-- --------------------------------------------------------

--
-- Table structure for table `tblfacilitydetails`
--

CREATE TABLE IF NOT EXISTS `tblfacilitydetails` (
  `fldID` int(20) NOT NULL AUTO_INCREMENT,
  `fldOrderID` int(20) NOT NULL,
  `fldFacility` varchar(100) NOT NULL,
  PRIMARY KEY (`fldID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tblfacilitydetails`
--


-- --------------------------------------------------------

--
-- Table structure for table `tblicdcodes`
--

CREATE TABLE IF NOT EXISTS `tblicdcodes` (
  `fldOrderid` int(10) NOT NULL,
  `fldProc1icd1` varchar(255) NOT NULL,
  `fldProc1icd2` varchar(255) NOT NULL,
  `fldProc1icd3` varchar(255) NOT NULL,
  `fldProc1icd4` varchar(255) NOT NULL,
  `fldProc1dig` varchar(255) NOT NULL,
  `fldProc2icd1` varchar(255) NOT NULL,
  `fldProc2icd2` varchar(255) NOT NULL,
  `fldProc2icd3` varchar(255) NOT NULL,
  `fldProc2icd4` varchar(255) NOT NULL,
  `fldProc2dig` varchar(255) NOT NULL,
  `fldProc3icd1` varchar(255) NOT NULL,
  `fldProc3icd2` varchar(255) NOT NULL,
  `fldProc3icd3` varchar(255) NOT NULL,
  `fldProc3icd4` varchar(255) NOT NULL,
  `fldProc3dig` varchar(255) NOT NULL,
  `fldProc4icd1` varchar(255) NOT NULL,
  `fldProc4icd2` varchar(255) NOT NULL,
  `fldProc4icd3` varchar(255) NOT NULL,
  `fldProc4icd4` varchar(255) NOT NULL,
  `fldProc4dig` varchar(255) NOT NULL,
  `fldProc5icd1` varchar(255) NOT NULL,
  `fldProc5icd2` varchar(255) NOT NULL,
  `fldProc5icd3` varchar(255) NOT NULL,
  `fldProc5icd4` varchar(255) NOT NULL,
  `fldProc5dig` varchar(255) NOT NULL,
  `fldProc6icd1` varchar(255) NOT NULL,
  `fldProc6icd2` varchar(255) NOT NULL,
  `fldProc6icd3` varchar(255) NOT NULL,
  `fldProc6icd4` varchar(255) NOT NULL,
  `fldProc6dig` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblicdcodes`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbllists`
--

CREATE TABLE IF NOT EXISTS `tbllists` (
  `fldID` int(20) NOT NULL AUTO_INCREMENT,
  `fldListName` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldValue` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`fldID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tbllists`
--

INSERT INTO `tbllists` (`fldID`, `fldListName`, `fldValue`) VALUES
(5, 'relationship', 'Brother'),
(4, 'relationship', 'Sister'),
(6, 'insurance', 'Skilled/PPS'),
(7, 'insurance', 'Medicare PartB'),
(8, 'modality', 'CR'),
(9, 'modality', 'US'),
(10, 'modality', 'EKG'),
(11, 'modality', 'Holter Monitor'),
(12, 'insurance', 'Medicaid'),
(13, 'insurance', 'HMO'),
(14, 'insurance', 'Private Pay'),
(15, 'relationship', 'Mother'),
(16, 'relationship', 'Father'),
(17, 'relationship', 'Wife'),
(18, 'relationship', 'Husband'),
(19, 'modality', 'Pace Maker '),
(20, 'modality', 'Pul function tes');

-- --------------------------------------------------------

--
-- Table structure for table `tblorderdetails`
--

CREATE TABLE IF NOT EXISTS `tblorderdetails` (
  `fldID` int(25) NOT NULL AUTO_INCREMENT,
  `fldPatientID` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `fldDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fldUserName` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fldPatientSSN` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldFirstName` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldLastName` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldMiddleName` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldSurName` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldDOB` date NOT NULL,
  `fldGender` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `fldInsurance` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldMedicareNumber` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldMedicaidNumber` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldState` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldInsuranceCompanyName` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldHmoContract` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPolicy` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldGroup` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldResponsiblePerson` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPhone` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldRelationship` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldFacilityName` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPrivateAddressLine1` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPrivateAddressLine2` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPrivateAddressCity` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPrivateAddressState` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPrivateAddressZip` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `fldPrivatePhoneNumber` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `fldHomeAddressLine1` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `fldHomeAddressLine2` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `fldHomeAddressCity` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `fldHomeAddressState` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `fldHomeAddressZip` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `fldHomePhoneNumber` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `fldStat` tinyint(1) NOT NULL,
  `fldOrderingPhysicians` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldRequestedBy` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldProcedure1` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldProcedure2` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldProcedure3` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldProcedure4` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldProcedure5` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldProcedure6` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldplr1` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `fldplr2` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `fldplr3` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `fldplr4` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `fldplr5` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `fldplr6` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `fldSymptom1` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldSymptom2` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldSymptom3` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldSymptom4` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldSymptom5` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldSymptom6` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldacsno1` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `fldacsno2` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `fldacsno3` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `fldacsno4` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `fldacsno5` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `fldacsno6` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `fldSymptoms` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fldHistory` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPatientroom` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `fldAfterhours` tinyint(1) NOT NULL,
  `fldAuthorized` tinyint(1) NOT NULL,
  `fldTechnologist` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldDispatched` tinyint(1) NOT NULL,
  `fldVerbal` tinyint(1) NOT NULL,
  `fldCoded` tinyint(1) NOT NULL,
  `fldReportDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fldReportCalledTo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fldReportDetails` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fldCDRequested` tinyint(1) NOT NULL,
  `fldCDAddr` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fldCreDate` date NOT NULL,
  `fldAuthDate` date NOT NULL,
  PRIMARY KEY (`fldID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tblorderdetails`
--


-- --------------------------------------------------------

--
-- Table structure for table `tblproceduremanagment`
--

CREATE TABLE IF NOT EXISTS `tblproceduremanagment` (
  `fldID` int(25) NOT NULL AUTO_INCREMENT,
  `fldCBTCode` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `fldDescription` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldModality` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`fldID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=54 ;

--
-- Dumping data for table `tblproceduremanagment`
--

INSERT INTO `tblproceduremanagment` (`fldID`, `fldCBTCode`, `fldDescription`, `fldModality`) VALUES
(38, '73010', 'Scapula (2V)', 'CR'),
(39, '72200', 'SI Joints (>3V)', 'CR'),
(40, '73030', 'Shoulder (2V)', 'CR'),
(41, '70210', 'Sinus Series (1V or 2V)', 'CR'),
(42, '70220', 'Sinus Series (3V)', 'CR'),
(43, '70250', 'Skull', 'CR'),
(44, '72070', 'T-Spine (2V)', 'CR'),
(45, '73590', 'Tibia/Fibula (2V)', '8'),
(46, '73660', 'Toes (2V)', 'CR'),
(47, '73110', 'Wrist (3V)', 'CR'),
(48, '70200', 'Facial Orbital', 'CR'),
(49, '70110', 'Facial Mandible (Jaw)', 'CR'),
(50, '93230', 'Holter Monitor', '11'),
(51, '93306', 'Echocardiogram', '9'),
(52, '93970', 'Venous Doppler (DVT)', 'US'),
(53, '70150', 'Facial Bones (3V)', 'CR');

-- --------------------------------------------------------

--
-- Table structure for table `tblsettings`
--

CREATE TABLE IF NOT EXISTS `tblsettings` (
  `fldEmailSignedOrders1` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldEmailSendOrders1` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPDFUnsignedOrders` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPDFSignedOrders` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `flddmwl` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldEmailSignedOrders2` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldEmailSendOrders2` varchar(100) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tblsettings`
--

INSERT INTO `tblsettings` (`fldEmailSignedOrders1`, `fldEmailSendOrders1`, `fldPDFUnsignedOrders`, `fldPDFSignedOrders`, `flddmwl`, `fldEmailSignedOrders2`, `fldEmailSendOrders2`) VALUES
('dpotter@cnymail.com', 'dpotter@cnymail.com', 'unsigned/', 'signed/', 'txt/', 'dpotter@cnymail.com', 'dpotter@cnymail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE IF NOT EXISTS `tbluser` (
  `fldID` int(25) NOT NULL AUTO_INCREMENT,
  `fldUserID` int(25) NOT NULL,
  `fldRealName` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldUserName` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPassword` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `fldEmail` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldRole` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldFacility` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fldPhone` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`fldID`),
  UNIQUE KEY `fldUserName` (`fldUserName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`fldID`, `fldUserID`, `fldRealName`, `fldUserName`, `fldPassword`, `fldEmail`, `fldRole`, `fldFacility`, `fldPhone`) VALUES
(1, 10000000, 'Admin', 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', '', 'admin', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbluserfacdetails`
--

CREATE TABLE IF NOT EXISTS `tbluserfacdetails` (
  `fldFacility` varchar(255) NOT NULL,
  `fldUserID` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluserfacdetails`
--

