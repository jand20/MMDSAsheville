<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style2 {color: #0000CC}
.style4 {color: #0000CC; font-weight: bold; }
.style5 {color: #006600}
.style8 {color: #006600; font-weight: bold; }
.style9 {color: #FF9900}
.style11 {color: #FF9900; font-weight: bold; }
.style12 {color: #000000}
.style14 {color: #000000; font-weight: bold; }
-->
</style>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" background="main.png">
  <tr>
    <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="17%">&nbsp;</td>
        <td width="83%">&nbsp;</td>
      </tr>
      <tr>
        <td class="lab">Color Code </td>
        <td class="lab">Meaning</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="25"><span class="style2">Blue</span></td>
        <td><span class="style2">New Order</span></td>
      </tr>
      <tr>
        <td height="25"><span class="style4">Blue Bold </span></td>
        <td><span class="style4">New Order � E-Signed</span></td>
      </tr>
      <tr>
        <td height="25"><span class="style5">Green</span></td>
        <td><span class="style5">Order Dispatched</span></td>
      </tr>
      <tr>
        <td height="25"><span class="style8">Green Bold</span></td>
        <td><span class="style8">Order Dispatched � E-Signed</span>
          </td>
      </tr>
      <tr>
        <td height="25"><span class="war">Red</span>          </td>
        <td><span class="war">New Order - Stat</span></td>
      </tr>
      <tr>
        <td height="25"><span class="war"><strong>Red Bold </strong></span></td>
        <td><span class="war"><strong>New Order � Stat & E-Signed</strong></span></td>
      </tr>
      <tr>
        <td height="25"><span class="style9">Orange</span></td>
        <td><span class="style9">Order Dispatched - Stat</span></td>
      </tr>
      <tr>
        <td height="25"><span class="style11">Orange Bold </span></td>
        <td><span class="style11">Order Dispatched � Stat & E-Signed</span></td>
      </tr>
      <tr>
        <td height="25"><span class="style12">Black</span></td>
        <td><span class="style12">Studies Received</span></td>
      </tr>
      <tr>
        <td height="25"><span class="style14">Black bold </span></td>
        <td><span class="style14">Studies Received & E-Signed</span></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
