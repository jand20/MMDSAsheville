<?php session_start();
// if session is not set redirect the user
if(empty($_SESSION['user']))
header("Location:index.php");
include "config.php";
$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tblorderdetails where fldID='$id'"));
?>
<link href="style.css" rel="stylesheet" type="text/css">
<form action="" method="post">
  <table width="1050" border="0" align="center" cellpadding="0" cellspacing="0" background="main.png">
    <tr>
      <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="9%" class="lab">Facility Name </td>
              <td width="16%"><span class="dis">
                <?=$sql_values_fetch['fldFacilityName']?>
              </span></td>
              <td width="13%" class="lab">Phone</td>
              <td width="31%"><span class="dis">
                <?=$sql_values_fetch['fldFacPhone']
?>
              </span></td>
              <td width="6%" class="lab">&nbsp;</td>
              <td width="25%">&nbsp;</td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

            <tr>
              <td width="9%"><span class="lab">First name</span></td>
              <td width="16%"><span class="dis">
                <?=$sql_values_fetch['fldFirstName']?>
              </span></td>
              <td width="10%"><span class="lab">Middle name</span></td>
              <td width="17%"><span class="dis">
                <?=$sql_values_fetch['fldMiddleName']?>
              </span></td>
              <td width="12%"><span class="lab">Last name</span></td>
              <td width="17%"><span class="dis">
                <?=$sql_values_fetch['fldLastName']?>
              </span></td>
              <td width="6%">&nbsp;</td>
              <td width="13%">&nbsp;</td>
            </tr>
            <tr>
              <td class="lab">Patient MR# </td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldPatientID']?>
              </span></td>
              <td><span class="lab">DOB </span></td>
              <td><span class="dis">
                <?
				function formatDateddmmyy($dDate){
				$dNewDate = strtotime($dDate);
				return date('m-d-Y',$dNewDate);
				}
				$fdob = $sql_values_fetch['fldDOB'];
				$ddob = formatDateddmmyy($fdob);
				?>
                <?=$ddob?>
              </span></td>
              <td><span class="lab">Patient SSN</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldPatientSSN']?>
              </span></td>
              <td><span class="lab">Sex</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldGender']?>
              </span></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="9%"><span class="lab">Room #</span></td>
              <td width="16%"><span class="dis">
                <?=$sql_values_fetch['fldPatientroom']?>
              </span></td>
              <td width="6%"><span class="lab">Urgent</span></td>
              <td><span class="dis">
                <? if($sql_values_fetch['fldStat'] == 1) {?>
Urgent
<? } else { ?>
Normal
<? } ?>
              </span></td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="10%"><span class="lab">Procedure #1</span></td>
              <td width="25%"><span class="dis">
                <?=$sql_values_fetch['fldProcedure1']?>
              </span></td>
              <td width="4%"><span class="lab">L/R</span></td>
              <td width="12%"><span class="dis">
                <?=$sql_values_fetch['fldplr1']?>
              </span></td>
              <td width="8%"><span class="lab">Symptom </span></td>
              <td width="37%"><span class="dis">
                <?=$sql_values_fetch['fldSymptom1']?>
              </span></td>
              <td width="4%">&nbsp;</td>
            </tr>
            <tr>
              <td><span class="lab">Procedure #2</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldProcedure2']?>
              </span></td>
              <td><span class="lab">L/R</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldplr2']?>
              </span></td>
              <td><span class="lab">Symptom </span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldSymptom2']?>
              </span></td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td><span class="lab">Procedure #3</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldProcedure3']?>
              </span></td>
              <td><span class="lab">L/R</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldplr3']?>
              </span></td>
              <td><span class="lab">Symptom </span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldSymptom3']?>
              </span></td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td><span class="lab">Procedure #4</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldProcedure4']?>
              </span></td>
              <td><span class="lab">L/R</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldplr4']?>
              </span></td>
              <td><span class="lab">Symptom </span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldSymptom4']?>
              </span></td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td><span class="lab">Procedure #5</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldProcedure5']?>
              </span></td>
              <td><span class="lab">L/R</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldplr5']?>
              </span></td>
              <td><span class="lab">Symptom </span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldSymptom5']?>
              </span></td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td><span class="lab">Procedure #6</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldProcedure6']?>
              </span></td>
              <td><span class="lab">L/R</span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldplr6']?>
              </span></td>
              <td><span class="lab">Symptom </span></td>
              <td><span class="dis">
                <?=$sql_values_fetch['fldSymptom6']?>
              </span></td>
              <td>&nbsp;</td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><span class="lab">Additional Patient Info</span></td>
            </tr>
            <tr>
              <td><span class="dis">
                <?=$sql_values_fetch['fldSymptoms']?>
              </span></td>
            </tr>
            <tr>
              <td><span class="lab">History:</span></td>
            </tr>
            <tr>
              <td><span class="dis">
                <?=$sql_values_fetch['fldHistory']?>
              </span></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><span class="lab">Verbal Report : </span></td>
            </tr>
            <tr>
              <td height="20"><textarea name="ReportDetails" cols="100" rows="3"><?=$sql_values_fetch['fldReportDetails']?>
              </textarea></td>
            </tr>


          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
			<?
			$time=date("Y-m-d H:i",time());
			function formatDate11($dDate){
			$dNewDate = strtotime($dDate);
			return date('d-m-Y',$dNewDate);
			}
			function formatDate12($dDate){
			$dNewDate = strtotime($dDate);
			return date('H:i',$dNewDate);
			}
			$time11=formatdate11($time);
			$time12=formatdate12($time);
			?>
            <tr>
              <td width="19%" class="lab">Time Called in: </td>
              <td width="22%"><input name="schdate1" type="text" value="<?=$time11?>" id="schdate1" size="8"/>
                <input name="schdate2" type="text" value="<?=$time12?>" id="schdate2" size="2"/></td>
              <td width="14%" class="lab">Report Called to: </td>
              <td width="45%"><input name="ReportCalledTo" type="text" id="ReportCalledTo" class="myinput1" value="<?=$sql_values_fetch['fldReportCalledTo']?>"/></td>
            </tr>
            <tr>
              <td class="lab"># of patients seen on this trip </td>
              <td><select name="select" class="myselect4">
                  <option selected="selected" value="">Select</option>
                  <option  Value="1" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>1</option>
                  <option  Value="2" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>2</option>
                  <option  Value="3" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>3</option>
                  <option  Value="4" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>4</option>
                  <option  Value="5" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>5</option>
                  <option  Value="6" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>6</option>
                  <option  Value="7" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>7</option>
                  <option  Value="8" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>8</option>
                  <option  Value="9" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>9</option>
                  <option  Value="10" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>10</option>
                  <option  Value="11" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>11</option>
                  <option  Value="12" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>12</option>
                  <option  Value="13" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>13</option>
                  <option  Value="14" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>14</option>
                  <option  Value="15" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>15</option>
                  <option  Value="16" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>16</option>
                  <option  Value="17" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>17</option>
                  <option  Value="18" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>18</option>
                  <option  Value="19" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>19</option>
                  <option  Value="20" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>20</option>
                </select>
                </td>
              <td class="lab">Reading Radiologist </td>
              <td><select name="radiologist" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
    			$sql="SELECT * FROM tbllists where fldListName = 'radiologist' order by fldValue";
    			$result = mysql_query($sql);
    			while($row = mysql_fetch_array($result))
    			{?>
                <option value="<?=$row['fldValue']?>" <? if($sql_values_fetch['fldRadiologist'] == $row['fldValue']) {?> selected="selected" <? } ?>>
                <?=$row['fldValue']?>
                </option>
                <? } ?>
              </select></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>

        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><div align="center">
                <input type="submit" name="submit" value="Update" />
              </div></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
<?
if($_REQUEST['submit']!='')
{

function formatDate2($dDate){
$dNewDate = strtotime($dDate);
return date('Y-m-d H:i',$dNewDate);
}
$time1=$_REQUEST['schdate1'] . " " . $_REQUEST['schdate2'];
$time=formatdate2($time1);
if($_REQUEST['ReportCalledTo']!="")
{
$verbal="1";
}
else
{
$verbal="2";
}
$sql_insert	= mysql_query("update tblorderdetails set
fldVerbal='".$verbal."',
fldReportDate='".$time."',
fldReportCalledTo='".$_REQUEST['ReportCalledTo']."',
fldReportDetails='".$_REQUEST['ReportDetails']."',
fldRadiologist='".$_REQUEST['Radiologist']."',
fldVerbalnoofpat='".$_REQUEST['Verbalnoofpat']."'
where fldID='".$id."'");
if($sql_insert)
{
$redirecturl = "index.php?pg=20";
header("location:".$redirecturl);
}
}
?>