<?php session_start();
//if session is not set redirect the user
if(empty($_SESSION['user']))
header("Location:index.php");

include "config.php";
$user = $_SESSION['user'];
$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tbluser where fldUserName='$user'"));
$fac=$sql_values_fetch['fldFacility'];
$uid=$sql_values_fetch['fldID'];

$i=0;
$sql="SELECT * from tblorderdetails where 1";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result))
{
$ptid=$row['fldPatientID'];
if(is_numeric($ptid))
{
$arr[$i++]=$ptid;
}
}
$pid=max($arr);

if($pid < 25001)
{
$pid=25000;
}
$pid = $pid + 1;

//  require_once "Mail.php"; // PEAR Mail package
//  require_once ('Mail/mime.php'); // PEAR Mail_Mime packge

$host = "mail.mdipacs.net";
$username = "dpotter";
$password = "brasil06";

?>
<script type="text/javascript">
function search_prompt() {
var retVal=""
var valReturned;
retVal=showModalDialog('searchpop.htm');
valReturned=retVal;
location.replace(valReturned);
}
function newpt() {
location.replace('?pg=42');
}
</script>
<script type="text/javascript">
function cdenable(){
if (document.getElementById('cdrequested').value != 0){
document.getElementById('cdaddrlab').style.display = '';
document.getElementById('cddatelab').style.display = '';
document.getElementById('cdaddr').style.display = '';
document.getElementById('cddate').style.display = '';
} else {
document.getElementById('cddatelab').style.display = 'none';
document.getElementById('cdaddrlab').style.display = 'none';
document.getElementById('cdaddr').style.display = 'none';
document.getElementById('cddate').style.display = 'none';
};
}
function phyenable(){
if (document.forms[0].orderingphysicians.value == "new"){
document.forms[0].phynew.style.display = "";
} else {
document.forms[0].phynew.style.display = "none";
};
}
</script>
<script type="text/javascript" src="facility.js"></script>
<style type="text/css">
@import "timer/jquery.timeentry.css";
</style>
<script type="text/javascript" src="timer/jquery-1.3.2.js"></script>
<script type="text/javascript" src="timer/jquery.min.js"></script>
<script type="text/javascript" src="timer/jquery.timeentry.js"></script>
<script type="text/javascript">
$(function () {
	$('#schdate2').timeEntry({spinnerImage: ''});
    $('#schdate22').timeEntry({spinnerImage: ''});

});
</script>
 <script type="text/javascript" src="jquery-latest.js"></script>
 <script type="text/javascript" src="jquery.validate.js"></script>
 <script type="text/javascript">
  $.validator.addMethod(
      "aDate",
      function(value, element) {
          return value.match(/^\d\d?\-\d\d?\-\d\d\d\d$/);

      },
      "Please enter a date in the format mm-dd-yyyy"
  );
  $.validator.addMethod(
      "aDate1",
      function(value, element) {
          var temp = new Array();
		  temp = value.split('-');
		  month=temp[0];
		  days=temp[1];
		  year=temp[2];
		  flag=1;
		  if(value.length<10)
		  flag=0;
		  if(year.length<4)
		  flag=0;
		  if(year<1600 || year>2400)
		  flag=0;
		  if(month.length<2)
		  flag=0;
		  if(month<1 || month>12)
		  flag=0;
		  if(days.length<2)
		  flag=0;
          if ((parseInt(year)%4) == 0){
              if (parseInt(year)%100 == 0){
                  if (parseInt(year)%400 != 0){
		    		mdays=28;
                  }
                 if (parseInt(year)%400 == 0){
		    		mdays=29;
                  }
              }
              if (parseInt(year)%100 != 0){
		    	mdays=29;
              }
          }
          if ((parseInt(year)%4) != 0){
		  mdays=28;
          }
          if(month==01||month==03||month==05||month==07||month==08||month==10||month==12)
          mdays=31;
          if(month==04||month==06||month==09||month==11)
          mdays=30;
		  if(days<1 || days>mdays)
		  flag=0;

          if(flag==1)
          return true;
          else
          return false;

      },
      "Please enter a date in the format mm-dd-yyyy"
  );

    $(document).ready(function() {
      $("#myform").validate({
        rules: {
        lastname: {
          required: true
        },
        firstname: {
          required: true
        },
        patientid: {
          required: true
        },
        symptoms1: {
          required: true
        },
        dob: {
          required: true,
          aDate: true,
          aDate1: true
        },
        schdate12: {
          required: true,
          aDate: true,
          aDate1: true
        },
        patientssn: {
          required: true
        },
        sex: {
          required: true
        },
        requester: {
          required: true
        },
        facility: {
          required: true
        },
        orderingphysicians: {
          required: true
        }
        }
      });
    });
  </script>
<link href="style.css" rel="stylesheet" type="text/css" />
<form id="myform" action="" method="post">
<table width="1050" border="0" cellpadding="0" cellspacing="0" background="main.png">
  <tr>
    <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="9%"><span class="lab">Today Date</span></td>
            <td width="16%"><input name="schdate1" type="text" value="<?echo date('m-d-Y' , time());?>" id="schdate1" size="8"/></td>
            <td width="13%" class="lab">Today Time </td>
            <td width="31%"><input name="schdate2" type="text" size="6" id="schdate2" value="<?echo date('g:i A' , time());?>"/></td>
            <td width="6%">&nbsp;</td>
            <td width="25%">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
            <td width="9%">&nbsp;</td>
            <td colspan="2"><input name="retrive" type="button" onclick="search_prompt()" value="Search" />
            </td>
            <td width="17%">&nbsp;</td>
            <td width="9%">&nbsp;</td>
            <td width="17%">&nbsp;</td>
            <td width="6%">&nbsp;</td>
            <td width="13%">&nbsp;</td>
          </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="9%">&nbsp;</td>
			<td width="17%">&nbsp;</td>
            <td width="9%">&nbsp;</td>
            <td width="17%">&nbsp;</td>
            <td width="6%">&nbsp;</td>
            <td width="13%">&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Last name</span></td>
            <td width="16%"><input name="lastname" type="text" class="myinput1" style="background-color: #FFFF99;"/></td>
            <td width="13%"><span class="lab">First name</span></td>
            <td><input name="firstname" type="text" class="myinput1" style="background-color: #FFFF99;"/></td>
            <td><span class="lab">Middle name</span></td>
            <td><input name="middlename" type="text" class="myinput1" /></td>
            <td><span class="lab">Jr, Sr, II</span></td>
            <td><input name="surname" type="text" class="myinput2" size="10" /></td>
          </tr>
          <tr>
            <?
	 		function formatDateddmmyy($dDate){
	 		if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
			    return '';
            }
			$dNewDate = strtotime($dDate);
			return date('m-d-Y',$dNewDate);
			}
			$ddob="MM-DD-YYYY";
			?>
            <td><span class="lab">DOB (MM-DD-YYYY)</span></td>
            <td><input name="dob" type="text" class="myinput1" maxlength="10"  style="background-color: #FFFF99;"/></td>
            <td><span class="lab">Patient ID</span></td>
            <td><input name="patientssn" type="text" class="myinput1" style="background-color: #FFFF99;"/></td>
            <td><span class="lab">Sex</span></td>
            <td><select name="sex"  style="background-color: #FFFF99;">
              <option value="">Select</option>
              <option value="female">FEMALE</option>
              <option value="male">MALE</option>
            </select></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Contact</span></td>
            <td><input name="requester" type="text" class="myinput1" style="background-color: #FFFF99;"/></td>
            <td width="9%"><span class="lab">Facility Name </span></td>
            <td colspan="3"><select name="facility" class="myselect5" onchange="showUser(this.value)"  style="background-color: #FFFF99;">
              <?
			$sql="SELECT * FROM tblfacility where 1 order by fldFacilityName";
			//if($_SESSION['role'] =='facilityuser') { $sql="select * from tbluserfacdetails where fldUserID = '$uid'"; }
			//else
			{ ?>
            <option selected="selected" value="">Select</option>
			<? }
			$result = mysql_query($sql);
			while($row = mysql_fetch_array($result))
			{?>
              <option value="<?=$row['fldFacilityName']?>" >
              <?=strtoupper($row['fldFacilityName'])?>
              </option>
              <? } ?>
            </select></td>
            <td width="6%" class="lab"> Phone </td>
            <td width="19%"><div id="txtHint"><input name='faccontact' type='text' class='myinput1' /></div></td>
          </tr>
          <tr>
            <td width="5%"><span class="lab">Room #</span></td>
            <td width="18%"><input name="patientroom" type="text" class="myinput1" /></td>
            <td><span class="lab">Urgent</span></td>
            <td width="9%"><input name="stat" type="checkbox" class="chk" value="1" /></td>
            <td width="9%"><span class="lab">After Hours</span></td>
            <td width="25%"><input name="afterhours" type="checkbox" class="chk" value="1" /></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="9%"><span class="lab">Procedure #1</span></td>
            <td width="33%"><span class="lab">
              <select name="procedure1" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr1" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr1" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr1" value="BILATERAL" />
B</label>
            </span></td>
            <td width="8%"><span class="lab">Symptom </span></td>
            <td width="48%"><span class="lab">
              <input name="symptoms1" type="text" size="40" style="background-color: #FFFF99;"/>
            </span></td>
            <td width="2%">&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #2</span></td>
            <td><span class="lab">
              <select name="procedure2" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr2" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr2" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr2" value="BILATERAL"/>
B</label>
            </span></td>
            <td><span class="lab">Symptom </span></td>
            <td><span class="lab">
              <input name="symptoms2" type="text" size="40" />
            </span></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #3</span></td>
            <td><span class="lab">
              <select name="procedure3" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr3" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr3" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr3" value="BILATERAL" />
B</label>
            </span></td>
            <td><span class="lab">Symptom </span></td>
            <td><span class="lab">
              <input name="symptoms3" type="text" size="40" />
            </span></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #4</span></td>
            <td><span class="lab">
              <select name="procedure4" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr4" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr4" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr4" value="BILATERAL" />
B</label>
            </span></td>
            <td><span class="lab">Symptom </span></td>
            <td><span class="lab">
              <input name="symptoms4" type="text" size="40" />
            </span></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #5</span></td>
            <td><span class="lab">
              <select name="procedure5" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr5" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr5" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr5" value="BILATERAL" />
B</label>
            </span></td>
            <td><span class="lab">Symptom </span></td>
            <td><span class="lab">
              <input name="symptoms5" type="text" size="40" />
            </span></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Procedure #6</span></td>
            <td><span class="lab">
              <select name="procedure6" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
				$sql="SELECT * FROM tblproceduremanagment order by fldDescription";
				$result = mysql_query($sql);
				while($row = mysql_fetch_array($result))
				{?>
                <option value="<?=$row['fldDescription']?>">
                <?=strtoupper($row['fldDescription'])?>
                </option>
                <? } ?>
              </select>
              <label>
              <input type="radio" name="plr6" value="LEFT" />
L</label>
              <label>
              <input type="radio" name="plr6" value="RIGHT" />
R</label>
              <label>
              <input type="radio" name="plr6" value="BILATERAL" />
B</label>
            </span></td>
            <td><span class="lab">Symptom </span></td>
            <td><span class="lab">
              <input name="symptoms6" type="text" size="40" />
            </span></td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Additional Patient Info</span></td>
          </tr>
          <tr>
            <td><input name="symptoms" type="text" size="150" /></td>
          </tr>
          <tr>
            <td><span class="lab">History:</span></td>
          </tr>
          <tr>
            <td><input name="history" type="text" size="150" /></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="11%"><span class="lab">Referring Dr. </span></td>
            <td colspan="2"><select name="orderingphysicians" class="myselect1" onChange="phyenable();"  style="background-color: #FFFF99;">
              <option selected="selected" value="">Select</option>
              <?
			  if($_SESSION['role'] =='facilityuser')
    		  {
			  $sql="SELECT * FROM tbluser where fldRole='orderingphysician' and fldid in (Select flduserid from tbluserfacdetails where fldfacilityname like (Select fldrealname from tbluser where fldusername='$user')) Order by FldRealName";
			  } else {
			  $sql="SELECT * FROM tbluser where fldRole='orderingphysician' order by fldRealName";
			  }
			  $result = mysql_query($sql);
			  while($row = mysql_fetch_array($result))
	     	  {?>
              <option value="<?=$row['fldRealName']?>">
              <?=strtoupper($row['fldRealName'])?>
              </option>
              <? } ?>
              <option value="new">Not In List</option>
            </select>        <input name="phynew" id="phynew" style="display: none;"/></td>
            <td width="19%">
              <span class="lab">Date/Time Exam needed: </span></td>
            <td width="12%"><input name="schdate12" type="text" id="schdate12" size="8" style="background-color: #FFFF99;"/></td>
            <td width="4%" colspan="2"><input name="schdate22" type="text" value="<?echo date('g:i A' , time());?>" id="schdate22" size="6"/></td>
          </tr>
          <tr>
            <td class="lab">CD Needed ? </td>
            <td width="7%">
			<select name="cdrequested" id="cdrequested" onChange="cdenable();"> >
			<option value="1">Y</option>
			<option value="0" selected="selected">N</option>
			</select>			</td>
			<td width="32%">&nbsp;</td>
			<td class="lab"><label align="LEFT" name="cdaddrlab" id="cdaddrlab" style="display: none;">Location</label></td>
            <td><textarea name="cdaddr" id="cdaddr" style="display: none;" cols="30" rows="4"></textarea></td>
            <td  class="lab"><label align="LEFT" name="cddatelab" id="cddatelab" style="display: none;">Date CD needed :</label></td>
            <td><input name="cddate" type="text" value="<?=$time11?>" id="cddate" size="8"  style="display: none;"/></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Insurance Type</span></td>
            <td><select name="insurance" class="myselect1">
              <option selected="selected" value="">Select</option>
              <?
	  		  $sql="SELECT * FROM tbllists where fldListName = 'insurance' order by fldValue";
	  		  $result = mysql_query($sql);
	  		  while($row = mysql_fetch_array($result))
	  		  {?>
              <option value="<?=$row['fldValue']?>">
              <?=strtoupper($row['fldValue'])?>
              </option>
              <? } ?>
            </select></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td width="13%"><span class="lab">Medicare #</span></td>
            <td width="28%"><input name="medicare" type="text" class="myinput1" /></td>
            <td width="11%"><span class="lab">Medicaid #</span></td>
            <td width="21%"><input name="medicaid" type="text" class="myinput1" /></td>
            <td width="7%"><span class="lab">State #</span></td>
            <td width="20%"><select name="state">
                <option value="IA">IA</option>
                <option value="KS">KS</option>
                <option value="MO">MO</option>
                <option value="NE">NE</option>
              </select></td>
          </tr>
          <tr>
            <td><span class="lab">Insurance Company </span></td>
            <td><input name="insurancecompanyname" type="text" class="myinput3"/></td>
            <td><span class="lab">Policy #</span></td>
            <td><input name="policy" type="text" class="myinput1"/></td>
            <td><span class="lab">Group #</span></td>
            <td><input name="group" type="text" class="myinput1"/></td>
          </tr>
          <tr>
            <td><span class="lab">HMO Name/Contract </span></td>
            <td><input name="hmo_contract" type="text" class="myinput1" /></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="13%"><span class="lab">Responsible Party:</span></td>
            <td width="28%"><input name="responsibleperson" type="text" class="myinput3" /></td>
            <td width="11%"><span class="lab">Relationship</span></td>
            <td width="48%"><select name="relationship" class="myselect2">
              <option selected="selected" value="">Select</option>
              <?
    		  $sql="SELECT * FROM tbllists where fldListName = 'relationship' order by fldValue";
    		  $result = mysql_query($sql);
    		  while($row = mysql_fetch_array($result))
    		  {?>
              <option value="<?=$row['fldValue']?>" >
              <?=strtoupper($row['fldValue'])?>
              </option>
              <? } ?>
            </select></td>
          </tr>
          <tr>
            <td><span class="lab">Address #1</span></td>
            <td><input name="privatestreetaddress1" type="text" class="myinput3" /></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Address #2 </span></td>
            <td><input name="privatestreetaddress2" type="text" class="myinput3" /></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">City</span></td>
            <td><input name="privatecity" type="text" class="myinput3"/></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">State </span></td>
            <td><select name="privatestate" size="1" class="myselect2" id="privatestate">
              <option selected="selected">Select a State</option>
              <option value="ALASKA"> ALASKA</option>
			<option value="ALABAMA">ALABAMA</option>
			<option value="ARKANSAS">ARKANSAS</option>
			<option value="ARIZONA">ARIZONA</option>
			<option value="CALIFORNIA">CALIFORNIA</option>
			<option value="COLORADO">COLORADO</option>
			<option value="CONNECTICUT">CONNECTICUT</option>
			<option value="WASHINGTON D C">WASHINGTON D C</option>
			<option value="DELAWARE">DELAWARE</option>
			<option value="FLORIDA">FLORIDA</option>
			<option value="GEORGIA">GEORGIA</option>
			<option value="HAWAII">HAWAII</option>
			<option value="IOWA">IOWA</option>
			<option value="IDAHO">IDAHO</option>
		   <option value="ILLINOIS">ILLINOIS</option>
		   <option value="INDIANA">INDIANA</option>
		   <option value="KANSAS">KANSAS</option>
		   <option value="KENTUCKY">KENTUCKY</option>
		   <option value="LOUISIANA">LOUISIANA</option>
		   <option value="MAINE">MAINE</option>
		   <option value="MARYLAND">MARYLAND</option>
		   <option value="MASSACHUSETTS">MASSACHUSETTS</option>
		   <option value="MICHIGAN">MICHIGAN</option>
		   <option value="MINNESOTA">MINNESOTA</option>
		   <option value="MISSISSIPPI">MISSISSIPPI</option>
		   <option value="MISSOURI">MISSOURI</option>
		   <option value="MONTANA">MONTANA</option>
		   <option value="NEBRASKA">NEBRASKA</option>
		   <option value="NEVADA">NEVADA</option>
		   <option value="NEW HAMPSHIRE">NEW HAMPSHIRE</option>
		   <option value="NEW JERSEY">NEW JERSEY</option>
		   <option value="NEW MEXICO">NEW MEXICO</option>
		   <option value="NEW YORK">NEW YORK</option>
		   <option value="NORTH CAROLINA">NORTH CAROLINA</option>
		   <option value="NORTH DAKOTA">NORTH DAKOTA</option>
		   <option value="OHIO">OHIO</option>
		   <option value="OKLAHOMA">OKLAHOMA</option>
		   <option value="OREGON">OREGON</option>
		   <option value="PENNSYLVANIA">PENNSYLVANIA</option>
		   <option value="PUERTO RICO">PUERTO RICO</option>
		   <option value="RHODE ISLAND">RHODE ISLAND</option>
		   <option value="SOUTH CAROLINA">SOUTH CAROLINA</option>
		   <option value="SOUTH DAKOTA">SOUTH DAKOTA</option>
		   <option value="TENNESSEE">TENNESSEE</option>
		   <option value="TEXAS">TEXAS</option>
		   <option value="UTAH">UTAH</option>
		   <option value="VERMONT">VERMONT</option>
		   <option value="VIRGINIA">VIRGINIA</option>
		   <option value="WASHINGTON">WASHINGTON</option>
		   <option value="WEST VIRGINIA">WEST VIRGINIA</option>
		   <option value="WISCONSIN">WISCONSIN</option>
		   <option value="WYOMING">WYOMING</option>
            </select></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Zip</span></td>
            <td><input name="privatezipcode" type="text" class="myinput1" /></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Phone #</span></td>
            <td><input name="privatephone" type="text" class="myinput1" /></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td>This Patient would find it physically and/or psychologically taxing because of advanced age and/or physical limitations to receive an X-ray or EKG outside this location. This test is medically necessary for the diagnosis and treatment of this patient.</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><div align="center">
              <input type="submit" name="submit" value="Add" />
            </div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>

    </table></td>
  </tr>
</table>
</form>

<?php

if($_REQUEST['submit']!='')
{

function formatdate($sDate1)
{
$sDate = split('-', $sDate1);
$sDate1 = $sDate[2].'-'.$sDate[0].'-'.$sDate[1];
return $sDate1;
}

$newdob = formatdate($_REQUEST['dob']);

function phone_number($sPhone){
    $sPhone = ereg_replace("[^0-9]",'',$sPhone);
    if(strlen($sPhone) != 10) return(False);
    $sArea = substr($sPhone,0,3);
    $sPrefix = substr($sPhone,3,3);
    $sNumber = substr($sPhone,6,4);
    $sPhone = "(".$sArea.")".$sPrefix."-".$sNumber;
    return($sPhone);
}

$cretime=date("Y-m-d",time());

$orddate = date('Y-m-d H:i',strtotime(formatdate($_REQUEST['schdate1']) . ' ' . $_REQUEST['schdate2']));
$schdate = date('Y-m-d H:i',strtotime(formatdate($_REQUEST['schdate12']) . ' ' . $_REQUEST['schdate22']));
$cddate = formatdate($_REQUEST['cddate']);

$ordphy=$_REQUEST['orderingphysicians'];
if($ordphy == "new")
{
$ordphy=$_REQUEST['phynew'];
}

$dispatched=0;
$technologist='';
$facy=$_REQUEST['facility'];
$sql_values_fetch_fac =	mysql_fetch_array(mysql_query("select * from tblfacility where fldFacilityName='$facy'"));
$adisp=$sql_values_fetch_fac['fldAutoDispatch'];
if($adisp==1)
{
$dispatched=1;
$technologist=$sql_values_fetch_fac['fldTechnologist'];
}


$sql_insert = mysql_query("insert into tblorderdetails set
fldPatientID='".strtoupper(strip_tags(addslashes($_REQUEST['patientid'])))."',
fldSchDate='".strtoupper(strip_tags(addslashes($schdate)))."',
fldPatientSSN='".strtoupper(strip_tags(addslashes($_REQUEST['patientssn'])))."',
fldFirstName='".strtoupper(strip_tags(addslashes($_REQUEST['firstname'])))."',
fldLastName='".strtoupper(strip_tags(addslashes($_REQUEST['lastname'])))."',
fldMiddleName='".strtoupper(strip_tags(addslashes($_REQUEST['middlename'])))."',
fldSurName='".strtoupper(strip_tags(addslashes($_REQUEST['surname'])))."',
fldDOB='".strtoupper(strip_tags(addslashes($newdob)))."',
fldGender='".(strip_tags(addslashes($_REQUEST['sex'])))."',
fldInsurance='".(strip_tags(addslashes($_REQUEST['insurance'])))."',
fldMedicareNumber='".strtoupper(strip_tags(addslashes($_REQUEST['medicare'])))."',
fldMedicaidNumber='".strtoupper(strip_tags(addslashes($_REQUEST['medicaid'])))."',
fldState='".(strip_tags(addslashes($_REQUEST['state'])))."',
fldInsuranceCompanyName='".strtoupper(strip_tags(addslashes($_REQUEST['insurancecompanyname'])))."',
fldHmoContract='".strtoupper(strip_tags(addslashes($_REQUEST['hmo_contract'])))."',
fldPolicy='".strtoupper(strip_tags(addslashes($_REQUEST['policy'])))."',
fldGroup='".strtoupper(strip_tags(addslashes($_REQUEST['group'])))."',
fldResponsiblePerson='".strtoupper(strip_tags(addslashes($_REQUEST['responsibleperson'])))."',
fldRelationship='".(strip_tags(addslashes($_REQUEST['relationship'])))."',
fldFacilityName='".(strip_tags(addslashes($_REQUEST['facility'])))."',
fldFacPhone='".(phone_number($_REQUEST['faccontact']))."',
fldPrivateAddressLine1='".strtoupper(strip_tags(addslashes($_REQUEST['privatestreetaddress1'])))."',
fldPrivateAddressLine2='".strtoupper(strip_tags(addslashes($_REQUEST['privatestreetaddress2'])))."',
fldPrivateAddressCity='".strtoupper(strip_tags(addslashes($_REQUEST['privatecity'])))."',
fldPrivateAddressState='".(strip_tags(addslashes($_REQUEST['privatestate'])))."',
fldPrivateAddressZip='".strtoupper(strip_tags(addslashes($_REQUEST['privatezipcode'])))."',
fldPrivatePhoneNumber='".strtoupper(phone_number($_REQUEST['privatephone']))."',
fldHomeAddressLine1='".strtoupper(strip_tags(addslashes($_REQUEST['homestreetaddress1'])))."',
fldHomeAddressLine2='".strtoupper(strip_tags(addslashes($_REQUEST['homestreetaddress2'])))."',
fldHomeAddressCity='".strtoupper(strip_tags(addslashes($_REQUEST['homecity'])))."',
fldHomeAddressState='".(strip_tags(addslashes($_REQUEST['homestate'])))."',
fldHomeAddressZip='".strtoupper(strip_tags(addslashes($_REQUEST['homezipcode'])))."',
fldHomePhoneNumber='".strtoupper(strip_tags(addslashes($_REQUEST['homephone'])))."',
fldStat='".strtoupper(strip_tags(addslashes($_REQUEST['stat'])))."',
fldOrderingPhysicians='".(strip_tags(addslashes($ordphy)))."',
fldRequestedBy='".strtoupper(strip_tags(addslashes($_REQUEST['requester'])))."',
fldProcedure1='".(strip_tags(addslashes($_REQUEST['procedure1'])))."',
fldProcedure2='".(strip_tags(addslashes($_REQUEST['procedure2'])))."',
fldProcedure3='".(strip_tags(addslashes($_REQUEST['procedure3'])))."',
fldProcedure4='".(strip_tags(addslashes($_REQUEST['procedure4'])))."',
fldProcedure5='".(strip_tags(addslashes($_REQUEST['procedure5'])))."',
fldProcedure6='".(strip_tags(addslashes($_REQUEST['procedure6'])))."',
fldplr1='".(strip_tags(addslashes($_REQUEST['plr1'])))."',
fldplr2='".(strip_tags(addslashes($_REQUEST['plr2'])))."',
fldplr3='".(strip_tags(addslashes($_REQUEST['plr3'])))."',
fldplr4='".(strip_tags(addslashes($_REQUEST['plr4'])))."',
fldplr5='".(strip_tags(addslashes($_REQUEST['plr5'])))."',
fldplr6='".(strip_tags(addslashes($_REQUEST['plr6'])))."',
fldSymptom1='".(strip_tags(addslashes($_REQUEST['symptoms1'])))."',
fldSymptom2='".(strip_tags(addslashes($_REQUEST['symptoms2'])))."',
fldSymptom3='".(strip_tags(addslashes($_REQUEST['symptoms3'])))."',
fldSymptom4='".(strip_tags(addslashes($_REQUEST['symptoms4'])))."',
fldSymptom5='".(strip_tags(addslashes($_REQUEST['symptoms5'])))."',
fldSymptom6='".(strip_tags(addslashes($_REQUEST['symptoms6'])))."',
fldPatientroom='".strtoupper(strip_tags(addslashes($_REQUEST['patientroom'])))."',
fldAfterhours='".strtoupper(strip_tags(addslashes($_REQUEST['afterhours'])))."',
fldHistory='".strtoupper(strip_tags(addslashes($_REQUEST['history'])))."',
fldCDRequested='".(strip_tags(addslashes($_REQUEST['cdrequested'])))."',
fldSymptoms='".strtoupper(strip_tags(addslashes($_REQUEST['symptoms'])))."',
fldCDAddr='".strtoupper(strip_tags(addslashes($_REQUEST['cdaddr'])))."',
fldCDDate='".strtoupper(strip_tags(addslashes($cddate)))."',
fldUserName='".strtoupper(strip_tags(addslashes($_SESSION['user'])))."',
fldDate='".strtoupper(strip_tags(addslashes($orddate)))."',
fldCreDate='".strtoupper(strip_tags(addslashes($cretime)))."',
fldDispatched='".strtoupper(strip_tags(addslashes($dispatched)))."',
fldTechnologist='".strtoupper(strip_tags(addslashes($technologist)))."'
") or die (mysql_error());
$id =	mysql_insert_id();
$txtid = $id;
$id =   $txtid;

if($sql_insert)
{
$sql_insert_icd	= mysql_query("insert into tblicdcodes set
fldOrderid='".(strip_tags(addslashes($id)))."'
") or die (mysql_error());

if($sql_insert_icd)
{
include "pdf_neworder.php";
}

//////////////////////////
// Read POST request params into global vars
$to1=$sql_values_fetch['fldEmailSendOrders1'];
$to2=$sql_values_fetch['fldEmailSendOrders2'];

$from = "Douglas <dpotter@mdipacs.net>";
$to=$to1 . ";" . $to2;
$subject = "MDI Imaging & Reffering Physician - Order";
$headers = array ('From' => $from,'To' => $to, 'Subject' => $subject);
$text = "Hi,\r\n\r\nPlease find the attached receipt for Order Placed at MDF Imaging & Referring Physician\r\n\r\nRegards\r\nMDF Imaging & Referring Physician";
$file = $filename; // attachment
$crlf = "\n";
//  $mime = new Mail_mime($crlf);
//  $mime->setTXTBody($text);
//  $mime->addAttachment($file, 'text/plain');
//  $body = $mime->get();
//  $headers = $mime->headers($headers);
//  $smtp = Mail::factory('smtp', array ('host' => $host, 'auth' => false, 'username' => $username,'password' => $password));
//  $mail = $smtp->send($to, $headers, $body);

//email to facility
$fac = $_REQUEST['facility'];
$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tblfacility where fldFacilityName = '$fac'"));
if($sql_values_fetch['fldEmailOrder'] == 1)
{
$to = $sql_values_fetch['fldEmail'];
$mail = $smtp->send($to, $headers, $body);
}


$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tblsettings"));
$txtdest=$sql_values_fetch['flddmwl'];

$stringData0 = "[RecordNum1] \r";
$stringData0 .= "Patient Name = " . $_REQUEST['lastname'] . "\t^" . $_REQUEST['firstname'] . "\r";
$stringData0 .= "Patient ID = " . $_REQUEST['patientid'] . "\r";

$stringData0 .= "Date of Birth = " . $newdob . "\r";
$stringData0 .= "Additional Patient History = " . $_REQUEST['history'] . "\r";
$stemp = $_REQUEST['sex'];
if ($stemp == 'male')
{
$txtsex = 'M';
}
if ($stemp == 'female')
{
$txtsex = 'F';
}
$stringData0 .= "Sex = " . $txtsex. "\r";
function formatDatez($dDate){
$dNewDate = strtotime($dDate);
return date('Ymd-His',$dNewDate);
}

$stringData1 = "Referring Physician = " . $ordphy . "\r";
$stringData1 .= "Scheduled AE Station = crvan \r";

$schdate = date('Y-m-d',strtotime(formatdate($_REQUEST['schdate12']) . ' ' . $_REQUEST['schdate22']));
$schtime = date('H:i',strtotime(formatdate($_REQUEST['schdate12']) . ' ' . $_REQUEST['schdate22']));
$stringData2 = "Scheduled Start Date = " . $schdate . "\r";
$stringData2 .= "Scheduled Start Time = " . $schtime . "\r";

$dob = $_REQUEST['dob'];
$sDate = split('-', $dob);
$sDate1 = $sDate[2].$sDate[0].$sDate[1];
$hi7_dob=$sDate1;


$hi7dest="hi7/";
$hi7_time=date("mdY",time());

$hi7_1="MSH|^~\&|Ig bu|MDImaging|Test|MD Imaging|";
$hi7_2 .="||ORM^O01|00000";
$hi7_2 .=$hi7_time;
$hi7_2 .="|P|2.3|||NE|NE" . "\r";
$hi7_2 .="PID|";
$hi7_2 .=$_REQUEST['patientid'];
$hi7_2 .="|";
$hi7_2 .=$_REQUEST['patientid'];
$hi7_2 .="|";
$hi7_2 .=$_REQUEST['patientid'];
$hi7_21 =$_REQUEST['lastname'] . "^" . $_REQUEST['firstname'] . "^" . $_REQUEST['middlename'] . "^" . $_REQUEST['surname'];
$hi7_21 .="||";
$hi7_21 .=$hi7_dob;
$hi7_21 .="|";
$hi7_21 .=$txtsex;
$hi7_21 .="||U|||||U|||000-00-0000" . "\r";
$hi7_21 .="PV1|";
$hi7_21 .=$_REQUEST['patientid'];
$hi7_21 .="|O|BUF^^buffalo^MDImaging||||Referring|";
$hi7_21 .=$ordphy . "\r";
$hi7_21 .="ORC|SC|";
$hi7_3 .="|S||^^^";
$hi7_3 .=$hi7_time;
$hi7_3 .="^^N||||||||||||||MD Imaging" . "\r";
$hi7_3 .="OBR|1|";

$pr1 = $_REQUEST['procedure1'];
if($pr1)
{
$myFile = $txtdest . $txtid . "p1.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr1'"));
$atime=date("Y-m-d H:i:s",time() + 1);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno1='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " . $_REQUEST['symptoms1'] . "\r" . $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r";
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr1'] . " " . $_REQUEST['procedure1'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr1'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr1'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms1'];

fwrite($fh, $hi7_txt);
fclose($fh);
}

$pr2 = $_REQUEST['procedure2'];
if($pr2)
{
$myFile = $txtdest . $txtid . "p2.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr2'"));
$atime=date("Y-m-d H:i:s",time() + 2);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno2='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " .$_REQUEST['symptoms2'] . "\r" . $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r" ;
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr2'] . " " . $_REQUEST['procedure2'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "-2||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr2'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr2'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms2'];

fwrite($fh, $hi7_txt);
fclose($fh);
}

$pr3 = $_REQUEST['procedure3'];
if($pr3)
{
$myFile = $txtdest . $txtid . "p3.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr3'"));
$atime=date("Y-m-d H:i:s",time() + 3);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno3='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " .$_REQUEST['symptoms3'] . "\r" .  $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r" ;
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr3'] . " " . $_REQUEST['procedure3'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "-3||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr3'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr3'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms3'];

fwrite($fh, $hi7_txt);
fclose($fh);
}

$pr4 = $_REQUEST['procedure4'];
if($pr4)
{
$myFile = $txtdest . $txtid . "p4.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr4'"));
$atime=date("Y-m-d H:i:s",time() + 4);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno4='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " .$_REQUEST['symptoms4'] . "\r" .  $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r" ;
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr4'] . " " . $_REQUEST['procedure4'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "-4||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr4'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr4'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms4'];

fwrite($fh, $hi7_txt);
fclose($fh);
}

$pr5 = $_REQUEST['procedure5'];
if($pr5)
{
$myFile = $txtdest . $txtid . "p5.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr5'"));
$atime=date("Y-m-d H:i:s",time() + 5);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno5='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " .$_REQUEST['symptoms5'] . "\r" .  $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r" ;
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr5'] . " " . $_REQUEST['procedure5'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "-5||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr5'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr5'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms5'];

fwrite($fh, $hi7_txt);
fclose($fh);
}

$pr6 = $_REQUEST['procedure6'];
if($pr6)
{
$myFile = $txtdest . $txtid . "p6.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$sql_values_fetch_mod = mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$pr6'"));
$atime=date("Y-m-d H:i:s",time() + 6);
$acsno = formatDatez($atime);

$sql_Update	= mysql_query("update tblorderdetails set
fldacsno6='".strtoupper(strip_tags(addslashes($acsno)))."'
where fldID='".$id."'") or die (mysql_error());

$stringData = $stringData0 . "Accession Number  = " . $acsno . "\r" . "Admitting Diagnoses Discription  = " .$_REQUEST['symptoms6'] . "\r" .  $stringData1 . "Modality = " . $sql_values_fetch_mod['fldModality'] . "\r" ;
$stringData .= $stringData2 . "Requested Procedure ID =  " . $sql_values_fetch_mod['fldCBTCode'] . "\r"  . "Requested Procedure Description = " . $_REQUEST['plr6'] . " " . $_REQUEST['procedure6'] . "\r";
$stringData = strtoupper($stringData);
fwrite($fh, $stringData);
fclose($fh);

$myFile = $hi7dest . $acsno . ".txt";
$fh = fopen($myFile, 'w') or die("can't open file");

$hi7_txt=$hi7_1 .  $acsno . $hi7_2 . "-6||" . $hi7_21 . $acsno . "||^" . $_REQUEST['plr6'] .  $hi7_3 . $acsno . "||" . $sql_values_fetch_mod['fldCBTCode'] . "^" . $_REQUEST['plr6'];
$hi7_txt .="|||||||||||||||||||||||||||" . $_REQUEST['symptoms6'];

fwrite($fh, $hi6_txt);
fclose($fh);
}

$redirecturl = "index.php?pg=20";
header("location:".$redirecturl);

}
}
?>

