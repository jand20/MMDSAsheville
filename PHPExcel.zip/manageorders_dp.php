<?php

	session_start();

	//check user logged
	if(!isset($_SESSION['user']) || $_SESSION['user'] == '')
	{
		header("Location:index.php");
		die;
	}

	//get info
	$role		= $_SESSION['role'];
	$userState	= $_SESSION['userState'];
	$userName	= $_SESSION['user'];
	$userId		= $_SESSION['userID'];
	$facility	=$_SESSION['facility'];

	if($role == 'biller')
	{
		header("Location: index.php?pg=55");
		die;
	}

	//do process EsignAll, recode with optimized, just use a query
	if($_REQUEST['action'] =="ESignAllSelected")
	{
		require_once 'config.php';

		$selected_orders = $_REQUEST['selected_orders'];
		if(!empty($selected_orders))
		{
			$selected_orders = implode(', ', $selected_orders);
			$query = "UPDATE tblorderdetails
						SET fldAuthorized='1', fldAuthDate=now()
						WHERE fldID IN ($selected_orders)";
			mysql_query($query);
		}

		mysql_close();
	}

	//for divisions
	require_once 'division_config.php';

?>
<!DOCTYPE html PUBLIC "-//W3C//Dth XHTML 1.0 Strict//EN" "https://www.w3.org/TR/xhtml1/Dth/xhtml1-strict.dth">
<html>
	<head>
		<title>MD Imaging</title>
		<link href="menu/menu_style.css" rel="stylesheet" type="text/css" />
		<link href='style.css'  rel="stylesheet" type="text/css" />
		<link href='tablesort_new.css'  rel="stylesheet" type="text/css" />
		<link href="paginate.css"   rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="map_images/fancybox/jquery.fancybox-1.3.4.css" media="screen" />
		<style>

			body{
				font-size: 12px; font-family: sans-serif;
			}

			.fdtablePaginatorWrapTop { display:none; }

			#top1 {
			  background: url(top.png);
			  position: absolute;
			  top: 0px;
			  left: 0px;
			  width: 66px;
			  height: 22px;
			  padding-left:5px;
			}
			#top2 {
			  background: url(top.png);
			  position: absolute;
			  top: 0px;
			  left: 70px;
			  width: 100%;
			  height: 22px;
			  vertical-align:middle;
			}
			#top2a {
			  position: absolute;
			  top: 5px;
			  left: 0px;
			  width: 100%;
			  height: 17px;
			  vertical-align:middle;
			}
			#top3 {
			  background: url(top.png);
			  position: absolute;
			  left: 95%;
			  top: 0px;
			  width: 64px;
			  height: 22px;
			}

			#header1 {
			  background: url(bg.png);
			  position: absolute;
			  top: 22px;
			  vertical-align: top;
			  left: 0px;
			  width: 100%;
			  height: 79px;
			}

			#header2 {
			  background: url(bg.png);
			  position: absolute;
			  top: 22px;
			  left: 500px;
			  width: 550px;
			  height: 79px;
			}

			#menuad {
				  background: url(main.png);
				  position: absolute;
				  top: 101px;
				  left: 0px;
				  text-align: left;
				  width: 100%;
				  <? if($role =='admin') { ?>
				  height: 40px;
				  <? } else { ?>
				  height: 25px;
				  <? } ?>
			}

			#content {
			  position: absolute;
			  <? if($role =='admin') { ?>
			  top: 141px;
			  <? } else { ?>
			  top: 126px;
			  <? } ?>
			  left: 0px;
			  width: 1050px;
			  height: auto;
			}

		</style>
	</head>
<body>
			<div id="top1">
				<img src="home.png" border="0" usemap="#Map" />
				<map name="Map">
					<area shape="rect" coords="3,3,46,19" href="index.php?pg=20" />
				</map>
			</div>
			<div id="top2">
				<?php
					include 'top_nav.php';
				?>
			</div>
			<div id="top3"><a href="logout.php"><img src="logout.png" border="0" /></a></div>
			<div id="header1"><img src="logo.png" align="left" /></div>

<?php
if( $role == 'admin' )
{
?>
<div id="menuad">
<script src="menujs.js" type="text/javascript"></script>
<noscript>
	<OBJECT id="menuobj" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
			codebase="https://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0"
			width="1050" height="45">
	 <PARAM NAME="movie" VALUE="menu.swf" />
	 <PARAM NAME="menu" VALUE="false" />
	 <PARAM NAME="quality" VALUE="high" />
	 <PARAM NAME="bgcolor" VALUE="#DDE6EA" />
	 <EMBED src="menu.swf" menu="false" quality="high" bgcolor="#DDE6EA"  WIDTH="1050" HEIGHT="45" TYPE="application/x-shockwave-flash" PLUGINSPAGE="https://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash">
	 </EMBED>
	 </OBJECT>
 </noscript>
</div>
<?php
}
?>


<div style="float: left;width: 100%; padding-top: 140px; padding-bottom: 100px;">

	<form id="frmSearch">
		<table cellpadding="0" cellspacing="0">
			<thead>
			<tr>
				<?php
					if($role == 'admin' || $role == 'dispatcher')
					{
						echo '<th>Select division'. getDivisionCombo().'</th>';
					}

					echo '
					<th>Others Keyword<br/>
						<input id="keyword" name="keyword" />
						<select id="keywordType" class="myselect1" style="width:120px;" name="keywordType">
							<option value="fldPatientSSN">Patient ID</option>
							<option value="fldLastName">Last Name</option>
							<option value="fldFirstName">First Name</option>
							<option value="fldDate">Order Date</option>
							<option value="fldSchDate">Exam Date</option>
							<option value="fldFacilityName">Facility</option>
						</select>
					</th>';

					echo '
					<th><input type="checkbox" value="1" name="lab" id="lab" /> Lab only</th>';


					if($role == 'admin')
					{
						echo '<th>State
									<select id="state" name="state" class="myselect2" style="width:120px;">
										<option value="">All</option>
										<option value="CO">CO</option>
										<option value="AZ">AZ</option>
									</select>
							</th>';
					}
					else
					{
						//if not admin, just use fixed hidden state,
						echo '<input type="hidden" value="'.$userState.'" name="state" />';
					}
				?>
				<th>Time
					<select id="time" class="myselect1" style="width:120px;" name="time">
						<option value="today">Today</option>
						<option value="week">This Week</option>
						<option value="month">This Month</option>
						<option value="nondist">Non Dispatched</option>
						<option value="all">Show All</option>
					</select>
				</th>
				<th>
					<input type="button" id="doSearch" value="LOAD" />
				</th>
				<th align="center" valign="middle"><div align="right">
				  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="https://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="105" height="23">
					<param name="movie" value="button1.swf" />
					<param name="quality" value="high" />
					<param name="bgcolor" value="#CAE8EA" />
					<embed src="button1.swf" quality="high" pluginspage="https://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="105" height="23" bgcolor="#CAE8EA"></embed>
				  </object>
				</div></th>
			</tr>
			</thead>
		</table>
	</form>
	<div id="mainList" style="width:100%">

	</div>
</div>
<div style="display: none;" >
	<img src="map_images/ajax_loader.gif" />
</div>

</body>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.3/jquery.min.js"></script>
<script type="text/javascript" src="map_images/jquery.blockUI.js"></script>
<script type="text/javascript" src="map_images/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<script type="text/javascript" src="common.js"></script>
<script type="text/javascript">

	/*----------- Old functions -------------------*/
	function show_confirm()
	{
		return confirm("Are you sure you want  to delete this Order");
	}

	function unselectCheckall()
	{
		document.getElementById("checkAllCheckbox").checked = false;
	}

	function selectAll()
	{
		var x =document.getElementsByName('selected_orders[]');
		var status = document.getElementById("checkAllCheckbox").checked;
		for(i=0;i<x.length;i++)
		{
			x[i].checked = status;
		}
	}

	function selectAllButton()
	{
		document.getElementById("checkAllCheckbox").checked = true;
		selectAll();
	}

	function eSignAll()
	{
		if(confirm("Are you sure you want to E-Sign all selected orders?"))
		{
			var args;
			var x=document.getElementsByName('selected_orders[]');
			for(i=0;i<x.length;i++)
			{
				if(x[i].checked == true )
				{
					args +="&selected_orders[]="+x[i].value;
				}
			}
			window.location.href="manageorders_new.php?action=ESignAllSelected&"+args;
		}
	}

	/*----------- End old functions -------------------*/


	var currentPage = 1;
	var formCache = null;

	//init sort is : undispatch, dispatched incompleted, dispatched completed
	var sortField	= 'tblorderdetails.fldDispatched, tblorderdetails.fldExamDate, tblorderdetails.fldSchDate';
	var sortBy		= 'ASC';
	var initView	= 1;

	$(document).ready(function(){
			list();

			$('#doSearch').click(function(){
				formCache = exportForm('frmSearch');
				//click to search, override init view rule
				sortField = 2; //Exam Date
				initView = 0;
				list();
			});
	});

	function list()
	{
		//assign current vars form search
		var form = $('#frmSearch').serializeArray();
		form[form.length] = {name : 'page' , value : currentPage};
		form[form.length] = {name : 'sortField' , value : sortField};
		form[form.length] = {name : 'sortBy' , value : sortBy};
		form[form.length] = {name : 'initView' , value : initView};

		$.ajax({
						url: 'get_order_list.php',
						type: 'POST',
						data: form,
						dataType: 'json',
						timeout: 600000,
						beforeSend: function(){
								$('#mainList').html('<img src="map_images/ajax_loader.gif" />');
						},
						error: function(data){
                                alert('Canot process. Error :' + data);
                        },
					    success: function(returnData) {

							if(returnData.data == 'TIME_OUT')
							{
								alert('TIME OUT. Please relogin');
								window.location = 'logout.php';
								return;
							}

							$('#mainList').html(returnData.data);

							$('a.sortColumn').click(function(){
								sortField = $(this).attr('rel');
								//if sort colum, we override init view order rule
								initView = 0;
								if(sortBy == 'ASC') sortBy = 'DESC';
								else sortBy = 'ASC';
								list();
							})

							$('a.paging').click(function(){
								//click paging to view next page, so should keep the order
								currentPage = $(this).attr('rel');
								list();
							})

							$('a.markCompleted').click(function(){
								doMarkComplete($(this).attr('rel'));
								return false;
							})

							$('a.showHistory').fancybox();

						}
		});

		return false;
	}

	function doMarkComplete(id)
	{
		$.ajax({
						url: 'ajax_process_order_record.php',
						type: 'POST',
						data: 'id=' + id + '&action=mark_completed',
						dataType: 'json',
						timeout: 600000,
						beforeSend: function(){
								$('#mainList').html('<img src="map_images/ajax_loader.gif" />');
						},
						error: function(data){
                                alert('Canot process. Error :' + data);
                        },
					    success: function(returnData) {

							if(returnData.data == 'TIME_OUT')
							{
								alert('TIME OUT. Please relogin');
								window.location = 'logout.php';
								return;
							}

							alert(returnData.data);

							list();

						}
		});
	}

	//reload for 2 min
	setInterval("list()", 120000);

</script>
</html>