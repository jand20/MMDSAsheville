<?php

	//----------------------
	// SONIT
	//function cloned code from map_process.php
	function getAdditionContent($id)
	{
		//			$query	= "SELECT tblorderdetails.*,
//								DATE_FORMAT(tblorderdetails.fldDate,'%m-%d-%Y %H:%i') AS dateExam,
//								tblfacility.fldAddressLine1,
//								tblfacility.fldAddressLine2,
//								tblfacility.fldAddressCity,
//								tblfacility.fldAddressState
//							FROM tblorderdetails
//								INNER JOIN tblfacility
//										ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
//							WHERE tblorderdetails.fldID = '$id'";
		$query = "SELECT tblfacility.*,
							tblorderdetails.fldStation,
							tblstations.StationPhone,
							tblstations.StationFax,
							tblorderdetails.fldOrderType,
							tblorderdetails.fldPrivateAddressLine1,
							tblorderdetails.fldPrivateAddressLine2,
							tblorderdetails.fldPrivateAddressCity,
							tblorderdetails.fldPrivateAddressState,
							tblorderdetails.fldPrivateAddressZip,
							DATE_FORMAT(tblorderdetails.fldDate,'%m-%d-%Y %H:%i') AS dateExam,
							tblfacility.fldAddressLine1,
							tblfacility.fldAddressLine2,
							tblfacility.fldAddressCity,
							tblfacility.fldAddressState,
							tblorderdetails.fldSymptoms,
							tblorderdetails.fldLastName,
							tblorderdetails.fldFirstName,
							tblorderdetails.fldProcedure1,
							tblorderdetails.fldProcedure2,
							tblorderdetails.fldProcedure3,
							tblorderdetails.fldProcedure4,
							tblorderdetails.fldProcedure5,
							tblorderdetails.fldProcedure6,
							tblorderdetails.fldProcedure7,
							tblorderdetails.fldProcedure8,
							tblorderdetails.fldProcedure9,
							tblorderdetails.fldProcedure10
						FROM tblorderdetails
							INNER JOIN tblfacility
								ON tblfacility.fldFacilityName = tblorderdetails.fldFacilityName
							LEFT JOIN tblstations
								ON tblorderdetails.fldStation = tblstations.StationName
									AND tblstations.facId = tblfacility.fldID
						WHERE tblorderdetails.fldID = '$id'";

			//echo $query;die;

			$result = mysql_query($query);
			$row	= mysql_fetch_assoc($result);

			$content = array();

			$content[] = '<div style="width:600px; text-align:left;">';
			$content[] = "<p style='font-size:16px; font-weight:bold;color:#0000FF'>Additional Details</p>";
			$content[] = "<p><b>Facility Name:</b> {$row['fldFacilityName']}</p>";
			$content[] = "<p><b>Facility Station:</b> {$row['fldStation']}</p>";
			$content[] = "<p><b>Patient Name:</b> {$row['fldLastName']} {$row['fldFirstName']} </p>";
			$content[] = "<p><b>Phone Number:</b> {$row['fldPhoneNumber']}</p>";
			$content[] = "<p><b>Fax Number:</b> {$row['fldFaxNumber']}</p>";
			$content[] = "<p><b>Station Phone:</b>{$row['StationPhone']}</p>";
			$content[] = "<p><b>Station Fax:</b>{$row['StationFax']}</p>";
			$content[] = "<p><b>Date ordered :</b> {$row['dateExam']} </p>";

			if($row['fldOrderType'] != '3')
					$address = $row['fldAddressLine1']." ".$row['fldAddressLine2']." ".$row['fldAddressCity']." ".$row['fldAddressState'];
				else
					$address = $row['fldPrivateAddressLine1']." ".$row['fldPrivateAddressLine2']." ".$row['fldPrivateAddressCity']." ".$row['fldPrivateAddressState']." ".$row['fldPrivateAddressZip'];

			$content[] = "<p><b>Address:</b> {$address}</p>";
			$content[] = "<br/>";

			$procedure = array();
			for($i = 0 ; $i <= 10 ; $i++)
			{
				if($row['fldProcedure'.$i] != '')
					$procedure[] = "<p><b>Procedure{$i}:</b> ".$row['fldProcedure'.$i]." </p>";
			}
			$procedure = implode('', $procedure);

			$content[] = "<p><b>Procedures:</b></p>";
			$content[] = "$procedure";
			$content[] = "<br/>";

			$content[] = "<p><b>Main notes:</b> {$row['fldSymptoms']}</p>";

			$query	= "SELECT *,
							DATE_FORMAT(created_date, '%m-%d-%Y %H:%i') AS dateMake
							FROM order_notes WHERE order_id = '$id'";
			$result = mysql_query($query);

			if(mysql_num_rows($result))
			{
				while($row = mysql_fetch_assoc($result))
				{
					$content[] = "<p><b>Notes:</b> {$row['notes']}</p>";
					$content[] = "<p><b>On</b> {$row['dateMake']} <b>by</b> {$row['created_by']}</p>";
					$content[] = "<br/>";
				}
			}

			$content[] = '</div>';

			return implode('', $content);
	}

	function getPatientInfo($id)
	{
		$query = "SELECT tblorderdetails.*,
							DATE_FORMAT(fldDOB, '%m/%d/%Y') AS dateOfBirth
							FROM tblorderdetails
							WHERE tblorderdetails.fldID = '$id'";
			$result = mysql_query($query);
			$row	= mysql_fetch_assoc($result);

			$orderType = array(
				'1'	=> 'NH',
				'2'	=> 'CF',
				'3'	=> 'HB',
				'4'	=> 'Lab'
			);

			$content = array();
			$content[] = '<div style="width:400px; text-align:left;">';
			$content[] = "<p style='font-size:16px; font-weight:bold;color:#0000FF'>Patient Info</p>";
			$content[] = "<p><b>Patient Name :</b> {$row['fldLastName']}, {$row['fldFirstName']}</p>";
			$content[] = "<p><b>Order Type :</b> {$orderType[$row['fldOrderType']]}</p>";
			$content[] = "<p><b>Patient SSN :</b>{$row['fldPatientSSN']}</p>";
			$content[] = "<p><b>DOB :</b> {$row['dateOfBirth']}</p>";
			$content[] = "<p><b>Gender :</b> {$row['fldGender']}</p>";
			$content[] = '</div>';

			return implode('', $content);
	}
