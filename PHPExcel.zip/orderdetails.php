<?php # PMD 2012-01-16
session_start();
// if session is not set redirect the user
if(empty($_SESSION['user'])) header("Location:index.php");
include "config.php";
$sql_values_fetch = mysql_fetch_array( mysql_query("select *,
                                                    DATE_FORMAT(created_date,'%m/%d/%Y %H:%i') AS created_date_formated,
                                                    DATE_FORMAT(modified_date,'%m/%d/%Y %H:%i') AS modified_date_formated
                                                    from tblorderdetails where fldID='$id'"));
$sql_values_icd =   mysql_fetch_array( mysql_query("select * from tblicdcodes where fldOrderid='$id'"));
/*
require_once "Mail.php"; // PEAR Mail package
require_once ('Mail/mime.php'); // PEAR Mail_Mime packge
$host = "mail.mdipacs.net";
$username = "dpotter";
$password = "brasil06";
*/

$type = $sql_values_fetch['fldOrderType'];
$typearray = array("","Nursing Home Order","Correctional Facility","Home Bound Orders","Lab Orders");

?>
<script type="text/javascript">
function open_win()
{
    <?
    $sql_values_fetch_pdf = mysql_fetch_array(mysql_query("select * from tblsettings"));
    if($sql_values_fetch['fldAuthorized'] == 1)
    {
        $dest = $sql_values_fetch_pdf['fldPDFSignedOrders'];
        $pdate = $sql_values_fetch['fldAuthDate'];
        $sign = "s";
    }
    else
    {
        $dest = $sql_values_fetch_pdf['fldPDFUnsignedOrders'];
        $pdate = $sql_values_fetch['fldCreDate'];
        $sign = "u";
    }
    $filename = $dest . $sign . $pdate . $sql_values_fetch['fldLastName'] . $sql_values_fetch['fldFirstName'] . "_" . $id . ".pdf";
    ?>
    window.open("<?echo $filename; ?>")
}
</script>
<link href="style.css" rel="stylesheet" type="text/css" />
<form action="" method="post">
<table width="1050" border="0" cellpadding="0" cellspacing="0" background="main.png">
  <tr>
    <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td class="lab">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
           <tr><td colspan='6' style='text-align:right;font-weight:bold;font-size:1.2em;text-decoration:underline;'><font face='arial' size='2em'><?=$typearray[$type]?></font></td></tr>

          <tr><!--
            <td width="9%"><span class="lab">Today Date</span></td>
            <td width="16%"><span class="dis">
              <?echo date('m-d-Y' ,strtotime($sql_values_fetch['fldDate']));?>
              </span></td>
            <td width="13%" class="lab">Today Time </td>
            <td width="16%"><span class="dis">
              <?echo date('g:i A' ,strtotime($sql_values_fetch['fldDate']));?>
            </span></td>-->
            <td colspan="8" align="left">
            <?php
                
            if($_SESSION['role']=='admin' || $_SESSION['role']=='dispatcher'){
                
                $myTemp = array();
                if( $sql_values_fetch['created_by'] != '' )
                {
                    $myTemp[] = '<span class="lab"">Ordered by:</span><span class="dis"> '.$sql_values_fetch['created_by'].' '.$sql_values_fetch['created_date_formated'].'</span>';
                }
                
                if( $sql_values_fetch['modified_by'] != '' )
                {
                    $myTemp[] = '<span class="lab"">Last Edited by:</span><span class="dis"> '.$sql_values_fetch['modified_by'].' '.$sql_values_fetch['modified_date_formated'].'</span>';
                }
                echo implode('&nbsp;&nbsp;', $myTemp);
                
             }
             
            ?>
            </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="10%"><span class="lab">Last name</span></td>
            <td width="20%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldLastName'])?>
            </span></td>
            <td width="15%"><span class="lab">First name</span></td>
            <td width="20%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldFirstName'])?>
            </span></td>
            <td width="10%"><span class="lab">Middle name</span></td>
            <td width="20%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldMiddleName'])?>
            </span></td>
            <td width="8%"><span class="lab">Jr, Sr, II</span></td>
            <td width="15%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldSurName'])?>
            </span></td>
          </tr>
          <tr>
            <td width="9%"><span class="lab"><?if ($type==2){echo"Inmate ID# ";}else{echo"Patient MR# ";}?> </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPatientID'])?>
            </span></td>
            <?
            function formatDateddmmyy($dDate){
            $dNewDate = strtotime($dDate);
            return date('m-d-Y',$dNewDate);
            }
            $ddob="MM-DD-YYYY";
            $fdob = $sql_values_fetch['fldDOB'];
            if($fdob!='')
            {
            $ddob = formatDateddmmyy($fdob);
            }
            ?>
            <td><span class="lab">DOB (MM-DD-YYYY)</span></td>
            <td><span class="dis">
              <?=$ddob?>
            </span></td>
            <?if($type == 1 || $type == 3|| $type == 4){?>
            <td><span class="lab">Patient SSN</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPatientSSN'])?>
            </span></td>
            <?} else {?>
                <td>&nbsp;</td><td>&nbsp;</td>
            <?}?>
            <td><span class="lab">Sex</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldGender'])?>
            </span></td>
          </tr>
            <?if ($type == 2) {?>

                <tr>
                 <td><span class="lab">Housing #</span></td>
                 <td><?=$sql_values_fetch['fldPrivateHousingNo']?></td>
                 <td>&nbsp;</td>
                 <td>&nbsp;</td>
                </tr>
                <tr>
                <td><span class="lab">Station: </span></td>
                <td class="dis">
                <?echo $sql_values_fetch['fldStation'];?>
                </td>
                </tr>
                <tr><td><span class='lab'>Stat </span></td><td class='dis'><? if($sql_values_fetch['fldStat'] == 1) {echo 'YES';} else {echo 'NO';} ?></td></tr>
            <?}?>
        </table></td>
      </tr>
      <?if($type==3 || $type==4){?>
        <tr><td colspan='8'><table>
      <tr>
        <td width="9%"><span class="lab">Location/Facility </span></td>
        <td colspan="3" class="dis"><?=$sql_values_fetch['fldLocFacName'];?></td>
        </tr>
        </table></td></tr>
    <? if($type ==4){ ?>
        <tr><td colspan='8'><table>
        <tr><td class="lab">Station</td>
        <td class="dis"><?=$sql_values_fetch['fldStation'];?>
        </td>
        </tr>
        </table></td></tr>
        
         <tr><td><table>
           <tr>          
            <td><span class="lab">Room #</span></td>
            <td  class="dis"><?=$sql_values_fetch['fldPatientroom']?></td>
            <td colspan='4'></td>
        </tr></table></td></tr>
    <?}?>
    <tr><td colspan='8'><table>
      <tr>
          <td><span class="lab">Address #1</span></td>
          <td class="dis"><?echo($sql_values_fetch['fldPrivateAddressLine1']=='UNDEFINED'?'':$sql_values_fetch['fldPrivateAddressLine1']);?></td>
      </tr>
      <tr>
          <td><span class="lab">Address #2 </span></td>
          <td class="dis"><?echo($sql_values_fetch['fldPrivateAddressLine2']=='UNDEFINED'?'':$sql_values_fetch['fldPrivateAddressLine2']);?></td>
      </tr>
      <tr>
          <td><span class="lab">City</span></td>
          <td class="dis"><?echo($sql_values_fetch['fldPrivateAddressCity']=='UNDEFINED'?'':$sql_values_fetch['fldPrivateAddressCity']);?></td>
      </tr>
        <tr>
          <td><span class="lab">State </span></td>
          <td class="dis"><?echo($sql_values_fetch['fldPrivateAddressState']=='UNDEFINED'?'':$sql_values_fetch['fldPrivateAddressState']);?></td>
        </tr>
          <tr>
            <td><span class="lab">Zip</span></td>
            <td class="dis"><?echo($sql_values_fetch['fldPrivateAddressZip']=='UNDEFINED'?'':$sql_values_fetch['fldPrivateAddressZip']);?></td>
          </tr>    
    <?if($type == 3 ){?>
      <tr>
        <td><span class="lab">Phone #</span></td>
        <td><span class="dis">
          <?=strtoupper($sql_values_fetch['fldPrivateResidenceNumber'])?>
        </span></td>
      </tr>
    <?}?>
      </table></td></tr>
    <?}?>
      <tr>
        <td>&nbsp;</td>
      </tr>
    <?if($type == 4){?>
        <tr><td colspan='8'><table>
        <tr>
            <td class="lab" style='white-space:nowrap;'>Test Priority </td>
            <td class="dis"><? echo "Weekend : ".$sql_values_fetch['fldTestPriority']; ?></td> <td class="dis"><? echo "Stat : ".$sql_values_fetch['fldStat']; ?></td>
        </tr>
        </table>
        </td>
        </tr>
        <tr><td colspan="8"><table>
        <tr>
            <td class="lab"  width="11%" style='white-space:nowrap;'>Ordering Dr.</td>
            <td class="dis" style='white-space:nowrap;'><?=$sql_values_fetch['fldOrderingPhysicians'];?></td>
         </tr></table>
          </td>
      </tr>
          <tr><td colspan="8"><table>
          <tr>
               <td class="lab" colspan='2'>Diagnosis Required 1)</td>
               <td class="dis"><?=$sql_values_fetch['fldDiagnosisReuired1']?></td>
          </tr>
          <tr>
               <td class="lab" style='text-align:right;'  colspan='2'>2)</td>
               <td class="dis"><?=$sql_values_fetch['fldDiagnosisReuired2']?></td>
          </tr>
          <tr>
               <td class="lab" style='text-align:right;'  colspan='2'>3)</td>
               <td class="dis"><?=$sql_values_fetch['fldDiagnosisReuired3']?></td>
          </tr></table>
          </td>
      </tr>
    <?}?>      
            
  <?if($type == 1){?>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                <td><span class="lab">Contact</span></td>
                <td><span class="dis">
                  <?=strtoupper($sql_values_fetch['fldRequestedBy'])?>
                </span></td>
                <td width="9%"><span class="lab">Facility Name </span></td>
                <td colspan="5"><span class="dis">
                  <?=strtoupper($sql_values_fetch['fldFacilityName'])?>
                </span></td>

                <td class="lab"> Phone </td>
                <td colspan="2" class="lab"><div id="txtHint"><span class="dis">
                    <?=strtoupper($sql_values_fetch['fldFacPhone'])?>
                </span></div></td>
                <td class="lab"> Fax </td>
                <td colspan="2" class="lab"><div id="txtHint"><span class="dis">
                    <?=strtoupper($sql_values_fetch['fldFacFax'])?>
                </span></div></td>          </tr>
              <tr>
                <td width="7%"><span class="lab">Room #</span></td>
                <td width="15%"><span class="dis">
                  <?=strtoupper($sql_values_fetch['fldPatientroom'])?>
                </span></td>
                <td><span class="lab">Stat/Normal</span></td>
                <td width="8%"><span class="dis">
                  <? if($sql_values_fetch['fldStat'] == 1) {?>
                  Stat
                  <? } else { ?>
                  NORMAL
                  <? } ?>
                </span></td>

                <td width="9%"><span class="lab">After Hours</span></td>
                <td width="9%"><span class="dis">
                  <? if($sql_values_fetch['fldAfterhours'] == 1) {?>
                  YES
                  <? } else { ?>
                  NO
                  <? } ?>
                </span></td>
          </tr>
          <tr>
          <td><span class="lab">Station: </span></td>
          <td class="dis">
          <?echo $sql_values_fetch['fldStation'];?>
          </td>
          </tr>
        </table></td>
      </tr>
          <?} else if($type == 2 ){?>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

            <tr>
            <td width="9%"><span class="lab">Facility Name </span></td>
            <td width='60%'><span class="dis">
            <?=strtoupper($sql_values_fetch['fldFacilityName'])?>
            </span></td>
            <td><span class="lab">Report Phone</span></td>
            <td><div id="txtHint"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldFacPhone'])?>
            </span></div></td>
            </tr>
            
            <tr>
            <td><span class="lab">Room #1</span></td>
            <td class="dis"><?=strtoupper($sql_values_fetch['fldPatientroom'])?></td>
            <td><span class="lab">Report Fax</span></td>
            <td class="dis"><?=strtoupper($sql_values_fetch['fldReportFax'])?></td>
            </tr>
            <tr>
            <td colspan="2"></td>
            <td><span class="lab">Backup Phone</span></td>
            <td class="dis"><?=$sql_values_fetch['fldBackupPhone']?></td>
            </tr>
            <tr>
            <td colspan="2"></td>
            <td><span class="lab">Backup Fax</span></td>
            <td class="dis"><?=$sql_values_fetch['fldBackupFax']?></td>
            </tr>

        </table></td>
      </tr>
    <?} else if($type == 3 ){?>
            <tr><td colspan='8'><table>
            <tr>
                <td class="lab">Stat </td>
                <td class="dis"><? if($sql_values_fetch['fldStat'] == 1) {echo'Yes';} else {echo 'No';} ?></td>
            </tr>
            </table>
            </td>
            </tr>
           <tr><td colspan='8'><table>
            <tr>
            <td width="9%" style='white-space:nowrap;'><span class="lab">Ordering Facility </span></td>
            <td colspan="3" class="dis"><?=$sql_values_fetch['fldFacilityName']?></td>
            <td width="6%" class="lab">Phone </td>
            <td width="19%" class="dis"><?=$sql_values_fetch['fldFacPhone']?>'</td>
            <td width="6%" class="lab">Fax </td>
            <td width="19%" class="dis"><?=$sql_values_fetch['fldFacFax']?></td>
            </tr>
            </table></td></tr>
          <tr>
            <td colspan='4' style='text-align:left;'><table><tr>
            <td class="lab">Stairs :</td>
            <td class="dis"><? if($sql_values_fetch['fldStairs'] == 1) {echo "YES"; } else {echo "NO"; }?></td>
            <td class="lab"># of stairs :</td>
            <td  class="dis"><?=$sql_values_fetch['fldNstairs']?></td>
            <td ><span class="lab">Pets :</span></td>
            <td  class="dis"><? if($sql_values_fetch['fldPets'] == 1) {echo "YES";} else {echo "NO"; } ?></td>
          </tr></table></td></tr>
          <tr><td>&nbsp;</td></tr>
          <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><span class="lab">Notes</span></td>
            </tr>
            <tr>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldSymptoms'])?>
              </span></td>
            </tr>

    <?}?>
        <td>&nbsp;</td>
      </tr>


<?if($type != 4 ){?>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
        
        <? # loop start
        for ( $pntr = 1; $pntr < 11; $pntr++)
        {   
        ?>  
          <tr>
            <td width="9%"><span class="lab">Procedure #<? echo $pntr; ?></span></td>
            <td colspan="4"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldProcedure'.$pntr])?>
            </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldplr'.$pntr])?>
            </span></td>
            <td><span class="lab">Symptom</span></td>
            <td colspan="4"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldSymptom'.$pntr])?>
                        </span></td>
            </tr>
          <tr>
            <td><span class="lab">ICD9A</span></td>
            <td colspan="2"><span class="dis">
              <?=strtoupper($sql_values_icd['fldProc'.$pntr.'icd1'])?>
            </span></td>
            <td width="7%"><span class="lab">ICD9B</span></td>
            <td colspan="2"><span class="dis">
              <?=strtoupper($sql_values_icd['fldProc'.$pntr.'icd2'])?>
            </span></td>
            <td width="6%"><span class="lab">ICD9C</span></td>
            <td width="17%"><span class="dis">
              <?=strtoupper($sql_values_icd['fldProc'.$pntr.'icd3'])?>
            </span></td>
            <td width="7%"><span class="lab">ICD9D</span></td>
            <td width="20%"><span class="dis">
              <?=strtoupper($sql_values_icd['fldProc'.$pntr.'icd4'])?>
            </span></td>
          </tr>
          <tr>
            <td colspan="2"><span class="lab">Definiative Diagnosis </span></td>
            <td colspan="6"><span class="dis">
              <?=strtoupper($sql_values_icd['fldProc'.$pntr.'dig'])?>
            </span></td>
            <td><span class="lab">Ac No : </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldacsno'.$pntr])?>
            </span></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td colspan="2">&nbsp;</td>
            <td>&nbsp;</td>
            <td colspan="2">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        <? # End loop
        }
        ?>  
        </table></td>
      </tr>
      <?} else {?>
            <tr>
              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
              
              <? # loop start
              for ( $pntr = 1; $pntr < 11; $pntr++)
              {   
              ?>  
                <tr>
                  <td width="9%"><span class="lab">Test #<? echo $pntr; ?></span></td>
                  <td colspan="4"><span class="dis">
                    <?=strtoupper($sql_values_fetch['fldProcedure'.$pntr])?>
                  </span></td>
                  <td></td>
                  <td></td>
                  <td colspan="4"></td>
                  </tr>
                  <tr><td>&nbsp;</td></tr>
              <? # End loop
              }
              ?>  
              </table></td>
      </tr>
      <?}?>
      
      <tr>
        <td>&nbsp;</td>
      </tr>
    <?if($type != 3 ){?>      
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Additional Patient Info</span></td>
          </tr>
          <tr>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldSymptoms'])?>
            </span></td>
          </tr>
     <?}?>     
    <?if($type != 4 ){?>      
          <tr>
            <td><span class="lab">History:</span></td>
          </tr>
          <tr>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldHistory'])?>
            </span></td>
          </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Ordering Dr. </span></td>
            <td width='35%' style='white-spce:nowrap;'><span class="dis">
              <?=strtoupper($sql_values_fetch['fldOrderingPhysicians'])?>
            </span></td>
            <?
          $time=date("Y-m-d H:i",time());
          function formatDate21($dDate){
          $dNewDate = strtotime($dDate);
          return date('m-d-Y',$dNewDate);
          }
          function formatDate22($dDate){
            
            $dNewDate = strtotime($dDate);
            $t = date('g:i A',$dNewDate);
            if( $t == '12:00 AM' ){
                return '';
           }
            else{
                
                return '$t';

            }
          }
          $schdte=$sql_values_fetch['fldSchDate'];
          $time11=formatdate21($schdte);
          $time12=formatdate22($schdte);
          $cddte=$sql_values_fetch['fldCDDate'];
          $cddate=formatdate21($cddte);
          $refph=$sql_values_fetch['fldOrderingPhysicians'];
          $sql_user=mysql_fetch_array(mysql_query("SELECT * FROM tbluser where fldRealName='$refph'"));
          $phyph=$sql_user['fldPhone'];
          
          ?>
            <td><span class="lab">Phone : </span></td>
            <td width='15%'><span class="dis">
              <?=$sql_values_fetch['fldOrderingPhysiciansPhone']?>
            </span></td>
            <td><span class="lab">Fax : </span></td>
            <td width='15%'><span class="dis">
              <?=$sql_values_fetch['fldOrderingPhysiciansFax']?>
            </span></td>
            <td class="lab">Date Exam needed: </td>
            <td class="dis">
            <?echo "$time11 $time12"?>
            </td>
          </tr>
          
          <?if($type ==4 ){?>
          <tr>
            <td class="lab">CD Needed ? </td>
            <td width="12%"><span class="dis">
              <? if($sql_values_fetch['fldCDRequested'] == 1) {?>
              YES
              <? } else { ?>
              NO
              <? } ?>
            </span></td>
            <? if($sql_values_fetch['fldCDRequested'] == 1) {?>
            <td width="7%"><span class="lab">Location</span></td>
            <td colspan="4"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldCDAddr'])?>
            </span></td>
            <td width="10%" class="lab">Date CD needed </td>
            <td width="14%"><span class="dis">
              <?=strtoupper($cddate)?>
            </span></td>
            <? }
            else
            { ?>
            <td colspan="7">&nbsp;</td>
            <? } ?>
          </tr>
          <?}?>
        </table></td>
      </tr>
     <?} else{?>       
           <tr><td><table>
           <tr>    
             <td>
               <span class="lab">Date Draw/Order Requested </span></td>
             <td class='dis'><?echo formatDateddmmyy($sql_values_fetch['fldSchDate']);?></td>
             <td class="lab">&nbsp;&nbsp;Standing Order</td>
             <td><span class="dis"><?echo($sql_values_fetch['fldRepeat'] == 1?'YES': 'NO');?></span></span></td>
             </tr>
             <tr>
             <td class="lab">
                     Repeat Every <span class="dis"><?=$sql_values_fetch['fldRepeatDays']?></span> Days.<br>
                     Repeat <span class="dis"><?=$sql_values_fetch['fldRepeatTimes']?></span> Times.<br>
             </td>      
             </tr>
             </table></td>
      </tr>
     <?}?>
      <tr>
        <td>&nbsp;</td>
      </tr>      
      <tr>      
    <?if($type == 1 | $type == 4 ){?>
      <tr>
        <td><span class='lab'>Bill </span><span class='dis'><?if($sql_values_fetch['fldbilled'] == 'insurance'){echo 'Insurance';}else{echo 'Facility';}?></span></td>
      </tr>
        <?
        }
        if($type != 2){?>
        <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Insurance Type</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldInsurance'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td width="13%"><span class="lab">Medicare #</span></td>
            <td width="28%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldMedicareNumber'])?>
            </span></td>
            <td width="8%"><span class="lab">Medicaid #</span></td>
            <td width="24%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldMedicaidNumber'])?>
            </span></td>
            <td width="6%"><span class="lab">State #</span></td>
            <td width="21%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldState'])?>
            </span></td>
          </tr>
          <tr>
            <td><span class="lab" style='white-space:nowrap;'>Insurance Company </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldInsuranceCompanyName'])?>
            </span></td>
            <td><span class="lab">Policy #</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPolicy'])?>
            </span></td>
            <td><span class="lab">Group #</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldGroup'])?>
            </span></td>
          </tr>
          <tr>
            <td><span class="lab">HMO Name/Contract </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldHmoContract'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>

        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <?}?>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <?if($type==1 || $type == 3){?>
          <tr>
            <td width="13%"><span class="lab">Responsible Party:</span></td>
            <td width="28%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldResponsiblePerson'])?>
            </span></td>
            <td width="8%"><span class="lab">Relationship</span></td>
            <td width="51%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldRelationship'])?>
            </span></td>
          </tr>
      <?} else if($type ==2 ) {?>
          <tr>
            <td width="13%"><span class="lab">Guarantor:</span></td>
            <td width="28%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldResponsiblePerson'])?>
            </span></td>
            <td width="8%"></td>
            <td width="51%"></td>
      
      <?}
      if($type == 1 || $type == 2){
      ?>
          
          <tr>
            <td><span class="lab">Address #1</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivateAddressLine1'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Address #2 </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivateAddressLine2'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">City</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivateAddressCity'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">State </span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivateAddressState'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Zip</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivateAddressZip'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
         <?}else if($type == 3){?>
          <tr>
            <td><span class="lab">Phone #</span></td>
            <td><span class="dis">
              <?=strtoupper($sql_values_fetch['fldPrivatePhoneNumber'])?>
            </span></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        <?}?>          
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <?if($type != 4){?>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="12%"><span class="lab">Verbal Date</span></td>
            <td width="18%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldReportDate'])?>
            </span></td>
            <td width="12%"><span class="lab">Report Called To</span></td>
            <td width="22%"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldReportCalledTo'])?>
            </span></td>
            <td width="36%">&nbsp;</td>
            </tr>
            <tr><td>&nbsp;</td></tr>
          <tr>
            <td width="12%" ><span class="lab">Report Details</span></td>
            <td width="90%" style="word-wrap: break-word" colspan="5"><span class="dis">
              <?=strtoupper($sql_values_fetch['fldReportDetails'])?>
            </span></td>
          </tr>
          </tr>
        </table></td>
      </tr>
        <?
        }
        if($_SESSION['role']=='admin' || $_SESSION['role']=='dispatcher'){
        
        preg_match("/(\d{4})-(\d\d)-(\d\d) (\d\d:\d\d:\d\d)/",$sql_values_fetch['created_date'],$matches);
        $sql_values_fetch['created_date'] = $matches[2]."-".$matches[3]."-".$matches[1]." ".$matches[4];
        
        ?>
    <!--   <tr>
          <td>
          <table>
              <tr><td><span class="lab">Created By </span></td><td class="dis"><?=strtoupper($sql_values_fetch['created_by'])?></td></tr>
              <tr><td><span class="lab">Created On </span></td><td class="dis"><?=strtoupper($sql_values_fetch['created_date'])?></td></tr>
              <tr><td><span class="lab">Last Modified By </span></td><td class="dis"><?=strtoupper($sql_values_fetch['modified_by'])?></td></tr>
          </table>
          </td>
        </tr>
     -->   
        <?}?>
      
      <?if($type==1 || $type==3){
      if( $sql_values_fetch['fldAuthorized'] == 1 ){
        preg_match("/(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d\:\d\d\:\d\d)/",$sql_values_fetch['fldAuthDate'],$matches);
        $sql_values_fetch['fldAuthDate'] = $matches[2]."-".$matches[3]."-".$matches[1]." ".$matches[4];

        echo "<tr><td class=\"dis\">Esigned by  ".$sql_values_fetch['fldOrderingPhysicians']." on  ".$sql_values_fetch['fldAuthDate']."</td></tr>";
        }
        $sql = "SELECT * FROM tblfacility WHERE fldFacilityName='".$sql_values_fetch['fldFacilityName']."'";
        $res = mysql_query($sql);
        $fac = mysql_fetch_array($res);
        if($fac['fldReqDis'] =='0'){
         echo "<tr><td>&nbsp;</td></tr><tr><td class='lab' style='text-align:left;'>This patient would find it physically and/or psychologically taxing because of advanced age and/or physical limitation to receive an x-ray or EKG outside this location. This test is medically necessary for the diagnosis and treatment of this patient.</td></tr>";
        }
        }?>
      <tr>
        <td>&nbsp;</td>
      </tr>

      <tr>
        <td><table align="center">
          <tr>
            <td align="center"><input type="submit" name="back" value="Back" /></td>
            <td align="center"><input type="button" name="print" value="Print" onclick="window.print()"></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>

    </table></td>
  </tr>
</table>
</form>
<?php
if($_REQUEST['back']!='')
{
$redirecturl = "index.php?pg=20";
header("location:".$redirecturl);
}
if($_REQUEST['email']!='')
{
$sql_values_fetch_pdf = mysql_fetch_array(mysql_query("select * from tblsettings"));
    if($sql_values_fetch['fldAuthorized'] == 1)
    {
    $dest=$sql_values_fetch_pdf['fldPDFSignedOrders'];
    $pdate=$sql_values_fetch['fldAuthDate'];
    $sign="s";
    }
    else
    {
    $dest=$sql_values_fetch_pdf['fldPDFUnsignedOrders'];
    $pdate=$sql_values_fetch['fldCreDate'];
    $sign="u";
    }

$filename = $dest . $sign . $pdate . $sql_values_fetch['fldLastName'] . $sql_values_fetch['fldFirstName'] . "_" . $id . ".pdf";

////////////////////////////////////////
// Read POST request params into global vars
//$from = "Douglas <dpotter@mdipacs.net>";
//$to=$_REQUEST['temail'];
//$subject = "MDI Imaging & Reffering Physician - Order";
//$headers = array ('From' => $from,'To' => $to, 'Subject' => $subject);
//$text = "Hi,\r\n\r\nPlease find the Copy of your Order. \r\n\r\nRegards\r\nMDF Imaging & Referring Physician.";
//$file = $filename; // attachment
//$crlf = "\n";
//$mime = new Mail_mime($crlf);
//$mime->setTXTBody($text);
//$mime->addAttachment($file, 'text/plain');
//do not ever try to call these lines in reverse order
//$body = $mime->get();
//$headers = $mime->headers($headers);
//$smtp = Mail::factory('smtp', array ('host' => $host, 'auth' => false, 'username' => $username,'password' => $password));
//$mail = $smtp->send($to, $headers, $body);

}
?>