<?php # PMD 2012-01-16
session_start(); //if session is not set redirect the user
if(empty($_SESSION['user'])) header("Location:index.php");
include "config.php";
$user = $_SESSION['user'];
$sql_values_fetch = mysql_fetch_array( mysql_query("select * from tbluser where fldUserName='$user'") );
$fac = $sql_values_fetch['fldFacility'];
$uid = $sql_values_fetch['fldID'];

# "21" == "createorders.php";
# "42" == "createneworders.php";
# "71" == "createorders2.php";

#if($newpt == 1) { echo $pid; } else { echo $sql_values_fetch['fldPatientID'];

/*
echo "<pre>";
print_r($_REQUEST);
echo "</pre>";

require_once "Mail.php"; // PEAR Mail package
require_once ('Mail/mime.php'); // PEAR Mail_Mime packge
$host = "mail.mdipacs.net";
$username = "dpotter";
$password = "brasil06";
*/

include_once("mod_editfuncs.php"); 

if( $_REQUEST['submit'] != '' ) include "mod_saveneworder.php";

if( $id != "" )
{ # pulls up existing data?
	$sql_values_fetch = mysql_fetch_array( mysql_query("SELECT * FROM tblorderdetails WHERE fldID='$id'") );
	$sql = "SELECT * FROM tblorderdetails WHERE fldID LIKE '$id'";
	$result = mysql_query($sql) or die (mysql_error());
	$num = 0;
	$num = mysql_num_rows($result);
}

?>
<script type="text/javascript">
function search_prompt() 
{
	var retVal=""
	var valReturned;
	retVal=showModalDialog('searchpop.htm');
	valReturned=retVal;
	location.replace(valReturned);
}

function newpt() 
{
	location.replace('?pg=42');
}

function cdenable()
{
	if (document.getElementById('cdrequested').value != 0)
	{
		document.getElementById('cdaddrlab').style.display = '';
		document.getElementById('cddatelab').style.display = '';
		document.getElementById('cdaddr').style.display = '';
		document.getElementById('cddate').style.display = '';
	} 
	else
	{
		document.getElementById('cddatelab').style.display = 'none';
		document.getElementById('cdaddrlab').style.display = 'none';
		document.getElementById('cdaddr').style.display = 'none';
		document.getElementById('cddate').style.display = 'none';
	};
}

function phyenable()
{
	if (document.forms[0].orderingphysicians.value == "new")
	{
		document.forms[0].phynew.style.display = "inline";
	} 
	else
	{
		document.forms[0].phynew.style.display = "none";
	};
}
</script>
<script type="text/javascript" src="facility.js"></script>
<style type="text/css">
@import "timer/jquery.timeentry.css";
</style>

<link rel="stylesheet" type="text/css" href="datepick.css" /> 
<script type='text/javascript' src='datepick.js'></script>

<script type="text/javascript" src="timer/jquery-1.3.2.js"></script>
<script type="text/javascript" src="timer/jquery.min.js"></script>
<script type="text/javascript" src="timer/jquery.timeentry.js"></script>
<script type="text/javascript">
$(function () {
	$('#schdate2').timeEntry({spinnerImage: ''});
    $('#schdate22').timeEntry({spinnerImage: ''});

});
</script>
<?#  <script type="text/javascript" src="jquery-latest.js"></script> ?>
 <script type="text/javascript" src="jquery.validate.js"></script>
 <script type="text/javascript">
  $.validator.addMethod(
      "aDate",
      function(value, element) {
          return value.match(/^\d\d?\-\d\d?\-\d\d\d\d$/);

      },
      "Please enter a date in the format mm-dd-yyyy"
  );
  $.validator.addMethod(
      "aDate1",
      function(value, element) {
          var temp = new Array();
		  temp = value.split('-');
		  month=temp[0];
		  days=temp[1];
		  year=temp[2];
		  flag=1;
		  if(value.length<10)
		  flag=0;
		  if(year.length<4)
		  flag=0;
		  if(year<1600 || year>2400)
		  flag=0;
		  if(month.length<2)
		  flag=0;
		  if(month<1 || month>12)
		  flag=0;
		  if(days.length<2)
		  flag=0;
          if ((parseInt(year)%4) == 0){
              if (parseInt(year)%100 == 0){
                  if (parseInt(year)%400 != 0){
		    		mdays=28;
                  }
                 if (parseInt(year)%400 == 0){
		    		mdays=29;
                  }
              }
              if (parseInt(year)%100 != 0){
		    	mdays=29;
              }
          }
          if ((parseInt(year)%4) != 0){
		  mdays=28;
          }
          if(month=='01'||month=='03'||month=='05'||month=='07'||month=='08'||month=='10'||month=='12')
          mdays=31;
          if(month=='04'||month=='06'||month=='09'||month=='11')
          mdays=30;
		  if(days<1 || days>mdays)
		  flag=0;

          if(flag==1)
          return true;
          else
          return false;

      },
      "Please enter a date in the format mm-dd-yyyy"
  );

    $(document).ready(function() {
      $("#myform").validate({
        rules: {
        lastname: {
          required: true
        },
        firstname: {
          required: true
        },
        symptoms1: {
          required: true
        },
        dob: {
          required: true,
          aDate: true,
          aDate1: true
        },
        schdate12: {
          required: true,
          aDate: true,
          aDate1: true
        },
        patientssn: {
          required: true
        },
        sex: {
          required: true
        },
		History: {
          required: false
        },
        requester: {
          required: true
        },
        facility: {
          required: false
        },
        orderingphysicians: {
          required: true
        },
		medicare: {
          required: false
        }
        }
      });
    });
	
	function checkUserRole()
	{
		var stat = document.getElementsByName('stat')[0];
		
		if (stat.checked)
		{
<?php		if( $_SESSION['role'] == 'facilityuser' ) 
			{
					echo 'alert("your text here"); return false;';
			} ?>
		}
		return false;
	}
  </script>
<link href="style.css" rel="stylesheet" type="text/css" />

<? 
# Data Entry 
if ( !isset($schdate1) ) $schdate1 = date('m-d-Y' ,time());
if ( !isset($schdate2) ) $schdate2 = date('h:i A' , time());
if ( !isset($schdate12) ) $schdate12 = date('m-d-Y' , time());
{ 
?>

<form id="myform" action="" method="post" onsubmit="checkUserRole()">

<table width="1050" border="0" cellpadding="0" cellspacing="0" background="main.png">
  <tr>
    <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td>&nbsp;</td>
      </tr>
      <?if ($newpt != 1 && $num == 0 && $pid != 0 && $pid !="") {?>
      <tr>
        <td><div align="center"><span class="war"><strong>Patient doesn't exist</strong></span></div></td>
      </tr>
      <? } ?>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="9%"><span class="lab">Today Date</span></td>
            <td width="16%"><? doDatePick('schdate1',$schdate1); ?></td>
            <td width="31%"><input name="schdate2" id="schdate2" type="text" size="7" value="<?echo $schdate2;?>"/></td>
            <td width="6%">&nbsp;</td>
            <td width="25%">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="9%">&nbsp;</td>
            <td colspan="2">
			  <input type="button" name="retrive" id="retrive" onclick="search_prompt()" value="Search" />
              <input type="submit" name="new" id="new" value="New" />
			</td>
            <td width="17%">&nbsp;</td>
            <td width="9%">&nbsp;</td>
            <td width="17%">&nbsp;</td>
            <td width="6%">&nbsp;</td>
            <td width="13%">&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Last name</span></td>
            <td width="16%"><input type="text" name="lastname" id="lastname" class="myinput1" value="<?=$sql_values_fetch['fldLastName']?>" style="background-color: #FFFF99;"/></td>
            <td width="13%"><span class="lab">First name</span></td>
            <td><input type="text" name="firstname" id="firstname" class="myinput1" value="<?=$sql_values_fetch['fldFirstName']?>"  style="background-color: #FFFF99;"/></td>
            <td><span class="lab">Middle name</span></td>
            <td><input name="middlename" type="text" class="myinput1" value="<?=$sql_values_fetch['fldMiddleName']?>" /></td>
            <td><span class="lab">Jr, Sr, II</span></td>
            <td><input name="surname" type="text" class="myinput2" value="<?=$sql_values_fetch['fldSurName']?>" size="10" /></td>
          </tr>
          <tr>
            <td class="lab">Patient MR# </td>
            <td><input type="text" name="patientid" id="patientid" class="myinput2"  style="background-color: #FFFF99;" value="<?if($newpt == 1) { echo $pid; } else { echo $sql_values_fetch['fldPatientID']; }?>" size="10" /></td>
            <?
			function formatDateddmmyy($dDate)
			{
				if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') return '';
				$dNewDate = strtotime($dDate);
				return date('m-d-Y',$dNewDate);
			}
			$ddob = "MM-DD-YYYY";
			$fdob = $sql_values_fetch['fldDOB']; # yyyy-mm-dd
			if( $fdob != '' ) $ddob = formatDateddmmyy($fdob);
			?>
            <td><span class="lab">DOB (MM-DD-YYYY)</span></td>
            <td><input name="dob" type="text" class="myinput1" value="<?=$ddob?>" maxlength="10"  style="background-color: #FFFF99;"/></td>
            <td><span class="lab">Patient SSN</span></td>
            <td><input name="patientssn" type="text" class="myinput1" value="<?=$sql_values_fetch['fldPatientSSN']?>" style="background-color: #FFFF99;"/></td>
            <td><span class="lab">Sex</span></td>
            <td><select name="sex"  style="background-color: #FFFF99;">
              <option value="" <? if($sql_values_fetch['fldGender'] == '') {?> selected="selected" <? } ?>>Select</option>
              <option value="female" <? if($sql_values_fetch['fldGender'] == 'female') {?> selected="selected" <? } ?>>FEMALE</option>
              <option value="male" <? if($sql_values_fetch['fldGender'] == 'male') {?> selected="selected" <? } ?>>MALE</option>
            </select></td>
          </tr>
		  <tr>
            <td><span class="lab">Address #1</span></td>
            <td><input name="privatestreetaddress1" type="text" class="myinput3" value="<?=$sql_values_fetch['fldPrivateAddressLine1']?>" /></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Address #2 </span></td>
            <td><input name="privatestreetaddress2" type="text" class="myinput3" value="<?=$sql_values_fetch['fldPrivateAddressLine2']?>" /></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">City</span></td>
            <td><input name="privatecity" type="text" class="myinput3" value="<?=$sql_values_fetch['fldPrivateAddressCity']?>" /></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">State </span></td>
            <td><? doSelect("privatestate", $statesarray, $sql_values_fetch['fldPrivateAddressState'], 'myselect2'); ?></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><span class="lab">Zip</span></td>
            <td><input name="privatezipcode" type="text" class="myinput1" value="<?=$sql_values_fetch['fldPrivateAddressZip']?>" /></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Contact</span></td>
            <td><input name="requester" type="text" class="myinput1"  value="<?=$sql_values_fetch['fldRequestedBy']?>"  style="background-color: #FFFF99;"/></td>
            <td width="9%"><span class="lab">Facility Name </span></td>
            <td colspan="3"><select name="facility" class="myselect5" onchange="showUser(this.value)"  style="background-color: #FFFF99;">
              <?
			$sql = "SELECT * FROM tblfacility where 1 order by fldFacilityName";
			if( $_SESSION['role'] == 'facilityuser' )
			{
				$sql = "select fldFacility AS fldFacilityName from tbluserfacdetails where fldUserID = '$uid'";			
				echo $sql;
			}
			else 
			{ ?>
            <option selected="selected" value="">Select</option>
			<? }
			$result = mysql_query($sql);
			while($row = mysql_fetch_array($result))
			{?>
              <option value="<?=$row['fldFacilityName']?>" <? if($sql_values_fetch['fldFacilityName'] == $row['fldFacilityName']) {?> selected="selected" <? } ?>>
              <?=strtoupper($row['fldFacilityName'])?>
              </option>
              <? } ?>
            </select></td>
            <td width="6%" class="lab"> Phone </td>
            <td width="19%"><div id="txtHint"><input name='faccontact' type='text' class='myinput1'  value='<?=$sql_values_fetch['fldFacPhone']?>' /></div></td>
          </tr>
          <tr>
            <td width="5%"><span class="lab">Room #</span></td>
            <td width="18%"><input name="patientroom" type="text" class="myinput1" value="<?=$sql_values_fetch['fldPatientroom']?>" /></td>
            <td><span class="lab">Urgent</span></td>
            <td width="9%"><input name="stat" type="checkbox" class="chk" value="1" <? if($sql_values_fetch['fldStat'] == 1) {?>checked="checked"<? } ?> /></td>
            <td width="9%"><span class="lab">After Hours</span></td>
            <td width="25%"><input name="afterhours" type="checkbox" class="chk" value="1" <? if($sql_values_fetch['fldAfterhours'] == 1) {?>checked="checked"<? } ?> /></td>
          </tr>
		  <tr>       
            <td><span class="lab">Stairs</span></td>
            <td width="9%"><input name="stairs" type="checkbox" class="chk" value="1" <? if($sql_values_fetch['fldStairs'] == 1) {?>checked="checked"<? } ?> /></td>
            <td width="5%"><span class="lab"># of stairs</span></td>
            <td width="10%"><input name="nstairs" type="text" class="myinput2" value="<?=$sql_values_fetch['fldNstairs']?>" /></td>
          </tr>

        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
		<? # loop start
		for ( $pntr = 1; $pntr < 7; $pntr++)
		{	
		?>
          <tr>
            <td width="9%"><span class="lab">Procedure #<? echo $pntr; ?></span></td>
            <td width="33%"><span class="lab">
			<? 
			doSelect("procedure".$pntr, $procarray, $sql_values_fetch['fldProcedure'.$pntr],'myselect2');
			doRadio("plr".$pntr, "LEFT", $sql_values_fetch['fldplr'.$pntr],"L"); 
			doRadio("plr".$pntr, "RIGHT", $sql_values_fetch['fldplr'.$pntr],"R"); 
			doRadio("plr".$pntr, "BILATERAL", $sql_values_fetch['fldplr'.$pntr],"B");
 			?>
            </span></td>
            <td width="8%"><span class="lab">Symptom </span></td>
            <td width="48%"><span class="lab">
              <input name="symptoms<? echo $pntr; ?>" type="text" size="40" value="<?=$sql_values_fetch['fldSymptom'.$pntr]?>" style="background-color: #FFFF99;"/>
            </span></td>
            <td width="2%">&nbsp;</td>
          </tr>
		<? # End loop
		}
		?>   
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Additional Patient Info and Special Instrcutions</span></td>
          </tr>
          <tr>
            <td><input name="symptoms" type="text"  value="<?=$sql_values_fetch['fldSymptoms']?>" size="150" /></td>
          </tr>
          <tr>
            <td><span class="lab">History:</span></td>
          </tr>
          <tr>
            <td><input name="history" type="text"  value="<?=$sql_values_fetch['fldHistory']?>" size="150"  style="background-color: #FFFF99;"/></td>

          </tr>
		  <tr>
            <td><span class="lab">Patient Notes:</span></td>
          </tr>
          <tr>
            <td><textarea rows='4' cols='113' name='patNotes' id='patNotes' style=' resize:none;'><?=$sql_values_fetch['fldPatNotes']?></textarea></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="11%"><span class="lab">Referring Dr. </span></td>
            <td colspan="2"><select name="orderingphysicians" class="myselect1" onChange="phyenable();"  style="background-color: #FFFF99;">
              <option selected="selected" value="">Select</option>
              <?
			  if($_SESSION['role'] =='facilityuser')
    		  {
				//$sql="Select * from tbluser where fldRole='orderingphysician' and fldID in (Select fldUserID from tbluserfacdetails where                           fldFacility in (Select fldFacility from tbluserfacdetails where fldUserID in(Select fldid from tbluser where fldUserName='$user'))) Order by FldRealName";
				$sql = "SELECT * FROM tbluser where fldRole='orderingphysician' order by fldRealName";
			  } 
			  else 
			  {
				$sql="SELECT * FROM tbluser where fldRole='orderingphysician' order by fldRealName";
			  }
			  $result = mysql_query($sql);
			  while($row = mysql_fetch_array($result))
	     	  {?>
              <option value="<?=$row['fldRealName']?>" <? if($sql_values_fetch['fldOrderingPhysicians'] == $row['fldRealName']) {?> selected="selected" <? } ?>>

              <?=strtoupper($row['fldRealName'])?>
              </option>
              <? } ?>
              <option value="new">Not In List</option>
            </select>        <input name="phynew" id="phynew" style="display: none;"/></td>
            <td width="19%">
              <span class="lab">Date Exam needed: </span></td>
            <td width="12%"><? doDatePick('schdate12',$schdate12); ?></td>
		</tr>
          
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
	  <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><span class="lab">Insurance Type</span></td>
            <td><select name="insurance" class="myselect1">
              <option selected="selected" value="">Select</option>
              <?
	  		  $sql="SELECT * FROM tbllists where fldListName = 'insurance' order by fldValue";
	  		  $result = mysql_query($sql);
	  		  while($row = mysql_fetch_array($result))
	  		  {?>
              <option value="<?=$row['fldValue']?>"<? if($sql_values_fetch['fldInsurance'] == $row['fldValue']) {?> selected="selected" <? } ?>>
              <?=strtoupper($row['fldValue'])?>
              </option>
              <? } ?>
            </select></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td width="13%"><span class="lab">Medicare #</span></td>
            <td width="28%"><input name="medicare" type="text" class="myinput1" value="<?=$sql_values_fetch['fldMedicareNumber']?>" /></td>
            <td width="11%"><span class="lab">Medicaid #</span></td>
            <td width="21%"><input name="medicaid" type="text" class="myinput1" value="<?=$sql_values_fetch['fldMedicaidNumber']?>" /></td>
            <td width="7%"><span class="lab">State</span></td>
            <td width="20%"><? doSelect("state", $starray, $sql_values_fetch['fldState'], ''); ?>			</td>
          </tr>
          <tr>
            <td><span class="lab">Insurance Company </span></td>
            <td><input name="insurancecompanyname" type="text" class="myinput3" value="<?=$sql_values_fetch['fldInsuranceCompanyName']?>" /></td>
            <td><span class="lab">Policy #</span></td>
            <td><input name="policy" type="text" class="myinput1" value="<?=$sql_values_fetch['fldPolicy']?>" /></td>
            <td><span class="lab">Group #</span></td>
            <td><input name="group" type="text" class="myinput1" value="<?=$sql_values_fetch['fldGroup']?>" /></td>
          </tr>
          <tr>
            <td><span class="lab">HMO Name/Contract </span></td>
            <td><input name="hmo_contract" type="text" class="myinput1" value="<?=$sql_values_fetch['fldHmoContract']?>" /></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="13%"><span class="lab">Responsible Party:</span></td>
            <td width="28%"><input name="responsibleperson" type="text" class="myinput3"  value="<?=$sql_values_fetch['fldResponsiblePerson']?>" /></td>
            <td width="11%"><span class="lab">Relationship</span></td>
            <td width="48%"><select name="relationship" class="myselect2">
              <option selected="selected" value="">Select</option>
              <?
    		  $sql="SELECT * FROM tbllists where fldListName = 'relationship' order by fldValue";
    		  $result = mysql_query($sql);
    		  while($row = mysql_fetch_array($result))
    		  {?>
              <option value="<?=$row['fldValue']?>" <? if($sql_values_fetch['fldRelationship'] == $row['fldValue']) {?> selected="selected" <? } ?>>
              <?=strtoupper($row['fldValue'])?>
              </option>
              <? } ?>
            </select></td>
          </tr>
                <tr>

            <td><span class="lab">Phone #</span></td>
            <td><input name="privatephone" type="text" class="myinput1" value="<?=$sql_values_fetch['fldPrivatePhoneNumber']?>" /></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td>This Patient would find it physically and/or psychologically taxing because of advanced age and/or physical limitations to receive an X-ray or EKG outside this location. This test is medically necessary for the diagnosis and treatment of this patient.</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><div align="center">
              <input type="submit" name="submit" value="Add" />
            </div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>

    </table></td>
  </tr>
</table>
</form>
<? } # Data Entry ?>