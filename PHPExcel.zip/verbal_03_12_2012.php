<?php session_start();
// if session is not set redirect the user
if(empty($_SESSION['user']))
header("Location:index.php");
include "config.php";
$sql_values_fetch = mysql_fetch_array(mysql_query("select *,DATE_FORMAT(tr_modified_date,'%m/%d/%Y %H:%i') AS tr_modified_date_formated from tblorderdetails where fldID='$id'"));
?>
<link href="style.css" rel="stylesheet" type="text/css">
<form action="" method="post">
  <table width="1050" border="0" align="center" cellpadding="0" cellspacing="0" background="main.png">
    <tr>
      <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="9%" class="lab">Facility Name </td>
              <td width="16%"><span class="dis">
                <?=strtoupper($sql_values_fetch['fldFacilityName'])?>
              </span></td>
              <td width="6%" class="lab">Phone</td>
              <td width="38%"><span class="dis">
                <?=strtoupper($sql_values_fetch['fldFacPhone'])?>
              </span></td>
              <td width="6%" class="lab">&nbsp;</td>
              <td width="25%">&nbsp;</td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

            <tr>
              <td width="9%"><span class="lab">First name</span></td>
              <td width="16%"><span class="dis">
                <?=strtoupper($sql_values_fetch['fldFirstName'])?>
              </span></td>
              <td width="10%"><span class="lab">Middle name</span></td>
              <td width="17%"><span class="dis">
                <?=strtoupper($sql_values_fetch['fldMiddleName'])?>
              </span></td>
              <td width="12%"><span class="lab">Last name</span></td>
              <td width="17%"><span class="dis">
                <?=strtoupper($sql_values_fetch['fldLastName'])?>
              </span></td>
              <td width="6%">&nbsp;</td>
              <td width="13%">&nbsp;</td>
            </tr>
            <tr>
              <td class="lab">Patient MR# </td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldPatientID'])?>
              </span></td>
              <td><span class="lab">DOB </span></td>
              <td><span class="dis">
                <?
				function formatDateddmmyy($dDate){
				if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
				    return '';
}
				$dNewDate = strtotime($dDate);
				return date('m-d-Y',$dNewDate);
				}
				$fdob = strtoupper($sql_values_fetch['fldDOB']);
				$ddob = formatDateddmmyy($fdob);
				?>
                <?=strtoupper($ddob)?>
              </span></td>
              <td><span class="lab">Patient SSN</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldPatientSSN'])?>
              </span></td>
              <td><span class="lab">Sex</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldGender'])?>
              </span></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="9%"><span class="lab">Room #</span></td>
              <td width="16%"><span class="dis">
                <?=strtoupper($sql_values_fetch['fldPatientroom'])?>
              </span></td>
              <td width="6%"><span class="lab">Urgent</span></td>
              <td><span class="dis">
                <? if($sql_values_fetch['fldStat'] == 1) {?>
URGENT
<? } else { ?>
NORMAL
<? } ?>
              </span></td>
              <td width="9%"><span class="lab">Order Date : </span></td>
              <td width="16%"><span class="dis">
                <?echo strftime("%m-%d-%Y %H:%M", strtotime($sql_values_fetch['fldDate']));?>
              </span></td>
              <td width="30%"'>&nbsp;</td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="10%"><span class="lab">Procedure #1</span></td>
              <td width="25%"><span class="dis">
                <?=strtoupper($sql_values_fetch['fldProcedure1'])?>
              </span></td>
              <td width="3%"><span class="lab">L/R</span></td>
              <td width="12%"><span class="dis">
                <?=strtoupper($sql_values_fetch['fldplr1'])?>
              </span></td>
              <td width="8%"><span class="lab">Symptom </span></td>
              <td width="33%"><span class="dis">
                <?=strtoupper($sql_values_fetch['fldSymptom1'])?>
              </span></td>
              <td width="4%"><span class="lab">Pos/Neg</span></td>
 			  <td width="6%"><select name="sign1">
				<option value="" <? if($sql_values_fetch['fldSign1'] == '') {?> selected="selected" <? } ?>>Select</option>
				<option value="1" <? if($sql_values_fetch['fldSign1'] == '1') {?> selected="selected" <? } ?>>Positive</option>
				<option value="0" <? if($sql_values_fetch['fldSign1'] == '0') {?> selected="selected" <? } ?>>Negative</option>
              </select></td>
            </tr>
            <tr>
              <td><span class="lab">Procedure #2</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldProcedure2'])?>
              </span></td>
              <td><span class="lab">L/R</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldplr2'])?>
              </span></td>
              <td><span class="lab">Symptom </span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldSymptom2'])?>
              </span></td>
              <td width="4%"><span class="lab">Pos/Neg</span></td>
 			  <td><select name="sign2">
				<option value="" <? if($sql_values_fetch['fldSign2'] == '') {?> selected="selected" <? } ?>>Select</option>
				<option value="1" <? if($sql_values_fetch['fldSign2'] == '1') {?> selected="selected" <? } ?>>Positive</option>
				<option value="0" <? if($sql_values_fetch['fldSign2'] == '0') {?> selected="selected" <? } ?>>Negative</option>
              </select></td>
            </tr>
            <tr>
              <td><span class="lab">Procedure #3</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldProcedure3'])?>
              </span></td>
              <td><span class="lab">L/R</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldplr3'])?>
              </span></td>
              <td><span class="lab">Symptom </span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldSymptom3'])?>
              </span></td>
              <td width="4%"><span class="lab">Pos/Neg</span></td>
 			  <td><select name="sign3">
				<option value="" <? if($sql_values_fetch['fldSign3'] == '') {?> selected="selected" <? } ?>>Select</option>
				<option value="1" <? if($sql_values_fetch['fldSign3'] == '1') {?> selected="selected" <? } ?>>Positive</option>
				<option value="0" <? if($sql_values_fetch['fldSign3'] == '0') {?> selected="selected" <? } ?>>Negative</option>
              </select></td>
            </tr>
            <tr>
              <td><span class="lab">Procedure #4</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldProcedure4'])?>
              </span></td>
              <td><span class="lab">L/R</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldplr4'])?>
              </span></td>
              <td><span class="lab">Symptom </span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldSymptom4'])?>
              </span></td>
              <td width="4%"><span class="lab">Pos/Neg</span></td>
 			  <td><select name="sign4">
				<option value="" <? if($sql_values_fetch['fldSign4'] == '') {?> selected="selected" <? } ?>>Select</option>
				<option value="1" <? if($sql_values_fetch['fldSign4'] == '1') {?> selected="selected" <? } ?>>Positive</option>
				<option value="0" <? if($sql_values_fetch['fldSign4'] == '0') {?> selected="selected" <? } ?>>Negative</option>
              </select></td>
            </tr>
            <tr>
              <td><span class="lab">Procedure #5</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldProcedure5'])?>
              </span></td>
              <td><span class="lab">L/R</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldplr5'])?>
              </span></td>
              <td><span class="lab">Symptom </span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldSymptom5'])?>
              </span></td>
              <td width="4%"><span class="lab">Pos/Neg</span></td>
 			  <td><select name="sign5">
				<option value="" <? if($sql_values_fetch['fldSign5'] == '') {?> selected="selected" <? } ?>>Select</option>
				<option value="1" <? if($sql_values_fetch['fldSign5'] == '1') {?> selected="selected" <? } ?>>Positive</option>
				<option value="0" <? if($sql_values_fetch['fldSign5'] == '0') {?> selected="selected" <? } ?>>Negative</option>
              </select></td>
            </tr>
            <tr>
              <td><span class="lab">Procedure #6</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldProcedure6'])?>
              </span></td>
              <td><span class="lab">L/R</span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldplr6'])?>
              </span></td>
              <td><span class="lab">Symptom </span></td>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldSymptom6'])?>
              </span></td>
              <td width="4%"><span class="lab">Pos/Neg</span></td>
 			  <td><select name="sign6">
				<option value="" <? if($sql_values_fetch['fldSign6'] == '') {?> selected="selected" <? } ?>>Select</option>
				<option value="1" <? if($sql_values_fetch['fldSign6'] == '1') {?> selected="selected" <? } ?>>Positive</option>
				<option value="0" <? if($sql_values_fetch['fldSign6'] == '0') {?> selected="selected" <? } ?>>Negative</option>
              </select></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><span class="lab">Additional Patient Info</span></td>
            </tr>
            <tr>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldSymptoms'])?>
              </span></td>
            </tr>
            <tr>
              <td><span class="lab">History:</span></td>
            </tr>
            <tr>
              <td><span class="dis">
                <?=strtoupper($sql_values_fetch['fldHistory'])?>
              </span></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
			  <td width="5%"><span class="lab">Tech Recieved</span></td>
			 <td width="10%"><select name="pps">
				<option value="" <? if($sql_values_fetch['fldpps'] == '') {?> selected="selected" <? } ?>>Select</option>
				<option value="yes" <? if($sql_values_fetch['fldpps'] == 'yes') {?> selected="selected" <? } ?>>Yes</option>
				<option value="no" <? if($sql_values_fetch['fldpps'] == 'no') {?> selected="selected" <? } ?>>No</option>
				</select>
			 </td>
			 <?php
				if($sql_values_fetch['fldpps'] != 'yes')
				{
			?>				
				<td width="3%">&nbsp;</td>
				<td width="12%"><span class="lab">Date CD Shipped : </span></td>
				<td width="10%"><input name="cdshipdate" type="text" value="<?=$sql_values_fetch['fldCDShipDate']?>" id="cdshipdate" size="8"/></td>
				<td width="55%">&nbsp;</td>
			<?php	
				}
				else
				{
			?>
				<td width="20%">
					<span class="lab">
								Confimred by: : <?php echo $sql_values_fetch['tr_modified_by'];?><br/>
								at <?php echo $sql_values_fetch['tr_modified_date_formated'];?>
					</span>			
				</td>
				<td width="12%"><span class="lab">Date CD Shipped : </span></td>
				<td width="10%"><input name="cdshipdate" type="text" value="<?=$sql_values_fetch['fldCDShipDate']?>" id="cdshipdate" size="8"/></td>
				<td width="22%">&nbsp;</td>
			<?php
				}
			?>
            </tr>
		
          </table></td>
          </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>
          	<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td class="lab"  width="9%">Exception 1</td>
					<td  width="20%"><select name="exception1" id="exception1" class="myselect2">
					<option selected="selected" value="">Select</option>
					<?
					$sql="SELECT * FROM tbllists where fldListName = 'exception' order by fldValue";
					$result = mysql_query($sql);
					while($row = mysql_fetch_array($result))
					{?>
					<option value="<?=$row['fldValue']?>" <? if($sql_values_fetch['fldException1'] == $row['fldValue']) {?> selected="selected" <? } ?>>
					<?=strtoupper($row['fldValue'])?>
					</option>
					<? } ?>
					</select></td>
					
				<tr>
					<td class="lab"  width="9%">Exception 2</td>
					<td  width="20%"><select name="exception2" id="exception1" class="myselect2">
					<option selected="selected" value="">Select</option>
					<?
					$sql="SELECT * FROM tbllists where fldListName = 'exception' order by fldValue";
					$result = mysql_query($sql);
					while($row = mysql_fetch_array($result))
					{?>
					<option value="<?=$row['fldValue']?>" <? if($sql_values_fetch['fldException2'] == $row['fldValue']) {?> selected="selected" <? } ?>>
					<?=strtoupper($row['fldValue'])?>
					</option>
					<? } ?>
					</select></td>
					
				<tr>
					<td class="lab"  width="9%">Exception 3</td>
					<td  width="20%"><select name="exception3" id="exception3" class="myselect2">
					<option selected="selected" value="">Select</option>
					<?
					$sql="SELECT * FROM tbllists where fldListName = 'exception' order by fldValue";
					$result = mysql_query($sql);
					while($row = mysql_fetch_array($result))
					{?>
					<option value="<?=$row['fldValue']?>" <? if($sql_values_fetch['fldException3'] == $row['fldValue']) {?> selected="selected" <? } ?>>
					<?=strtoupper($row['fldValue'])?>
					</option>
					<? } ?>
					</select></td>
					
				</tr>
			</table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><span class="lab">Verbal Report : </span></td>
            </tr>
            <tr>
              <td height="20"><textarea name="ReportDetails" cols="100" rows="3"><?=strtoupper($sql_values_fetch['fldReportDetails'])?>
              </textarea></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="81"><table width="100%" border="0" cellspacing="0" cellpadding="0">
			<?
			$time=date("Y-m-d H:i",time());
			$repdate=$sql_values_fetch['fldReportDate'];
            if($_REQUEST['pg']!="31")
			{
			$repdate=$time;
			}
			function formatDate11($dDate){
			$dNewDate = strtotime($dDate);
			return date('m-d-Y',$dNewDate);
			}
			function formatDate12($dDate){
			$dNewDate = strtotime($dDate);
			return date('H:i',$dNewDate);
			}
			$time11=formatdate11($repdate);
			$time12=formatdate12($repdate);
			?>
            <tr>
              <td width="19%" height="26" class="lab">Time Called in: </td>
              <td width="22%"><input name="schdate1" type="text" value="<?=strtoupper($time11)?>" id="schdate1" size="8"/>
                <input name="schdate2" type="text" value="<?=strtoupper($time12)?>" id="schdate2" size="2"/></td>
              <td width="14%" class="lab">Report Called to: </td>
              <td width="45%"><input name="ReportCalledTo" type="text" id="ReportCalledTo" class="myinput1" value="<?=strtoupper($sql_values_fetch['fldReportCalledTo'])?>"/></td>
            </tr>
            <tr>
              <td height="27" class="lab"># of patients seen on this trip </td>
              <td><select name="nopat" id="nopat" class="myselect4">
                  <option selected="selected" value="">Select</option>
                  <option  Value="1" <? if($sql_values_fetch['fldVerbalnoofpat'] == 1) {?> selected="selected" <? } ?>>1</option>
                  <option  Value="2" <? if($sql_values_fetch['fldVerbalnoofpat'] == 2) {?> selected="selected" <? } ?>>2</option>
                  <option  Value="3" <? if($sql_values_fetch['fldVerbalnoofpat'] == 3) {?> selected="selected" <? } ?>>3</option>
                  <option  Value="4" <? if($sql_values_fetch['fldVerbalnoofpat'] == 4) {?> selected="selected" <? } ?>>4</option>
                  <option  Value="5" <? if($sql_values_fetch['fldVerbalnoofpat'] == 5) {?> selected="selected" <? } ?>>5</option>
                  <option  Value="6" <? if($sql_values_fetch['fldVerbalnoofpat'] == 6) {?> selected="selected" <? } ?>>6</option>
                  <option  Value="7" <? if($sql_values_fetch['fldVerbalnoofpat'] == 7) {?> selected="selected" <? } ?>>7</option>
                  <option  Value="8" <? if($sql_values_fetch['fldVerbalnoofpat'] == 8) {?> selected="selected" <? } ?>>8</option>
                  <option  Value="9" <? if($sql_values_fetch['fldVerbalnoofpat'] == 9) {?> selected="selected" <? } ?>>9</option>
                  <option  Value="10" <? if($sql_values_fetch['fldVerbalnoofpat'] == 10) {?> selected="selected" <? } ?>>10</option>
                  <option  Value="11" <? if($sql_values_fetch['fldVerbalnoofpat'] == 11) {?> selected="selected" <? } ?>>11</option>
                  <option  Value="12" <? if($sql_values_fetch['fldVerbalnoofpat'] == 12) {?> selected="selected" <? } ?>>12</option>
                  <option  Value="13" <? if($sql_values_fetch['fldVerbalnoofpat'] == 13) {?> selected="selected" <? } ?>>13</option>
                  <option  Value="14" <? if($sql_values_fetch['fldVerbalnoofpat'] == 14) {?> selected="selected" <? } ?>>14</option>
                  <option  Value="15" <? if($sql_values_fetch['fldVerbalnoofpat'] == 15) {?> selected="selected" <? } ?>>15</option>
                  <option  Value="16" <? if($sql_values_fetch['fldVerbalnoofpat'] == 16) {?> selected="selected" <? } ?>>16</option>
                  <option  Value="17" <? if($sql_values_fetch['fldVerbalnoofpat'] == 17) {?> selected="selected" <? } ?>>17</option>
                  <option  Value="18" <? if($sql_values_fetch['fldVerbalnoofpat'] == 18) {?> selected="selected" <? } ?>>18</option>
                  <option  Value="19" <? if($sql_values_fetch['fldVerbalnoofpat'] == 19) {?> selected="selected" <? } ?>>19</option>
                  <option  Value="20" <? if($sql_values_fetch['fldVerbalnoofpat'] == 20) {?> selected="selected" <? } ?>>20</option>
                </select>                </td>
              <td class="lab">Reading Radiologist </td>
              <td><select name="radiologist" id="radiologist" class="myselect2">
                <option selected="selected" value="">Select</option>
                <?
    			$sql="SELECT * FROM tbllists where fldListName = 'radiologist' order by fldValue";
    			$result = mysql_query($sql);
    			while($row = mysql_fetch_array($result))
    			{?>
                <option value="<?=$row['fldValue']?>" <? if($sql_values_fetch['fldRadiologist'] == $row['fldValue']) {?> selected="selected" <? } ?>>
                <?=strtoupper($row['fldValue'])?>
                </option>
                <? } ?>
              </select></td>
            </tr>
            <tr>
              <td class="lab"># of Views Done:</td>
              <td><select name="views" class="myselect4" id="views">
                <option selected="selected" value="">Select</option>
                <option  value="1" <? if($sql_values_fetch['fldnoofviews'] == 1) {?> selected="selected" <? } ?>>1</option>
                <option  value="2" <? if($sql_values_fetch['fldnoofviews'] == 2) {?> selected="selected" <? } ?>>2</option>
                <option  value="3" <? if($sql_values_fetch['fldnoofviews'] == 3) {?> selected="selected" <? } ?>>3</option>
                <option  value="4" <? if($sql_values_fetch['fldnoofviews'] == 4) {?> selected="selected" <? } ?>>4</option>
                <option  value="5" <? if($sql_values_fetch['fldnoofviews'] == 5) {?> selected="selected" <? } ?>>5</option>
                <option  value="6" <? if($sql_values_fetch['fldnoofviews'] == 6) {?> selected="selected" <? } ?>>6</option>
                <option  value="7" <? if($sql_values_fetch['fldnoofviews'] == 7) {?> selected="selected" <? } ?>>7</option>
                <option  value="8" <? if($sql_values_fetch['fldnoofviews'] == 8) {?> selected="selected" <? } ?>>8</option>
                <option  value="9" <? if($sql_values_fetch['fldnoofviews'] == 9) {?> selected="selected" <? } ?>>9</option>
                <option  value="10" <? if($sql_values_fetch['fldnoofviews'] == 10) {?> selected="selected" <? } ?>>10</option>
                <option  value="11" <? if($sql_values_fetch['fldnoofviews'] == 11) {?> selected="selected" <? } ?>>11</option>
                <option  value="12" <? if($sql_values_fetch['fldnoofviews'] == 12) {?> selected="selected" <? } ?>>12</option>
                <option  value="13" <? if($sql_values_fetch['fldnoofviews'] == 13) {?> selected="selected" <? } ?>>13</option>
                <option  value="14" <? if($sql_values_fetch['fldnoofviews'] == 14) {?> selected="selected" <? } ?>>14</option>
                <option  value="15" <? if($sql_values_fetch['fldnoofviews'] == 15) {?> selected="selected" <? } ?>>15</option>
                <option  value="16" <? if($sql_values_fetch['fldnoofviews'] == 16) {?> selected="selected" <? } ?>>16</option>
                <option  value="17" <? if($sql_values_fetch['fldnoofviews'] == 17) {?> selected="selected" <? } ?>>17</option>
                <option  value="18" <? if($sql_values_fetch['fldnoofviews'] == 18) {?> selected="selected" <? } ?>>18</option>
                <option  value="19" <? if($sql_values_fetch['fldnoofviews'] == 19) {?> selected="selected" <? } ?>>19</option>
                <option  value="20" <? if($sql_values_fetch['fldnoofviews'] == 20) {?> selected="selected" <? } ?>>20</option>
              </select></td>
              <td class="lab">Tech Completed:</td>
              <?
              $etime=formatdate12($sql_values_fetch['fldExamDate']);
              ?>
              <td><input name="etime" type="text" value="<?=$etime?>" id="etime" size="2"/></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>

        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><div align="center">
                <input type="submit" name="submit" value="Update" />
              </div></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
<?
if($_REQUEST['submit']!='')
{

function formatDate2($dDate){
$dNewDate = strtotime($dDate);
return date('Y-m-d',$dNewDate);
}
$time1=$_REQUEST['schdate1'];
$rptime=formatdate2($time1);
$sDate1 = $time1;
$sDate2 = split('-', $sDate1);
$shdate = $sDate2[2].'-'.$sDate2[0].'-'.$sDate2[1];
$rptime =$shdate . " " . $_REQUEST['schdate2'];
if($_REQUEST['ReportCalledTo']!="")
{
$verbal="1";
}
else
{
$verbal="2";
}
$currentDateTime = date('Y-m-d H:i:s');
$sql_insert	= mysql_query("update tblorderdetails set
fldVerbal='".$verbal."',
fldReportDate='".$rptime."',
fldReportCalledTo='".$_REQUEST['ReportCalledTo']."',
fldReportDetails='".$_REQUEST['ReportDetails']."',
fldRadiologist='".$_REQUEST['radiologist']."',
fldVerbalnoofpat='".$_REQUEST['nopat']."',
fldnoofviews='".$_REQUEST['views']."',
fldExamDate='".$_REQUEST['etime']."',
fldSign1='".$_REQUEST['sign1']."',
fldSign2='".$_REQUEST['sign2']."',
fldSign3='".$_REQUEST['sign3']."',
fldSign4='".$_REQUEST['sign4']."',
fldSign5='".$_REQUEST['sign5']."',
fldSign6='".$_REQUEST['sign6']."',
fldException1='".$_REQUEST['exception1']."',
fldException2='".$_REQUEST['exception2']."',
fldException3='".$_REQUEST['exception3']."',
fldCDShipDate='".$_REQUEST['cdshipdate']."',
fldpps='".$_REQUEST['pps']."',
tr_modified_by = '".$_SESSION['user']."',
tr_modified_date = '$currentDateTime'
where fldID='".$id."'") or die (mysql_error());
if($sql_insert)
{
require('fpdf/html_table.php');

$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tblorderdetails where fldID='$id'"));
$orddate=$sql_values_fetch['fldDate'];
$time=date("Y-m-d H:i",time());
function formatDate21($dDate){
if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
    return '';
}
$dNewDate = strtotime($dDate);
return date('d-m-Y',$dNewDate);
}
function formatDate22($dDate){
if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
    return '';
}
$dNewDate = strtotime($dDate);
return date('H:i',$dNewDate);
}
$time11=formatdate21($orddate);
$time12=formatdate22($orddate);
$rperson=$sql_values_fetch['fldRequestedBy'];
$facility = $sql_values_fetch['fldFacilityName'];
$phone=$sql_values_fetch['fldPhone'];
$fname = $sql_values_fetch['fldFirstName'];
$lname = $sql_values_fetch['fldLastName'];
$mname=$sql_values_fetch['fldMiddleName'];
$sname=$sql_values_fetch['fldSurName'];
$patientid=$sql_values_fetch['fldPatientID'];
$sDate1 = $sql_values_fetch['fldDOB'];
$sDate2 = split('-', $sDate1);
$dob = $sDate2[1].'-'.$sDate2[2].'-'.$sDate2[0];

$ssn=$sql_values_fetch['fldPatientSSN'];
$gender=$sql_values_fetch['fldGender'];
$room=$sql_values_fetch['fldPatientroom'];
$urgent="No";
if($sql_values_fetch['fldStat']==1)
{
$urgent="Yes";
}
$afterhours="No";
if($sql_values_fetch['fldAfterhours']==1)
{
$afterhours="Yes";
}
$symptom1=$sql_values_fetch['fldSymptom1'];
$symptom2=$sql_values_fetch['fldSymptom2'];
$symptom3=$sql_values_fetch['fldSymptom3'];
$symptom4=$sql_values_fetch['fldSymptom4'];
$symptom5=$sql_values_fetch['fldSymptom5'];
$symptom6=$sql_values_fetch['fldSymptom6'];
$plr1=$sql_values_fetch['fldplr1'];
$plr2=$sql_values_fetch['fldplr2'];
$plr3=$sql_values_fetch['fldplr3'];
$plr4=$sql_values_fetch['fldplr4'];
$plr5=$sql_values_fetch['fldplr5'];
$plr6=$sql_values_fetch['fldplr6'];
$additionalinfo=$sql_values_fetch['fldSymptoms'];
$history=$sql_values_fetch['fldHistory'];
$physician=$sql_values_fetch['fldOrderingPhysicians'];
function formatDate1a($dDate){
if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
    return '';
}
$dNewDate = strtotime($dDate);
return date('m-d-Y',$dNewDate);
}
function formatDate1b($dDate){
if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
    return '';
}
$dNewDate = strtotime($dDate);
return date('H:i',$dNewDate);
}


$schdte=$sql_values_fetch['fldSchDate'];
$shdate=formatdate1a($schdte);

$shtime=formatdate1b($schdte);
$cdneeded="No";
if($sql_values_fetch['fldCDRequested']==1)
{
$cdneeded="Yes";
$cddt=$sql_values_fetch['fldCDDate'];
$cddate=formatdate1a($cddt);
$cdaddr=$sql_values_fetch['fldCDAddr'];

}
$medicare=$sql_values_fetch['fldMedicareNumber'];
$medicaid=$sql_values_fetch['fldMedicaidNumber'];
$state=$sql_values_fetch['fldState'];
$inscompany=$sql_values_fetch['fldInsuranceCompanyName'];
$relation=$sql_values_fetch['fldRelationship'];
$addr1=$sql_values_fetch['fldPrivateAddressLine1'];
$addr2=$sql_values_fetch['fldPrivateAddressLine2'];
$addrcity=$sql_values_fetch['fldPrivateAddressCity'];
$addrstate=$sql_values_fetch['fldPrivateAddressState'];
$addrzip=$sql_values_fetch['fldPrivateAddressZip'];
$addrph=$sql_values_fetch['fldPrivatePhoneNumber'];
$addrphone=$addrph;
$hmo_contract=$sql_values_fetch['fldHmoContract'];
$policy=$sql_values_fetch['fldPolicy'];
$group=$sql_values_fetch['fldGroup'];
$verbalrep=strtoupper($sql_values_fetch['fldReportDetails']);
$repdate=$sql_values_fetch['fldReportDate'];

function formatDate1d($dDate){
if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
    return '';
}
$dNewDate = strtotime($dDate);
return date('m-d-Y H:i',$dNewDate);
}
$rpdate=formatdate1d($repdate);

$repcalledto=$sql_values_fetch['fldReportCalledTo'];
$radiologist=$sql_values_fetch['fldRadiologist'];
$noofpatients=$sql_values_fetch['fldVerbalnoofpat'];
$noofviews=$sql_values_fetch['fldnoofviews'];
$examtime=$sql_values_fetch['fldExamDate'];
$resperson=$sql_values_fetch['fldResponsiblePerson'];
if(!$resperson) $resperson='&nbsp;';



$proc=$sql_values_fetch['fldProcedure1'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt1=$sql_values_fetch_proc['fldCBTCode'];
$pdesc1=$sql_values_fetch_proc['fldDescription'];
$proc=$sql_values_fetch['fldProcedure2'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt2=$sql_values_fetch_proc['fldCBTCode'];
$pdesc2=$sql_values_fetch_proc['fldDescription'];
$proc=$sql_values_fetch['fldProcedure3'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt3=$sql_values_fetch_proc['fldCBTCode'];
$pdesc3=$sql_values_fetch_proc['fldDescription'];
$proc=$sql_values_fetch['fldProcedure4'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt4=$sql_values_fetch_proc['fldCBTCode'];
$pdesc4=$sql_values_fetch_proc['fldDescription'];
$proc=$sql_values_fetch['fldProcedure5'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt5=$sql_values_fetch_proc['fldCBTCode'];
$pdesc5=$sql_values_fetch_proc['fldDescription'];
$proc=$sql_values_fetch['fldProcedure6'];
$sql_values_fetch_proc =    mysql_fetch_array(mysql_query("select * from tblproceduremanagment where fldDescription='$proc'"));
$cbt6=$sql_values_fetch_proc['fldCBTCode'];
$pdesc6=$sql_values_fetch_proc['fldDescription'];

$sql_fac=mysql_fetch_array(mysql_query("SELECT * FROM tblfacility where fldFacilityName='$facility'"));
$facph=$sql_fac['fldPhoneNumber'];
$facphone=$facph;

$sql_user=mysql_fetch_array(mysql_query("SELECT * FROM tbluser where fldRealName='$physician'"));
$phyph=$sql_user['fldPhone'];

$plr1=strtoupper($plr1);
$plr2=strtoupper($plr2);
$plr3=strtoupper($plr3);
$plr4=strtoupper($plr4);
$plr5=strtoupper($plr5);
$plr6=strtoupper($plr6);

if(!$noofviews) $noofviews='&nbsp;';
if(!$examtime) $examtime='&nbsp;';

if(!$phyph) $phyph='&nbsp;';
if(!$facphone) $facphone='&nbsp;';
if(!$time11) $time11='&nbsp;';
if(!$time12) $time12='&nbsp;';
if(!$rperson) $rperson='&nbsp;';
if(!$facility ) $facility ='&nbsp;';
if(!$phone) $phone='&nbsp;';
if(!$patientid) $patientid='&nbsp;';
if(!$dob) $dob='&nbsp;';
if(!$ssn) $ssn='&nbsp;';
if(!$gender) $gender='&nbsp;';
if(!$room) $room='&nbsp;';
if(!$urgent) $urgent='&nbsp;';
if(!$afterhours) $afterhours='&nbsp;';
if(!$plr1) $plr1='&nbsp;';
if(!$plr2) $plr2='&nbsp;';
if(!$plr3) $plr3='&nbsp;';
if(!$plr4) $plr4='&nbsp;';
if(!$plr5) $plr5='&nbsp;';
if(!$plr6) $plr6='&nbsp;';
if(!$physician) $physician='&nbsp;';
if(!$shdate) $shdate='&nbsp;';
if(!$shtime) $shtime='&nbsp;';
if(!$cdneeded) $cdneeded='&nbsp;';
if(!$cdaddr) $cdaddr='&nbsp;';
if(!$medicare) $medicare='&nbsp;';
if(!$medicaid) $medicaid='&nbsp;';
if(!$state) $state='&nbsp;';
if(!$inscompany) $inscompany='&nbsp;';
if(!$relation) $relation='&nbsp;';
if(!$addr1) $addr1='&nbsp;';
if(!$addr2) $addr2='&nbsp;';
if(!$addrcity) $addrcity='&nbsp;';
if(!$addrstate) $addrstate='&nbsp;';
if(!$addrphone) $addrphone='&nbsp;';
if(!$hmo_contract) $hmo_contract='&nbsp;';
if(!$policy) $policy='&nbsp;';
if(!$group) $group='&nbsp;';
if(!$repdate) $repdate='&nbsp;';
if(!$rpdate) $rpdate='&nbsp;';
if(!$repcalledto) $repcalledto='&nbsp;';
if(!$radiologist) $radiologist='&nbsp;';
if(!$noofpatients) $noofpatients='&nbsp;';
if(!$cbt1) $cbt1='&nbsp;';
if(!$pdesc1) $pdesc1='&nbsp;';
if(!$cbt2) $cbt2='&nbsp;';
if(!$pdesc2) $pdesc2='&nbsp;';
if(!$cbt3) $cbt3='&nbsp;';
if(!$pdesc3) $pdesc3='&nbsp;';
if(!$cbt4) $cbt4='&nbsp;';
if(!$pdesc4) $pdesc4='&nbsp;';
if(!$cbt5) $cbt5='&nbsp;';
if(!$pdesc5) $pdesc5='&nbsp;';
if(!$cbt6) $cbt6='&nbsp;';
if(!$pdesc6) $pdesc6='&nbsp;';
if(!$noofviews) $noofviews='&nbsp;';
if(!$examtime) $examtime='&nbsp;';


$sDate1 = $time11;
$sDate2 = split('-', $sDate1);
$dt1 = $sDate2[1].'-'.$sDate2[0].'-'.$sDate2[2];

$pdf=new PDF();
$pdf->AddPage();

$html='<table border="0">
<tr>
<td width="50" height="30">Date :</td>
<strong><td width="100" height="30">';
$html.=$dt1;
$html.='</td></strong>
<td width="50" height="30">Time :</td>
<strong><td width="100" height="30">';
$html.=$time12;
$html.='</td></strong>
</tr>
<tr>
<td height="10"></td>
</tr>
<tr>
<td width="55" height="30">Facility : </td>
<strong><td width="350" height="30">';
$html.=$facility;
$html.='</td></strong>
<td width="60" height="30">Contact : </td>
<strong><td width="150" height="30">';
$html.=$rperson;
$html.='</td></strong>
<td width="50" height="30">Phone : </td>
<strong><td width="90" height="30">';
$html.=$facphone;
$html.='</td></strong>
</tr>
<tr>
<td width="90" height="30">Patient Name : </td>
<strong><td width="110" height="30">';
$html.=$fname . ' ' . $mname . ' ' . $lname;
$html.='</td></strong>
</tr>
<tr>
<td width="90" height="30">Patient MR#</td>
<strong><td width="90" height="30">';
$html.=$patientid;
$html.='</td></strong>
<td width="40" height="30">DOB : </td>
<strong><td width="150" height="30">';
$html.=$dob;
$html.='</td></strong>
<td width="40" height="30">SSN# </td>
<strong><td width="180" height="30">';
$html.=$ssn;
$html.='</td>
</strong><td width="40" height="30">Sex : </td>
<strong><td width="50" height="30">';
$html.=strtoupper($gender);
$html.='</td></strong>
</tr>
<tr>
<td width="60" height="30">Room# </td>
<strong><td width="80" height="30">';
$html.=$room;
$html.='</td></strong>
<td width="60" height="30">Urgent? </td>
<strong><td width="50" height="30">';
$html.=$urgent;
$html.='</td></strong>
<td width="80" height="30">After hours? </td>
<strong><td width="40" height="30">';
$html.=$afterhours;
$html.='</td></strong>
<td width="120" height="30">Date Exam needed: </td>
<strong><td width="100" height="30">';
$html.=$shdate;
$html.='</td></strong>
<td width="120" height="30">Time exam needed: </td>
<strong><td width="50" height="30">';
$html.=$shtime;
$html.='</td></strong>
</tr>
<tr>
</tr>
<tr>
<td width="90" height="30">Procedure1# </td>
<strong><td width="160" height="30">';
$html.=$pdesc1;
$html.='<td width="90" height="30">';
$html.=$plr1;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom1);
$html.='</td></strong>
</tr>
<td width="90" height="30">Procedure2# </td>
<strong><td width="160" height="30">';
$html.=$pdesc2;
$html.='<td width="90" height="30">';
$html.=$plr2;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom2);
$html.='</td></strong>
</tr>
<td width="90" height="30">Procedure3# </td>
<strong><td width="160" height="30">';
$html.=$pdesc3;
$html.='<td width="90" height="30">';
$html.=$plr3;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom3);
$html.='</td></strong>
</tr>
<td width="90" height="30">Procedure4# </td>
<strong><td width="160" height="30">';
$html.=$pdesc4;
$html.='<td width="90" height="30">';
$html.=$plr4;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom4);
$html.='</td></strong>
</tr>
<td width="90" height="30">Procedure5# </td>
<strong><td width="160" height="30">';
$html.=$pdesc5;
$html.='<td width="90" height="30">';
$html.=$plr5;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom5);
$html.='</td></strong>
</tr>
<td width="90" height="30">Procedure6# </td>
<strong><td width="160" height="30">';
$html.=$pdesc6;
$html.='<td width="90" height="30">';
$html.=$plr6;
$html.='</td></strong>
<td width="90" height="30">Symptoms: </td>
<strong><td width="120" height="30">';
$html.=strtoupper($symptom6);
$html.='</td></strong>
</tr>
<tr>
</tr>
</table>';

$html1='<table border="0">
<tr>
<td width="90" height="30">Ordering Dr. </td>
<strong><td width="330" height="30">';
$html1.=strtoupper($physician);
$html1.='</td></strong>
<td width="50" height="30">Phone# </td>
<strong><td width="250" height="30">';
$html1.=$phyph;
$html1.='</td></strong>
</tr>
<tr>
<td width="90" height="30">CD Needed ? </td>
<strong><td width="75" height="30">';
$html1.=$cdneeded;
if($cdneeded!='No')
{
$html1.='</td></strong>
<td width="60" height="30">Location : </td>
<strong><td width="325" height="30">';
$html1.=$cdaddr;
$html1.='</td></strong>
<td width="100" height="30">Date Needed By : </td>
<strong><td width="80" height="30">';
$html1.=$cddate;
}
$html1.='</td></strong>
</tr>
<tr>
<td width="90" height="30">Medicare# </td>
<strong><td width="330" height="30">';
$html1.=$medicare;
$html1.='</td></strong>
<u><strong><td width="140" height="30">Responsible Party </td></strong></u>
</tr>
<tr>
<td width="90" height="30">Medicaid# </td>
<strong><td width="180" height="30">';
$html1.=$medicaid;
$html1.='</td></strong>
<td width="30" height="30">ST </td>
<strong><td width="120" height="30">';
$html1.=$state;
$html1.='</td></strong>
<td width="140" height="30">Name :</td>
<strong><td width="120" height="30">';
$html1.=$resperson;
$html1.='</td></strong>
</tr>
<tr>
<td width="420" height="30">&nbsp;</td>
<td width="140" height="30">Relationship :</td>
<strong><td width="120" height="30">';
$html1.=$relation;
$html1.='</td></strong>
</tr>
<tr>
<td width="110" height="30">Supplementary Ins :</td>
<strong><td width="310" height="30">';
$html1.=$inscompany;
$html1.='</td></strong>
<td width="140" height="30">Address :</td>
<strong><td width="120" height="30">';
$html1.=$addr1;
$html1.='</td></strong>
</tr>
<tr>
<td width="110" height="30">Policy# </td>
<strong><td width="310" height="30">';
$html1.=$policy;
$html1.='</td></strong>
<td width="140" height="30">&nbsp;</td>
<strong><td width="120" height="30">';
$html1.=$addr2;
$html1.='</td></strong>
</tr>
<tr>
<td width="110" height="30">Group# </td>
<strong><td width="310" height="30">';
$html1.=$group;
$html1.='</td></strong>
<td width="140" height="30">&nbsp;</td>
<strong><td width="120" height="30">';
$html1.=$addrcity;
$html1.='</td></strong>
</tr>
<tr>
<td width="110" height="30">HMO :</td>
<strong><td width="310" height="30">';
$html1.=$hmo_contract;
$html1.='</td></strong>
<td width="140" height="30">&nbsp;</td>
<strong><td width="120" height="30">';
$html1.=$addrstate . "," . $addrzip;
$html1.='</td></strong>
</tr>
<tr>
<td width="420" height="30">&nbsp;</td>
<td width="140" height="30">Phone </td>
<strong><td width="120" height="30">';
$html1.=$addrphone;
$html1.='</td></strong>
</tr>
<tr>
</tr>
<tr>
<td width="560" height="30">I request that payment of authorized Medicare and/or Medigap benefits be made either to me or on my behalf to MD Imaging </td>
</tr>
<tr>
<td width="560" height="30">Services and/or the interpreting physician for any services furnished me by that physician or supplier. I authorize any holder of</td>
</tr>
<tr>
<td width="560" height="30">medical information about me to release to the Center for Medicare and Medicaid Services and its agents any information</td>
</tr>
<tr>
<td width="560" height="30">needed to determine these benefits payable for related services.</td>
</tr>
<tr>
</tr>
<tr>
<u><td width="300" height="30">X                                         </td></u>
<u><td width="220" height="30">X                                         </td></u>
</tr>
<tr>
<td width="300" height="30">Patient Signature</td>
<td width="220" height="30">Nurse�s Signature (if patient unable to sign)</td>
</tr>
<tr>
</tr>
</table>';
$html2='<table border="0">
<tr>
<td width="90" height="30">Time Called in :</td>
<strong><td width="130" height="30">';
$html2.=$rpdate;
$html2.='</td></strong>
<td width="110" height="30">Report Called to :</td>
<strong><td width="110" height="30">';
$html2.=$repcalledto;
$html2.='</td></strong>
<td width="120" height="30">Reading Radiologist :</td>
<strong><td width="110" height="30">';
$html2.=$radiologist;
$html2.='</td></strong>
</tr>
<tr>
<td width="130" height="30"># of Patients this Trip :</td>
<strong><td width="90" height="30">';
$html2.=$noofpatients;
$html2.='</td></strong>
<td width="100" height="30"># of Views Done :</td>
<strong><td width="120" height="30">';
$html2.=$noofviews;
$html2.='</td></strong>
<td width="100" height="30">Time Exam Done :</td>
<strong><td width="50" height="30">';
$examtm=formatdate1b($examtime);
$html2.=$examtm;
$html2.='</td></strong>
</tr>
<tr>
</tr>
</table>';
$pdf->Ln(10);
$pdf->SetFont('Arial','B',20);
$pdf->Cell(110,10,'MD Imaging, Inc.   ',0,0,'C');
$pdf->Ln();
$pdf->SetFont('Arial','B',11);
$pdf->Cell(90,10,'Phone 847-626-0800  Fax 847-626-0817',0,0,'C');
$pdf->Ln(15);
$pdf->SetFont('Arial','',9);
$pdf->WriteHTML($html);
$pdf->Cell(90,10,'Additonal patient Info');
$pdf->Ln(5);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(90,10,$additionalinfo);
$pdf->Ln(10);
$pdf->SetFont('Arial','',9);
$pdf->Cell(90,10,'History');
$pdf->Ln(5);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(90,10,$history);
$pdf->Ln(10);
$pdf->SetFont('Arial','',9);
$pdf->WriteHTML($html1);
$pdf->Cell(90,10,'Verbal Report');
$pdf->Ln(5);
$pdf->SetFont('Arial','B',9);
//new code for verbal
function splitString($string, $amount)
{
$start = 0;
$end = $amount;
while ($end < strlen($string)+$amount)
{
$strArray[] = substr($string, $start, $amount);
$start = $end;
$end = $end + $amount;
}
return $strArray;
}
$len=strlen($verbalrep);
$count=$len/100;
$count=$count+0.5;
$count=round($count);
$veb = splitString($verbalrep, 100);
for($i=0;$i<$count;$i++)
{
$pdf->Cell(90,10,$veb[$i]);
$pdf->Ln(5);
}
$pdf->Ln();
$pdf->SetFont('Arial','',9);
$pdf->WriteHTML($html2);
function formatDate1c($dDate){
if (trim($dDate) == '' || substr($dDate,0,10) == '0000-00-00') {
    return '';
}
$dNewDate = strtotime($dDate);
return date('Y-m-d',$dNewDate);
}
$credt=$sql_values_fetch['fldDate'];
$cretime=formatdate1c($credt);
$sql_values_fetch = mysql_fetch_array(mysql_query("select * from tblsettings"));
$dest=$sql_values_fetch['fldPDFUnsignedOrders'];
$filename = $dest . "u" . $cretime . $lname . $fname . "_" . $id . ".pdf";
unlink($filename);
$pdf->Output($filename,'F');

$redirecturl = "index.php?pg=20";
header("location:".$redirecturl);
}
}
?>