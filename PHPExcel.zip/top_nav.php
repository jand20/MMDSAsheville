<div class="top" id="top2a" align="left">User <?echo $_SESSION['user'];?>  |<?
	if($_SESSION['role'] =='admin' || $_SESSION['role'] =='dispatcher' || $_SESSION['role'] =='coder') {?>
	<a href="?pg=36" style="color:#fff;text-decoration:none; padding-left:10px;align: left;">Report  </a> |
	<? } ?>
	<?
	if( $_SESSION['role'] == 'admin' ) {?>
	<a href="?pg=55" style="color:#fff;text-decoration:none; padding-left:10px;align: left;">  </a> |
	<? } ?>
	<a href="?pg=34" style="color:#fff;text-decoration:none; padding-left:10px;align: left;">Legend  </a> |
	<?php
		if($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'dispatcher' || 1)
		{
			echo '<a href="map.php" target="_blank" style="color:#fff;text-decoration:none; padding-left:10px;align: left;">Map It  </a> |';
			echo '<a href="?pg=72" style="color:#fff;text-decoration:none; padding-left:10px;align: left;">Techs  </a> |';
		}
		if( $_SESSION['role'] == 'admin' || $_SESSION['role'] == 'technologist' || $_SESSION['role'] == 'dispatcher' || $_SESSION['role'] =='coder' )
		{
			echo '<a href="?pg=73" style="color:#fff;text-decoration:none; padding-left:10px;align: left;">Facilities  </a> |';
		}

		if( $_SESSION['role'] == 'admin' || $_SESSION['role'] == 'dispatcher')
		{
			echo '<a href="?pg=74" style="color:#fff;text-decoration:none; padding-left:10px;align: left;">MD MGT  </a>';
		}
	?>
	<a href="?pg=43" style="color:#fff;text-decoration:none; padding-left:10px;align: left;">Change Password</a>
	<? if( $_SESSION['role'] == 'technologist' ) {?>
	 | <a href="?pg=44" style="color:#fff;text-decoration:none; padding-left:10px;align: left;">Tech Report  </a><? } ?>
	 <? if( $_SESSION['role'] == 'facilityuser' ) {?>
	 | <a href="?pg=45" style="color:#fff;text-decoration:none; padding-left:10px;align: left;">Facility Report  </a>
	  | <a href="?pg=63" style="color:#fff;text-decoration:none; padding-left:10px;align: left;">  </a>
	 <? } ?>

  </div>